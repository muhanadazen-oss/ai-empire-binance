CREATE TABLE `empire_research` (
	`user_id` text PRIMARY KEY NOT NULL,
	`report` text NOT NULL,
	`scanned_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `empire_wallet_transfers` (
	`hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`recipient` text NOT NULL,
	`amount` text NOT NULL,
	`raw` text NOT NULL,
	`status` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `empire_wallets` (
	`user_id` text PRIMARY KEY NOT NULL,
	`address` text NOT NULL,
	`vault` text NOT NULL,
	`created_at` text NOT NULL
);
