CREATE TABLE `empire_wallet_deposits` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`hash` text NOT NULL,
	`sender` text NOT NULL,
	`amount` text NOT NULL,
	`created_at` text NOT NULL
);
