CREATE TABLE `empire_autotrader_preferences` (
	`user_id` text PRIMARY KEY NOT NULL,
	`capital` text NOT NULL,
	`updated_at` text NOT NULL
);
