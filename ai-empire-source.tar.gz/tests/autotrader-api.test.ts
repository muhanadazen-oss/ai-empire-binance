import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../server/worker.ts';
import {sqliteDB} from './sqlite.ts';
test('proof dashboard isolates chosen caps and refuses fabricated live proof and CSRF',async()=>{
 const {db,sqlite}=sqliteDB();let cookie='';
 async function call(path:string,body?:any,origin='https://empire.test'){const r=await worker.fetch(new Request('https://empire.test'+path,{method:body?'POST':'GET',headers:{cookie,...(body?{origin,'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})}),{DB:db});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie')!.split(';')[0];return {status:r.status,data:await r.json() as any};}
 assert.equal((await call('/api/autotrader')).status,401);await call('/api/session');assert.equal((await call('/api/autotrader')).status,401);
 await call('/api/auth/register',{name:'المؤسس',email:'bot-owner@example.test',password:'secure-test-password'});
 const initial=await call('/api/autotrader');assert.equal(initial.data.capital,null);assert.equal(initial.data.canActivate,false);assert.equal(initial.data.referenceBacktest.passed,false);
 assert.equal((await call('/api/autotrader/configure',{capital:40},'https://evil.test')).status,403);
 assert.equal((await call('/api/autotrader/configure',{capital:NaN})).status,400);
 assert.equal((await call('/api/autotrader/configure',{capital:40})).data.capital,40);
 assert.equal((await call('/api/autotrader')).data.capital,40);
 assert.equal((await call('/api/autotrader/activate',{ack:'ACTIVATE_LIVE',capital:1e6,passed:true,paperDays:60,policy:{dailyLoss:99}})).status,503);
 await call('/api/auth/logout',{});await call('/api/session');await call('/api/auth/register',{name:'مستخدم آخر',email:'bot-other@example.test',password:'secure-test-password'});
 assert.equal((await call('/api/autotrader')).data.capital,null);sqlite.close();
});
