import test from 'node:test';
import assert from 'node:assert/strict';
import {assignAgentRoles,initialState,tick} from '../src/engine/game.ts';
test('employee duties stay unique while an existing kingdom keeps its history and capital',()=>{
 const previous=tick(initialState(42)),before={cash:previous.cash,closed:previous.closed.length,history:previous.agents.map(a=>a.history.length)};
 const state=assignAgentRoles(previous);
 const byId=Object.fromEntries(state.agents.map(a=>[a.id,a]));
 assert.equal(byId.analyst.role,'محلل السوق');assert.match(byId.trader.skill,/تحليل نور/);assert.match(byId.monitor.role,/مراقب السوق/);assert.match(byId.advisor.role,/باحثة التوصيات/);assert.match(byId.risk.role,/المديرة المالية/);assert.match(byId.risk.skill,/الوحيدة/);
 assert.equal(state.agents.filter(a=>/مديرة المخاطر|إدارة المخاطر/.test(a.role+a.skill)).length,1);
 assert.equal(state.cash,before.cash);assert.equal(state.closed.length,before.closed);assert.deepEqual(state.agents.map(a=>a.history.length),before.history);
});
