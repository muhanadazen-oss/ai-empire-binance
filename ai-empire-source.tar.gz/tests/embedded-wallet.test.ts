import test from 'node:test';
import assert from 'node:assert/strict';
import {encodeFunctionData,erc20Abi,keccak256,type Hex} from 'viem';
import {privateKeyToAccount} from 'viem/accounts';
import {encryptWallet,decryptWallet,validVault} from '../src/integration/wallet-vault.ts';
import {validateRaw} from '../server/wallet.ts';
import {TOKEN} from '../src/integration/wallet-chain.ts';
import worker from '../server/worker.ts';
import {sqliteDB} from './sqlite.ts';
const secret=('0x'+'12'.repeat(32)) as Hex,account=privateKeyToAccount(secret),recipient='0x2222222222222222222222222222222222222222';
const sign=(change:Record<string,unknown>={})=>account.signTransaction({chainId:56,type:'legacy',nonce:0,gas:60000n,gasPrice:1000000000n,to:TOKEN,value:0n,data:encodeFunctionData({abi:erc20Abi,functionName:'transfer',args:[recipient,10000000000000000001n]}),...change} as any);
test('embedded wallet authenticated encryption binds owner, address, chain; no plaintext key',async()=>{
 const v=await encryptWallet('owner','strong-wallet-password',secret);assert.ok(validVault(v));assert.equal(await decryptWallet(v,'strong-wallet-password'),secret);assert.ok(!JSON.stringify(v).includes(secret));
 assert.notEqual(v.ciphertext,(await encryptWallet('owner','strong-wallet-password',secret)).ciphertext);
 await assert.rejects(decryptWallet(v,'wrong-wallet-password'));
 await assert.rejects(decryptWallet({...v,owner:'other'},'strong-wallet-password'));
 await assert.rejects(decryptWallet({...v,address:recipient},'strong-wallet-password'));
 await assert.rejects(encryptWallet('owner','short',secret));
});
test('signed transfers only allow own signer, USDT, chain 56 and transfer method',async()=>{
 const raw=await sign();assert.deepEqual(await validateRaw(raw,account.address),{hash:keccak256(raw),recipient,amount:'10000000000000000001'});
 for(const change of [{chainId:1},{value:1n},{to:recipient},{gasPrice:100000000001n},{gas:300001n},{data:encodeFunctionData({abi:erc20Abi,functionName:'approve',args:[recipient,100n]})}])await assert.rejects(validateRaw(await sign(change),account.address));
 await assert.rejects(validateRaw(await sign({data:encodeFunctionData({abi:erc20Abi,functionName:'transfer',args:[recipient,9999999999999999999n]})}),account.address),/10 USDT/);
 assert.equal((await validateRaw(await sign({data:encodeFunctionData({abi:erc20Abi,functionName:'transfer',args:[recipient,10000000000000000000n]})}),account.address)).amount,'10000000000000000000');
 await assert.rejects(validateRaw(raw,recipient));
});
test('durable vault isolation, CSRF, pending-before-broadcast and duplicate prevention survive reload',async()=>{
 const {db,sqlite}=sqliteDB();const env={DB:db};
 const client=()=>{let cookie='';return async(path:string,body?:unknown,origin='https://empire.test')=>{const r=await worker.fetch(new Request('https://empire.test'+path,{method:body?'POST':'GET',headers:{Cookie:cookie,...(body?{Origin:origin,'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined}),env);if(r.headers.has('set-cookie'))cookie=r.headers.get('set-cookie')!.split(';')[0];return {status:r.status,data:await r.json() as any};};};
 const a=client(),b=client();const initial=await a('/api/session');await b('/api/session');assert.equal((await a('/api/wallet/vault')).status,401);
 await a('/api/auth/register',{name:'owner',email:'wallet@test.example',password:'strong-game-password'});await b('/api/auth/register',{name:'other',email:'other@test.example',password:'strong-game-password'});
 const v=await encryptWallet(initial.data.user.id,'strong-wallet-password',secret);
 assert.equal((await a('/api/wallet/vault',{vault:v},'https://evil.test')).status,403);assert.equal((await a('/api/wallet/vault',{vault:v})).status,200);
 assert.equal((await b('/api/wallet/vault')).data.vault,null);assert.equal((await b('/api/wallet/vault',{vault:v})).status,400);
 assert.equal((await a('/api/wallet/vault',{vault:await encryptWallet(v.owner,'strong-wallet-password')})).status,409);
 assert.deepEqual((await a('/api/wallet/vault')).data.vault,v);
 const old=globalThis.fetch;let broadcasts=0,receipt:any=null;
 globalThis.fetch=async(input,init)=>{assert.equal(String(input),'https://bsc-dataseed.bnbchain.org');const p=JSON.parse(String(init?.body));if(p.method==='eth_sendRawTransaction'){broadcasts++;assert.equal(sqlite.prepare("SELECT count(*) n FROM empire_wallet_transfers WHERE status='pending'").get()!.n,1);throw new Error('network timeout');}return Response.json({jsonrpc:'2.0',id:1,result:p.method==='eth_getTransactionReceipt'?receipt:'0x12'});};
 try{
  const raw=await sign(),hash=keccak256(raw);const sent=await a('/api/wallet/send',{raw});assert.equal(sent.status,200);assert.equal(sent.data.broadcast,false);assert.equal(sent.data.transfer.status,'pending');
  assert.equal((await a('/api/wallet/transfers')).data.transfers[0].hash,hash);assert.ok(!JSON.stringify((await a('/api/wallet/transfers')).data).includes(raw));
  assert.equal((await a('/api/wallet/send',{raw:await sign({nonce:1})})).status,400);assert.equal(broadcasts,1);
  assert.equal((await b('/api/wallet/receipt',{hash})).status,400);
  assert.equal((await a('/api/wallet/receipt',{hash})).data.transfer.status,'pending');
  receipt={transactionHash:hash,blockNumber:'0x10',status:'0x1'};assert.equal((await a('/api/wallet/receipt',{hash})).data.transfer.status,'confirmed');
  assert.equal((await a('/api/wallet/send',{raw})).data.transfer.status,'confirmed');assert.equal(broadcasts,1);
  assert.equal((await a('/api/wallet/rpc',{method:'eth_sendRawTransaction',params:[raw]})).status,400);
  assert.equal((await a('/api/wallet/rpc',{method:'eth_getBalance',params:[recipient,'latest']})).status,400);
 }finally{globalThis.fetch=old;}
 assert.ok(!String(sqlite.prepare('SELECT vault FROM empire_wallets').get()!.vault).includes(secret));
});
