import test from 'node:test';
import assert from 'node:assert/strict';
import { transferInput, checkContext } from '../src/integration/wallet-chain.ts';
import {checkWithdrawal,MIN_DEPOSIT} from '../src/integration/wallet-limits.ts';
import type { EIP1193Provider } from 'viem';
const address = '0x1234567890123456789012345678901234567890';
test('USDT amounts keep full precision and reject zero, negative, exponent and extra decimals', () => {
  assert.equal(transferInput(address,'1.000000000000000001').value,1000000000000000001n);
  for (const value of ['0','-1','1e3','1.0000000000000000001','NaN','1,2','01']) assert.throws(()=>transferInput(address,value));
});
test('a transfer cannot target zero, token contract or a malformed address', () => {
  for(const value of ['0x0000000000000000000000000000000000000000','0x55d398326f99059ff775485246999027b3197955','0x1234']) assert.throws(()=>transferInput(value,'1'));
});
test('changing chain or account prevents sending', async () => {
  const provider = (chain:string, accounts:string[]) => ({request:async({method}:{method:string})=>method==='eth_chainId'?chain:accounts}) as EIP1193Provider;
  await checkContext(provider('0x38',[address]),address);
  await assert.rejects(checkContext(provider('0x1',[address]),address),/BNB/);
  await assert.rejects(checkContext(provider('0x38',['0x2222222222222222222222222222222222222222']),address),/الحساب/);
});

test('withdrawal minimum is exactly 10 USDT and deposit minimum is 1 USDT',()=>{assert.equal(MIN_DEPOSIT,1000000000000000000n);assert.throws(()=>checkWithdrawal(9999999999999999999n),/10 USDT/);assert.doesNotThrow(()=>checkWithdrawal(10000000000000000000n));assert.doesNotThrow(()=>checkWithdrawal(10000000000000000001n));});
