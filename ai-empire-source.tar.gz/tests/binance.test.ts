import test from 'node:test';
import assert from 'node:assert/strict';
import { seal, unseal, assertReadOnly, exchangeClock, exchangeError } from '../server/binance.ts';
import worker from '../server/worker.ts';
import { sqliteDB } from './sqlite.ts';
const key = btoa(String.fromCharCode(...new Uint8Array(32).fill(7)));
const credentials = { apiKey: 'K'.repeat(64), apiSecret: 'S'.repeat(64) };
test('diagnostics distinguish exchange blockers and never reflect raw upstream messages', async () => {
  assert.equal(exchangeError(302).code, 'EXCHANGE_REDIRECT_BLOCKED');
  assert.equal(exchangeError(451).code, 'EXCHANGE_REGION_BLOCKED');
  assert.equal(exchangeError(403).code, 'EXCHANGE_ACCESS_BLOCKED');
  assert.equal(exchangeError(401, -2015).code, 'KEY_IP_OR_PERMISSIONS');
  assert.equal(exchangeError(400, -1022).code, 'INVALID_SIGNATURE');
  assert.equal(exchangeError(400, -1021).code, 'TIMESTAMP_REJECTED');
  assert.equal(exchangeError(429).code, 'EXCHANGE_RATE_LIMIT');
  const original = globalThis.fetch;
  try {
    globalThis.fetch = async () => new Response(JSON.stringify({code:-2015,msg:credentials.apiSecret}),{status:401});
    await assert.rejects(exchangeClock(), e => { assert.equal((e as any).code, 'KEY_IP_OR_PERMISSIONS'); assert.ok(!(e as Error).message.includes(credentials.apiSecret)); return true; });
    globalThis.fetch = async () => { throw new Error(credentials.apiSecret); };
    await assert.rejects(exchangeClock(), e => { assert.equal((e as any).code, 'EXCHANGE_NETWORK_ERROR'); assert.ok(!(e as Error).message.includes(credentials.apiSecret)); return true; });
    globalThis.fetch = async () => new Response('<html>blocked</html>', {status:451});
    await assert.rejects(exchangeClock(), e => (e as any).code === 'EXCHANGE_REGION_BLOCKED');
    const { db } = sqliteDB();
    const r = await worker.fetch(new Request('https://empire.test/api/binance/health'), {DB:db});
    assert.equal(r.status,503);
    const body = await r.json() as any;
    assert.equal(body.code,'EXCHANGE_REGION_BLOCKED');
    assert.equal(body.reachable,false);
    assert.equal(await db.prepare('SELECT COUNT(*) n FROM empire_users').first().then((r:any)=>r.n),0);
  } finally { globalThis.fetch=original; }
});
test('vault uses authenticated encryption and isolates account identities', async () => {
  const encrypted = await seal(credentials, 'owner', key);
  assert.ok(!encrypted.includes(credentials.apiSecret));
  assert.deepEqual(await unseal(encrypted, 'owner', key), credentials);
  await assert.rejects(unseal(encrypted, 'other-owner', key));
  const p = JSON.parse(encrypted); p.data = p.data.slice(0, -4) + 'AAAA';
  await assert.rejects(unseal(JSON.stringify(p), 'owner', key));
  assert.notEqual(encrypted, await seal(credentials, 'owner', key));
});
test('permissions reject withdrawals, trading and transfer flags, failing closed', () => {
  const reading = { enableReading: true, enableWithdrawals: false };
  assertReadOnly(reading);
  for (const flag of ['enableWithdrawals','enableSpotAndMarginTrading','enableFutures','enableMargin','enableInternalTransfer','permitsUniversalTransfer','enableFixApiTrade','enablePortfolioMarginTrading'])
    assert.throws(() => assertReadOnly({ ...reading, [flag]: true }));
  assert.throws(() => assertReadOnly({enableReading:true}));
});
test('read-only connection reauthenticates, encrypts, persists, isolates and disconnects; no orders', async () => {
  const { db, sqlite } = sqliteDB();
  const env = { DB: db, BINANCE_CREDENTIAL_ENCRYPTION_KEY: key };
  function client() {
    let cookie = '';
    return async (path: string, body?: unknown, origin='https://empire.test') => {
      const res = await worker.fetch(new Request('https://empire.test'+path,{method:body?'POST':'GET',headers:{ Cookie:cookie, ...(body?{'Content-Type':'application/json',Origin:origin}:{}) },body:body?JSON.stringify(body):undefined}),env);
      if (res.headers.has('set-cookie')) cookie=res.headers.get('set-cookie')!.split(';')[0];
      return {status:res.status,data:await res.json() as any};
    };
  }
  const a=client(),b=client();
  await a('/api/session'); await b('/api/session');
  assert.equal((await a('/api/binance/status')).data.registered,false);
  assert.equal((await a('/api/binance/connect',{...credentials,password:'password-test'})).status,403);
  await a('/api/auth/register',{email:'vault@test.example',name:'المؤسس',password:'password-test'});
  const before=(await a('/api/session')).data;
  const oldFetch=globalThis.fetch;
  const calls:string[]=[];
  let unsafe=false, fail=false;
  globalThis.fetch=async (input, init) => {
    const url=new URL(String(input)); calls.push(url.pathname);
    assert.equal(url.origin,'https://api.binance.com');
    assert.equal(init?.redirect, 'manual');
    assert.ok(!init?.method || init.method==='GET');
    if(fail) return new Response(JSON.stringify({msg:credentials.apiSecret}),{status:401});
    if(url.pathname==='/api/v3/time') return Response.json({serverTime:Date.now()});
    assert.ok(url.searchParams.has('signature'));
    assert.equal((init!.headers as Record<string,string>)['X-MBX-APIKEY'],credentials.apiKey);
    return Response.json(url.pathname.includes('apiRestrictions') ? {enableReading:true,enableWithdrawals:unsafe,enableSpotAndMarginTrading:false} : {balances:[{asset:'USDT',free:'4.46',locked:'0'},{asset:'BTC',free:'0',locked:'0'}]});
  };
  try {
    assert.equal((await a('/api/binance/connect',{...credentials,password:'wrong'})).status,401);
    assert.equal(calls.length,0);
    assert.equal((await a('/api/binance/connect',{...credentials,password:'password-test'},'https://evil.test')).status,403);
    unsafe=true;
    assert.equal((await a('/api/binance/connect',{...credentials,password:'password-test'})).status,400);
    assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM empire_binance_connections').get()!.n,0);
    unsafe=false;
    const connected=await a('/api/binance/connect',{...credentials,password:'password-test'});
    assert.equal(connected.status,200);
    assert.deepEqual(connected.data.balances,[{asset:'USDT',free:'4.46',locked:'0'}]);
    assert.ok(!JSON.stringify(connected.data).includes(credentials.apiSecret));
    const record=sqlite.prepare('SELECT * FROM empire_binance_connections').get()!;
    assert.ok(!JSON.stringify(record).includes(credentials.apiKey));
    assert.equal((await a('/api/binance/status')).data.connected,true);
    assert.equal((await b('/api/binance/status')).data.connected,false);
    assert.equal((await a('/api/binance/refresh',{password:'password-test'})).status,200);
    fail=true;
    const rejected=await a('/api/binance/refresh',{password:'password-test'});
    assert.equal(rejected.status,400); assert.ok(!JSON.stringify(rejected.data).includes(credentials.apiSecret));
    fail=false;
    assert.equal((await a('/api/binance/order',{password:'password-test'})).status,404);
    assert.equal((await a('/api/binance/withdraw',{password:'password-test'})).status,404);
    const after=(await a('/api/session')).data;
    assert.deepEqual(before.trading,after.trading); assert.deepEqual(before.civic,after.civic);
    assert.equal((await a('/api/binance/disconnect',{password:'password-test'})).status,200);
    assert.equal((await a('/api/binance/status')).data.connected,false);
    assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM empire_binance_audit').get()!.n,3);
    assert.ok(!calls.some(p=>p.includes('order')||p.includes('withdraw')));
  } finally { globalThis.fetch=oldFetch; sqlite.close(); }
});
