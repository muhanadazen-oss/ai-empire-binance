import { DatabaseSync } from "node:sqlite";
import { readdirSync, readFileSync } from 'node:fs';
import type { DB, Statement } from "../server/db.ts";
export function sqliteDB(path = ":memory:") {
  const sqlite = new DatabaseSync(path);
  sqlite.exec("PRAGMA foreign_keys=ON");
  // Local adapter mirrors production's additive, versioned D1 migrations.
  sqlite.exec('CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY)');
  const directory = new URL('../drizzle/', import.meta.url);
  for (const name of readdirSync(directory).filter(n => n.endsWith('.sql')).sort()) {
    if (!sqlite.prepare('SELECT name FROM local_migrations WHERE name=?').get(name)) {
      sqlite.exec('BEGIN');
      try {
        sqlite.exec(readFileSync(new URL(name, directory), 'utf8'));
        sqlite.prepare('INSERT INTO local_migrations(name) VALUES(?)').run(name);
        sqlite.exec('COMMIT');
      } catch(e) { sqlite.exec('ROLLBACK'); throw e; }
    }
  }
  class Query implements Statement {
    sql: string;
    params: unknown[];
    constructor(sql: string, params: unknown[] = []) {
      this.sql = sql;
      this.params = params;
    }
    bind(...values: unknown[]) {
      return new Query(this.sql, values);
    }
    async first<T>() {
      return (sqlite.prepare(this.sql).get(...(this.params as any[])) ??
        null) as T | null;
    }
    async all<T>() {
      return {
        results: sqlite.prepare(this.sql).all(...(this.params as any[])) as T[],
      };
    }
    async run() {
      return this.execute();
    }
    execute() {
      const r = sqlite.prepare(this.sql).run(...(this.params as any[]));
      return { meta: { changes: Number(r.changes) } };
    }
  }
  const db: DB = {
    prepare: (sql) => new Query(sql),
    async batch(statements) {
      sqlite.exec("BEGIN IMMEDIATE");
      try {
        const r = statements.map((s) => (s as Query).execute());
        sqlite.exec("COMMIT");
        return r;
      } catch (e) {
        sqlite.exec("ROLLBACK");
        throw e;
      }
    },
  };
  return { db, sqlite };
}
