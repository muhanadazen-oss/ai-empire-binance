import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {devServer} from '../scripts/dev-server.ts';
const original=globalThis.fetch;
let broadcast=0,confirmed=false,lastHash='';
globalThis.fetch=async(input,init)=>{
 const url=String(input);
 if(url==='https://bsc-dataseed.bnbchain.org'){
  const p=JSON.parse(init.body);let result;
  if(p.method==='eth_chainId')result='0x38';
  else if(p.method==='eth_getBalance')result='0xde0b6b3a7640000';
  else if(p.method==='eth_gasPrice')result='0x3b9aca00';
  else if(p.method==='eth_estimateGas')result='0xc350';
  else if(p.method==='eth_getTransactionCount')result='0x0';
  else if(p.method==='eth_blockNumber')result='0x30';
  else if(p.method==='eth_call'){const d=p.params[0].data;result='0x'+(d.startsWith('0x313ce567')?18n:d.startsWith('0x70a08231')?40n*10n**18n:1n).toString(16).padStart(64,'0');}
  else if(p.method==='eth_sendRawTransaction'){broadcast++;throw Error('network lost');}
  else if(p.method==='eth_getTransactionReceipt')result=confirmed?{transactionHash:p.params[0],blockNumber:'0x10',status:'0x1'}:null;
  else throw Error('Unhandled '+p.method);
  return Response.json({jsonrpc:'2.0',id:1,result});
 }
 if(url.startsWith('https://www.coindesk.com/arc/outboundfeeds/rss'))return new Response(`<rss><channel><item><title>Bitcoin bullish breakout</title><link>https://www.coindesk.com/markets/sample</link><pubDate>${new Date(Date.now()-3600000).toUTCString()}</pubDate></item></channel></rss>`);
 if(url.startsWith('https://data-api.binance.vision')){const now=Math.floor(Date.now()/3600000)*3600000;return Response.json(Array.from({length:100},(_,i)=>{const start=now-(100-i)*3600000,p=100+i/5;return[start,String(p),String(p+1),String(p-1),String(p+.1),String(i===99?150:100),start+3599999];}));}
 return original(input,init);
};
const {server,sqlite}=await devServer({port:5183});
const browser=await chromium.launch({executablePath:'/tmp/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto('http://127.0.0.1:5183/#wallet');await page.getByRole('heading',{name:'أول خطوة: تسجيل الدخول'}).waitFor();
 const register=await page.request.post('http://127.0.0.1:5183/api/auth/register',{headers:{Origin:'http://127.0.0.1:5183'},data:{email:'browser@wallet.example',name:'مهند',password:'strong-game-password'}});assert.equal(register.status(),200);
 await page.reload();await page.getByRole('heading',{name:'إنشاء محفظتك',exact:true}).waitFor();
 await page.getByLabel('كلمة مرور خاصة للمحفظة (12 حرفًا على الأقل)').fill('strong-wallet-password');await page.getByLabel('كرر كلمة مرور المحفظة').fill('strong-wallet-password');await page.getByRole('button',{name:'إنشاء المحفظة',exact:true}).click();
 await page.getByRole('heading',{name:'احفظ النسخة الاحتياطية'}).waitFor();assert.ok(await page.getByRole('button',{name:'تفعيل المحفظة في اللعبة'}).isDisabled());
 const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'تحميل النسخة الاحتياطية المشفّرة'}).click();const file=await downloadPromise;assert.ok(file.suggestedFilename().endsWith('.json'));
 await page.getByRole('checkbox',{name:'حفظت الملف وكلمة المرور في مكان آمن'}).check();await page.getByRole('button',{name:'تفعيل المحفظة في اللعبة'}).click();
 await page.getByText('40 USDT',{exact:true}).waitFor();assert.equal(broadcast,0);
 assert.ok(sqlite.prepare('SELECT vault FROM empire_wallets').get());assert.equal(await page.evaluate(()=>localStorage.length),0);
 await page.getByLabel('كلمة مرور المحفظة',{exact:true}).fill('wrong-wallet-password');await page.getByRole('button',{name:'فتح المحفظة للإرسال'}).click();await page.getByText('كلمة مرور المحفظة غير صحيحة، أو النسخة الاحتياطية تالفة.').waitFor();
 await page.getByLabel('كلمة مرور المحفظة',{exact:true}).fill('strong-wallet-password');await page.getByRole('button',{name:'فتح المحفظة للإرسال'}).click();await page.getByRole('button',{name:'قفل المحفظة',exact:true}).waitFor();
 await page.getByLabel('عنوان إيداع Binance',{exact:true}).fill('0x2222222222222222222222222222222222222222');await page.getByLabel('المبلغ USDT',{exact:true}).fill('41');await page.getByRole('button',{name:'مراجعة المبلغ والرسوم'}).click();await page.getByText('رصيد USDT غير كافٍ.').waitFor();
 await page.getByLabel('المبلغ USDT',{exact:true}).fill('1.5');await page.getByRole('button',{name:'مراجعة المبلغ والرسوم'}).click();await page.getByRole('heading',{name:'تأكيد إرسال حقيقي'}).waitFor();assert.equal(broadcast,0);assert.ok(await page.getByRole('button',{name:'تأكيد وإرسال USDT'}).isDisabled());
 await page.getByRole('checkbox',{name:'تأكدت من عنوان إيداع Binance وشبكة BEP20 والمبلغ'}).check();await page.getByRole('button',{name:'تأكيد وإرسال USDT'}).click();await page.getByText('الإرسال محفوظ، لكن البث غير محسوم.',{exact:false}).waitFor();assert.equal(broadcast,1);lastHash=sqlite.prepare('SELECT hash FROM empire_wallet_transfers').get().hash;
 await page.reload();await page.getByRole('button',{name:'فحص التأكيدات'}).waitFor();assert.ok(await page.getByRole('button',{name:'مراجعة المبلغ والرسوم'}).isDisabled());assert.ok(await page.getByRole('button',{name:'فتح المحفظة للإرسال'}).isVisible());
 confirmed=true;await page.getByRole('button',{name:'فحص التأكيدات'}).click();await page.getByText('تأكد التحويل على الشبكة.',{exact:false}).waitFor();assert.equal(broadcast,1);assert.equal(sqlite.prepare('SELECT status FROM empire_wallet_transfers WHERE hash=?').get(lastHash).status,'confirmed');
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'/tmp/embedded-wallet-mobile.png',fullPage:true});
 await page.goto('http://127.0.0.1:5183/#research');await page.getByRole('button',{name:'ابدأ بحثًا وفحصًا جديدًا'}).click();await page.getByRole('heading',{name:'Bitcoin bullish breakout'}).waitFor();await page.getByText('رائد: رفض — RSI بين 45 و65؛ تجنّب التشبع.').waitFor();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'/tmp/research-mobile.png',fullPage:true});assert.deepEqual(errors,[]);
 console.log('Mobile create/backup/unlock/real amount/review/pending persistence/confirmation/research checks passed; no real funds moved.');
}finally{await browser.close();await server.close();globalThis.fetch=original;}
