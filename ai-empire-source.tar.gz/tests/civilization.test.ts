import test from "node:test";
import assert from "node:assert/strict";
import { initialCivilization } from "../src/civilization/initial.ts";
import { advanceDays, clockTick } from "../src/civilization/clock.ts";
import { applyCivicAction } from "../src/civilization/engine.ts";
import { age, account } from "../src/civilization/shared.ts";
import { totalBalances, transfer } from "../src/civilization/economy.ts";
import { child } from "../src/civilization/population.ts";
import { enroll } from "../src/civilization/education.ts";
test("starts with ten varied adults and segregated integer currency", () => {
  const s = initialCivilization();
  assert.equal(s.people.length, 10);
  assert.ok(s.people.every((p) => age(s, p) >= 18));
  assert.equal(totalBalances(s), s.totalMoney);
  assert.equal(s.families.length, 0);
  assert.equal(s.clock.running, false);
});
test("full rule-driven lifecycle: acquaintance -> mutual marriage -> child -> school -> training -> adult job", () => {
  let s = initialCivilization();
  let firstChild: string | undefined;
  let reached = false;
  for (let i = 0; i < 50; i++) {
    s = advanceDays(s, 90);
    assert.equal(totalBalances(s), s.totalMoney);
    assert.ok(
      Object.values(s.balances).every((v) => Number.isSafeInteger(v) && v >= 0),
    );
    const children = s.people.filter((p) => p.generation === 2);
    if (!firstChild && children.length) firstChild = children[0].id;
    if (
      children.some(
        (p) =>
          age(s, p) >= 18 &&
          p.schoolDays > 200 &&
          p.trainingDays >= 60 &&
          !!p.job,
      )
    ) {
      reached = true;
      break;
    }
  }
  assert.ok(s.relationships.some((r) => r.friend));
  assert.ok(s.families.length > 0);
  assert.ok(firstChild);
  assert.ok(
    reached,
    "at least one second-generation adult must qualify for and obtain employment",
  );
  const c = s.people.find((p) => p.id === firstChild)!;
  assert.equal(c.parents.length, 2);
  assert.ok(c.schoolDays > 0);
  assert.ok(s.events.length > 0);
  console.log(
    "Lifecycle metrics",
    JSON.stringify({
      day: s.clock.day,
      people: s.people.length,
      families: s.families.length,
      children: s.people.filter((p) => p.generation > 1).length,
      employedChildren: s.people.filter((p) => p.generation > 1 && p.job)
        .length,
    }),
  );
});
test("newborn has zero professional skills and no job; minors cannot enroll early", () => {
  const s = initialCivilization();
  s.people[0].partner = "p2";
  s.people[1].partner = "p1";
  s.people[0].family = "f";
  s.people[1].family = "f";
  s.families = [
    {
      id: "f",
      parents: ["p1", "p2"],
      children: [],
      marriedDay: 0,
      home: "home-11",
      planning: true,
      nextBirthDay: 60,
    },
  ];
  s.homes[10].residents = ["p1", "p2"];
  s.clock.day = 90;
  assert.ok(child(s, "f"));
  const p = s.people.at(-1)!;
  assert.ok(Object.values(p.skills).every((v) => v === 0));
  assert.equal(p.job, undefined);
  assert.equal(enroll(s, p, "programming"), false);
  assert.equal(child(s, "f"), false);
});
test("optional birth veto, housing and population limits enforced", () => {
  const s = initialCivilization();
  s.policy.birthsAllowed = false;
  assert.equal(child(s, "unknown"), false);
  assert.throws(() =>
    applyCivicAction(s, { type: "policy", values: { populationCap: 5 } }),
  );
  assert.throws(() =>
    applyCivicAction(s, { type: "support", person: "p1", amount: -1 }),
  );
});
test("time acceleration processes identical economic days with no skipped/doubled pay", () => {
  let fast = initialCivilization(),
    slow = initialCivilization();
  fast.clock.running = true;
  slow.clock.running = true;
  fast.clock.speed = 10;
  for (let i = 0; i < 4; i++) fast = clockTick(fast);
  for (let i = 0; i < 40; i++) slow = clockTick(slow);
  assert.equal(fast.clock.day, slow.clock.day);
  assert.deepEqual(fast.balances, slow.balances);
  const ids = fast.ledger.map((t) => t.id);
  assert.equal(new Set(ids).size, ids.length);
  assert.equal(totalBalances(fast), fast.totalMoney);
});
test("insufficient funds never create currency; replayed transaction id has no effect", () => {
  const s = initialCivilization();
  assert.equal(
    transfer(s, "treasury", account("p1"), s.totalMoney, "invalid"),
    false,
  );
  assert.ok(
    transfer(s, "treasury", account("p1"), 1000, "support", "same-key"),
  );
  assert.equal(
    transfer(s, "treasury", account("p1"), 1000, "support", "same-key"),
    false,
  );
  assert.equal(totalBalances(s), s.totalMoney);
});
test("serialization preserves ages, skills, relationships and families exactly", () => {
  const s = advanceDays(initialCivilization(), 900),
    saved = JSON.parse(JSON.stringify(s));
  assert.equal(JSON.stringify(saved), JSON.stringify(s));
  assert.equal(
    JSON.stringify(advanceDays(saved, 120)),
    JSON.stringify(advanceDays(s, 120)),
  );
  assert.equal(totalBalances(saved), saved.totalMoney);
});
