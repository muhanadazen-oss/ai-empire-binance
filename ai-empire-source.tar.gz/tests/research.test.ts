import test from 'node:test';
import assert from 'node:assert/strict';
import {analyseCandles,parseIdeas,reviewIdea} from '../server/research.ts';
const now=Date.UTC(2026,9,3,3),hour=3600000;
const candles=()=>Array.from({length:100},(_,i)=>{const start=now-(100-i)*hour,p=100+i/5;return [start,String(p),String(p+1),String(p-1),String(p+.1),String(i===99?150:100),start+hour-1];});
test('research filters old/future, spoofed hosts, duplicate and neutral headlines',()=>{
 const item=(title:string,link:string,date:number)=>`<item><title><![CDATA[${title}]]></title><link>${link}</link><pubDate>${new Date(date).toUTCString()}</pubDate></item>`;
 const xml=item('Bitcoin bullish breakout','https://www.coindesk.com/markets/a',now-hour)+item('Bitcoin bearish','https://www.coindesk.com.evil.test/a',now-hour)+item('Ethereum news','https://www.coindesk.com/b',now-hour)+item('Solana rally','https://www.coindesk.com/old',now-49*hour)+item('Solana rally','https://www.coindesk.com/future',now+hour)+item('Bitcoin bullish breakout','https://www.coindesk.com/markets/a',now-hour);
 const ideas=parseIdeas(xml,now);assert.equal(ideas.length,2);assert.equal(ideas[0].bias,'up');assert.equal(ideas[1].bias,'neutral');
});
test('market analysis requires recent closed contiguous valid candles and rejects bad data',()=>{
 const data=candles();const evidence=analyseCandles(data,now);assert.ok(evidence.price>0);assert.equal(evidence.closedAt,new Date(now-1).toISOString());
 assert.throws(()=>analyseCandles(data,now+2*hour),/قديمة/);
 assert.throws(()=>analyseCandles(data.slice(0,40),now),/كافية/);
 const gap=candles();gap.splice(70,1);assert.throws(()=>analyseCandles(gap,now),/متسقة/);
 const invalid=candles();invalid[99][2]='NaN';assert.throws(()=>analyseCandles(invalid,now));
});
test('second review cannot execute real trades; rejects missing data, bearish ideas and failed rules',()=>{
 const idea={title:'Bitcoin bullish',url:'https://www.coindesk.com/a',publishedAt:new Date(now-hour).toISOString(),asset:'BTC',bias:'up'} as const;
 assert.equal(reviewIdea(idea,undefined,'قديم').decision,'rejected');
 const evidence={price:110,sma20:105,sma50:100,rsi:55,atr:1,volumeRatio:1.2,closedAt:new Date(now-1).toISOString()};
 const accepted=reviewIdea(idea,evidence);assert.equal(accepted.decision,'reviewed');assert.equal(accepted.plan!.rewardRisk,2);assert.match(accepted.trader.at(-1)!,/موقوف/);
 assert.equal(reviewIdea({...idea,bias:'down'},evidence).decision,'rejected');assert.equal(reviewIdea(idea,{...evidence,rsi:90}).decision,'rejected');assert.equal(reviewIdea({...idea,bias:'neutral'},evidence).decision,'watch');
});
