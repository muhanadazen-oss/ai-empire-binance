import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState} from '../src/engine/game.ts';
import {capitalPlan} from '../src/integration/capital-plan.ts';
import {trainAcademy,LESSONS,checkLesson} from '../src/engine/academy.ts';
test('capital sizing rejects invalid inputs and respects reserve, allocation and planned loss without spending',()=>{
 for(const args of [[0,100,95],[40,100,100],[40,100,101],[NaN,100,95],[40,-1,95]])assert.equal(capitalPlan(...args as [number,number,number]),null);
 for(const b of [.01,1,10,40,1000])for(const stop of [1,50,95,99]){const p=capitalPlan(b,100,stop);if(p){assert.ok(p.amount<=b*.05);assert.ok(p.plannedLoss<=b*.01+1e-10);assert.ok(p.reserve>=b*.95-1e-10);}}
 assert.equal(capitalPlan(40,100,95,40),null);assert.equal(capitalPlan(40,100,95)!.amount,2);
});
test('school persists rule results while preserving capital, trades, civic economy and previous history',()=>{
 let s=initialState(42);const original=structuredClone(s);
 for(const lesson of LESSONS){assert.deepEqual(checkLesson(lesson.id),{tests:3,passed:3});s=trainAcademy(s,lesson.id);}
 assert.equal(s.academy!.completed.length,6);assert.equal(s.academy!.passed,18);assert.equal(s.cash,original.cash);assert.equal(s.capital,original.capital);assert.deepEqual(s.open,original.open);assert.deepEqual(s.closed,original.closed);assert.equal(original.academy,undefined);
 const xp=s.agents.find(a=>a.id==='risk')!.xp;s=trainAcademy(s,'capital');assert.equal(s.academy!.completed.length,6);assert.equal(s.agents.find(a=>a.id==='risk')!.xp,xp);assert.equal(s.cash,original.cash);
});
