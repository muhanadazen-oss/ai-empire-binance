import test from 'node:test';
import assert from 'node:assert/strict';
import {TradingRuntime,activationReasons} from '../trading/runtime.ts';
import {TradingStore,type LiveState} from '../trading/store.ts';
import {newPortfolio,POLICY_ID,type Filters,type Signal} from '../trading/core.ts';
import {ExchangeFailure,type Fill} from '../trading/binance-spot.ts';
const f:Filters={step:'0.01',tick:'0.01',minQty:.01,maxQty:1000,minNotional:5,maxNotional:1e8,marketStep:'0.01',marketMinQty:.01,marketMaxQty:1000,oco:true};
const ids={buy:'emp-b-12345678901234567890',list:'emp-l-12345678901234567890',above:'emp-t-12345678901234567890',below:'emp-s-12345678901234567890'};
const signal:Signal={enter:true,exit:false,score:85,stopPct:.02,reason:'test',at:1000};
const buy:Fill={orderId:1,clientId:ids.buy,side:'BUY',quantity:1,baseSpent:1,netBase:1,quote:100,quoteFee:.1,otherFee:0,fees:.1,price:100,at:2000,status:'FILLED',commissions:[{asset:'USDT',amount:.1,valueUSDT:.1}]};
class FakeBroker {
 protects=0;sells=0;buys=0;cancel=0;stopFilled=false;protectionFailure=false;unknownBuy=false;unknownClose=false;closeId='';
 async verify(ip:string){return {checkedAt:Date.now(),ip,ipRestricted:true,spotOnly:true,takerFee:.001};}
 async order(id:string):Promise<any>{if(id===ids.buy)return this.unknownBuy?null:{...buy,clientOrderId:id,executedQty:'1',cummulativeQuoteQty:'100'};if(id===ids.below)return this.protects?{orderId:2,clientOrderId:id,symbol:'BTCUSDT',side:'SELL',type:'STOP_LOSS',origQty:'1',stopPrice:'98',executedQty:this.stopFilled?'1':'0',status:this.stopFilled?'FILLED':'NEW'}:null;if(id===ids.above)return {orderId:3,executedQty:'0',status:'CANCELED'};if(id===this.closeId)return this.unknownClose?null:{orderId:4,clientOrderId:id,executedQty:'1',side:'SELL',status:'FILLED'};return null;}
 async orderList(){return this.protects?{listOrderStatus:this.stopFilled?'ALL_DONE':'EXECUTING'}:null;}
 async protect(){this.protects++;if(this.protectionFailure){this.protects--;throw new ExchangeFailure(400,-2010,false);}return {};}
 async fill(order:any):Promise<Fill>{if(order.orderId===1)return buy;return {...buy,orderId:order.orderId,clientId:order.clientOrderId,side:'SELL',quote:98,quoteFee:.098,fees:.098,price:98,at:3000};}
 async cancelProtection(){this.cancel++;this.stopFilled=true;}
 async sell(id:string){this.sells++;this.closeId=id;return {orderId:4};}
 async buy(){this.buys++;return {};}
 async account(){return {balances:[{asset:'BTC',free:'0',locked:'1'},{asset:'USDT',free:'899.9',locked:'0'}]};}
}
function setup(broker=new FakeBroker()) {
 const store=new TradingStore(':memory:'),r=new TradingRuntime(store,{evidenceDirectory:'/tmp/autotrader-test',expectedIp:'192.0.2.10'},broker as any);
 r.state.capital=1000;r.state.filters=f;r.state.phase='live';r.state.lastPrice=100;
 r.state.live={startedAt:2000,portfolio:newPortfolio(1000,2000),shadow:newPortfolio(1000,2000),intent:{kind:'buy',ids,closeId:null,signal,attemptedAt:2000,orderId:null,reason:'entry',flatten:false},ids:null,protected:false,accountedOrders:[],fills:[],lastSeenSignal:0,closeReason:null,totalFees:0,baselineQuote:1000,riskNoticeDay:null};r.persist();return {r,store,broker};
}
test('manual acknowledgement cannot bypass missing capital, losing backtest, paper or notification proof',async()=>{
 const store=new TradingStore(':memory:'),r=new TradingRuntime(store,{evidenceDirectory:'/tmp/autotrader-test'},null);
 assert.ok(activationReasons(r.state,Date.now(),false).length>=5);
 await assert.rejects(()=>r.activate('ACTIVATE_LIVE'));assert.equal(r.state.live,null);
 await assert.rejects(()=>r.configure('100'));await r.configure(100);assert.equal(r.state.capital,100);
 r.state.paper={startedAt:Date.now(),lastHeartbeat:Date.now(),observedMs:0,missedMs:0,invalid:false,invalidReason:null,policyId:POLICY_ID,portfolio:newPortfolio(100,Date.now()),lastPrice:100};
 await assert.rejects(()=>r.configure(200));assert.equal(r.state.capital,100);store.close();
});
test('a recovered accepted buy is accounted once and protected without sending a second buy',async()=>{
 const {r,broker,store}=setup();await r.reconcile();assert.equal(broker.buys,0);assert.equal(broker.protects,1);assert.equal(r.state.live!.protected,true);
 assert.equal(r.state.live!.portfolio.cash,899.9);assert.equal(r.state.live!.totalFees,.1);
 const restarted=new TradingRuntime(store,{evidenceDirectory:'/tmp/autotrader-test',expectedIp:'192.0.2.10'},broker as any);await restarted.reconcile();
 assert.equal(broker.buys,0);assert.equal(broker.protects,1);assert.equal(restarted.state.live!.portfolio.cash,899.9);assert.equal(restarted.state.live!.accountedOrders.length,1);store.close();
});
test('an unknown order stays unresolved across restarts rather than repeating a money mutation',async()=>{
 const {r,store,broker}=setup();broker.unknownBuy=true;await assert.rejects(()=>r.reconcile());
 const restarted=new TradingRuntime(store,{evidenceDirectory:'/tmp/autotrader-test'},broker as any);await assert.rejects(()=>restarted.reconcile());
 assert.equal(broker.buys,0);assert.equal(broker.sells,0);assert.equal(restarted.state.live!.intent?.kind,'buy');store.close();
});
test('definitive protection rejection halts and permits a confirmed liquidation attempt',async()=>{
 const {r,store,broker}=setup();broker.protectionFailure=true;await assert.rejects(()=>r.reconcile());assert.equal(r.state.phase,'halted');assert.equal(r.state.live!.intent!.orderId,0);
 await r.closeLive('protection_failed');assert.equal(broker.sells,1);assert.equal(r.state.live!.portfolio.position,null);assert.equal(r.state.live!.portfolio.halted,true);store.close();
});
test('emergency cancellation racing with an already filled stop cannot cause a duplicate sell',async()=>{
 const {r,store,broker}=setup();await r.reconcile();await r.emergency();
 assert.equal(broker.cancel,1);assert.equal(broker.sells,0);assert.equal(r.state.live!.portfolio.position,null);assert.equal(r.state.phase,'halted');assert.equal(r.state.emergency,true);
 assert.ok(Math.abs(r.state.live!.totalFees-.198)<1e-10);assert.ok(Math.abs(r.state.live!.portfolio.trades[0].fees-.198)<1e-10);
 await r.emergency();assert.equal(broker.sells,0);store.close();
});
test('unknown close cannot be resubmitted and emergency remains visible when close fails',async()=>{
 const {r,store,broker}=setup();await r.reconcile();broker.cancelProtection=async()=>{broker.protects=0;};broker.unknownClose=true;
 await assert.rejects(()=>r.emergency());assert.equal(broker.sells,1);assert.equal(r.state.live!.intent?.kind,'close');assert.equal(r.state.emergency,true);
 await assert.rejects(()=>r.closeLive('emergency_stop'));assert.equal(broker.sells,1);assert.ok(r.state.notices.some(n=>n.kind==='emergency_close_pending'));store.close();
});
test('durable revisions reject stale writers before a new order can be sent',()=>{
 const store=new TradingStore(':memory:'),a=store.load(),b=store.load();a.capital=100;store.save(a);b.capital=999;assert.throws(()=>store.save(b));assert.equal(store.load().capital,100);store.close();
});
test('reconciling a stop fill does not skip checking an externally changed USDT balance',async()=>{
 const {r,store,broker}=setup();await r.reconcile();broker.stopFilled=true;
 broker.account=async()=>({balances:[{asset:'BTC',free:'0',locked:'0'},{asset:'USDT',free:'999',locked:'0'}]});
 await assert.rejects(()=>r.verifyManagedBalance(),/USDT/);assert.equal(r.state.live!.portfolio.position,null);assert.equal(broker.sells,0);
 const correct=1000-buy.quote-buy.quoteFee+98-.098;
 broker.account=async()=>({balances:[{asset:'BTC',free:'0',locked:'0'},{asset:'USDT',free:String(correct),locked:'0'}]});
 await r.verifyManagedBalance();assert.equal(r.state.live!.fills.length,2);store.close();
});
