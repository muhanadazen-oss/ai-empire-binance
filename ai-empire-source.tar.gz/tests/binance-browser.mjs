import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { devServer } from '../scripts/dev-server.ts';
const {server}=await devServer({port:5181});
const browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1050}});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
let connected=false;
await page.route('**/api/binance/**',async route=>{
  const path=new URL(route.request().url()).pathname;
  if(path.endsWith('connect') && !path.endsWith('disconnect')) connected=true;
  if(path.endsWith('disconnect')) connected=false;
  await route.fulfill({json:{registered:true,configured:true,connected,liveTrading:false,checkedAt:new Date().toISOString(),balances:connected?[{asset:'USDT',free:'4.46',locked:'0'}]:[]}});
});
try{
  await page.goto('http://127.0.0.1:5181');
  await page.getByRole('button',{name:'ربط Binance',exact:true}).click();
  await page.getByLabel('API Key',{exact:true}).fill('K'.repeat(64));
  await page.getByLabel('API Secret',{exact:true}).fill('S'.repeat(64));
  await page.getByLabel('كلمة مرور حساب اللعبة لتأكيد العملية').fill('test-password');
  await page.getByRole('button',{name:'فحص المفتاح وحفظ الربط',exact:true}).click();
  await page.getByRole('heading',{name:'أرصدة Binance الفعلية'}).waitFor();
  assert.equal(await page.locator('input[type="password"]').inputValue(),'');
  const stored=await page.evaluate(()=>JSON.stringify({...localStorage}));
  assert.ok(!stored.includes('S'.repeat(64)));
  await page.screenshot({path:'artifacts/binance-desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path:'artifacts/binance-mobile.png',fullPage:true});
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
  await page.getByLabel('كلمة مرور حساب اللعبة لتأكيد العملية').fill('test-password');
  await page.getByRole('button',{name:'تحديث الرصيد وفحص الصلاحيات',exact:true}).click();
  await page.getByLabel('كلمة مرور حساب اللعبة لتأكيد العملية').fill('test-password');
  await page.getByRole('button',{name:'فصل وحذف المفاتيح',exact:true}).click();
  await page.getByLabel('API Key',{exact:true}).waitFor();
  assert.deepEqual(errors,[]);
  console.log('Binance UI: desktop/mobile, connect, refresh, disconnect, cleared password and no credential localStorage passed (mock responses).');
}finally{await browser.close();await server.close();}
