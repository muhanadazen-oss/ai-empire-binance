import test from "node:test";
import assert from "node:assert/strict";
import worker from "../server/worker.ts";
import { sqliteDB } from "./sqlite.ts";
import { totalBalances } from "../src/civilization/economy.ts";
import { advanceDays } from "../src/civilization/clock.ts";
import type { Civilization } from "../src/civilization/types.ts";
function client(db: ReturnType<typeof sqliteDB>["db"]) {
  let cookie = "";
  return async (
    path: string,
    body?: unknown,
    origin = "https://empire.test",
  ) => {
    const res = await worker.fetch(
      new Request("https://empire.test" + path, {
        method: body ? "POST" : "GET",
        headers: {
          Cookie: cookie,
          ...(body
            ? { "Content-Type": "application/json", Origin: origin }
            : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      }),
      { DB: db },
    );
    if (res.headers.has("set-cookie"))
      cookie = res.headers.get("set-cookie")!.split(";")[0];
    return {
      status: res.status,
      data: (await res.json()) as any,
      cookie: res.headers.get("set-cookie"),
    };
  };
}
test("server preserves guest progress through registration/login, isolates accounts and forbids CSRF/real money", async () => {
  const { db } = sqliteDB();
  const a = client(db),
    b = client(db);
  let ar = await a("/api/session");
  const aid = ar.data.user.id;
  const br = await b("/api/session");
  assert.notEqual(aid, br.data.user.id);
  assert.match(ar.cookie!, /HttpOnly.*SameSite=Strict.*Secure/);
  const support = { type: "support", person: "p1", amount: 5000 };
  ar = await a("/api/civilization", {
    action: support,
    revision: 0,
    requestId: "support-once",
  });
  assert.equal(ar.data.civic.balances["person:p1"], 305000);
  const again = await a("/api/civilization", {
    action: support,
    revision: 0,
    requestId: "support-once",
  });
  assert.equal(again.data.civic.revision, 1);
  assert.equal(again.data.civic.balances["person:p1"], 305000);
  assert.equal(
    (
      await a("/api/civilization", {
        action: { ...support, amount: 7000 },
        revision: 1,
        requestId: "support-once",
      })
    ).status,
    400,
  );
  assert.equal(
    (await b("/api/session")).data.civic.balances["person:p1"],
    300000,
  );
  assert.equal(
    (
      await a("/api/civilization", {
        action: support,
        revision: 0,
        requestId: "stale-key",
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await a(
        "/api/civilization",
        { action: support, revision: 1, requestId: "csrf-block" },
        "https://evil.test",
      )
    ).status,
    403,
  );
  assert.equal((await a("/api/binance/withdraw", {})).status, 404);
  assert.equal(
    (
      await b("/api/trading", {
        trading: ar.data.trading,
        version: 0,
        userId: aid,
      })
    ).status,
    409,
  );
  const registered = await a("/api/auth/register", {
    email: "founder@example.test",
    name: "المؤسس",
    password: "empire-test-password",
  });
  assert.equal(registered.data.user.id, aid);
  assert.ok(!JSON.stringify(registered.data).includes("password_hash"));
  await a("/api/auth/logout", {});
  assert.equal(
    (await a("/api/session")).data.civic.balances["person:p1"],
    300000,
  );
  const login = await a("/api/auth/login", {
    email: "founder@example.test",
    password: "empire-test-password",
  });
  assert.equal(login.data.user.id, aid);
  assert.equal(login.data.civic.balances["person:p1"], 305000);
  assert.equal(
    (
      await a("/api/auth/login", {
        email: "founder@example.test",
        password: "wrong",
      })
    ).status,
    401,
  );
  const exported = await a("/api/civilization/export");
  assert.equal(exported.data.ledger.length, 2);
  assert.equal(exported.data.ledger[1].amount, 5000);
  assert.equal(totalBalances(login.data.civic), login.data.civic.totalMoney);
});
test("server clock replay, rate limit, salary uniqueness and persisted generation cycle", async () => {
  const { db } = sqliteDB();
  const a = client(db);
  let s = (await a("/api/session")).data;
  const full = advanceDays(s.civic, 2800);
  await db
    .prepare("UPDATE empire_civilizations SET data=? WHERE user_id=?")
    .bind(JSON.stringify(full), s.user.id)
    .run();
  s = (
    await a("/api/civilization", {
      action: { type: "clock", speed: 10, running: true },
      revision: 0,
      requestId: "clock-once",
    })
  ).data;
  s = (
    await a("/api/civilization", {
      action: { type: "step" },
      revision: 1,
      requestId: "tick-once",
    })
  ).data;
  const day = s.civic.clock.day;
  assert.ok(day > 2800);
  assert.equal(
    (
      await a("/api/civilization", {
        action: { type: "step" },
        revision: 1,
        requestId: "tick-once",
      })
    ).data.civic.clock.day,
    day,
  );
  assert.equal(
    (
      await a("/api/civilization", {
        action: { type: "step" },
        revision: s.civic.revision,
        requestId: "tick-too-rapid",
      })
    ).data.civic.clock.day,
    day,
  );
  const saved = (await a("/api/session")).data.civic as Civilization;
  assert.equal(JSON.stringify(saved), JSON.stringify(s.civic));
  assert.ok(
    saved.people.some(
      (p) => p.generation > 1 && p.schoolDays > 0 && p.trainingDays >= 60,
    ),
  );
  const rows = await db
    .prepare(
      "SELECT COUNT(*) AS total,COUNT(DISTINCT entry_id) AS unique_ids FROM empire_ledger",
    )
    .first<any>();
  assert.equal(rows.total, rows.unique_ids);
  assert.equal(totalBalances(saved), saved.totalMoney);
  await db
    .prepare("UPDATE empire_civilizations SET last_tick=0 WHERE user_id=?")
    .bind(s.user.id)
    .run();
  s = (
    await a("/api/civilization", {
      action: { type: "step" },
      revision: s.civic.revision,
      requestId: "tick-next",
    })
  ).data;
  assert.ok(s.civic.clock.day > day);
});
test("legacy trading migration is one-time and does not touch civilization", async () => {
  const { db } = sqliteDB();
  const a = client(db);
  const initial = (await a("/api/session")).data;
  initial.trading.cash = 37;
  initial.trading.xp = 777;
  const migrated = (await a("/api/migrate", { trading: initial.trading })).data;
  assert.equal(migrated.trading.xp, 777);
  assert.equal(migrated.civic.people.length, 10);
  initial.trading.xp = 1;
  assert.equal(
    (await a("/api/migrate", { trading: initial.trading })).data.trading.xp,
    777,
  );
});
