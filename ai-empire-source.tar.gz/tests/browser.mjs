import { chromium } from "playwright";
import assert from "node:assert/strict";
import { devServer } from "../scripts/dev-server.ts";
const { server, db } = await devServer();
const browser = await chromium.launch({
  headless: true,
  ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
    ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH }
    : {}),
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 1050 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:5180");
await page.getByRole("heading", { name: /هنا تُبنى/ }).waitFor();
await page.screenshot({ path: "artifacts/desktop.png", fullPage: true });
assert.equal(
  await page
    .getByRole("button", { name: "إضاءة نهارية", exact: true })
    .getAttribute("aria-pressed"),
  "true",
);
await page.getByRole("button", { name: "إضاءة نهارية", exact: true }).click();
assert.equal(
  await page
    .getByRole("button", { name: "إضاءة نهارية", exact: true })
    .getAttribute("aria-pressed"),
  "true",
);
await page.screenshot({ path: "artifacts/desktop-day.png", fullPage: true });
await page.getByRole("button", { name: "إضاءة ليلية", exact: true }).click();
console.log("Desktop ready");
for (const name of [
  "القصر الرئيسي",
  "البنك",
  "مركز التداول",
  "مركز التحليل",
  "إدارة المخاطر",
  "الخزنة",
  "السوق",
  "مركز العمليات",
]) {
  console.log("Building", name);
  await page.getByRole("button", { name, exact: true }).click();
  await page.getByRole("dialog").waitFor();
  await page.keyboard.press("Escape");
  await page.getByRole("dialog").waitFor({ state: "hidden" });
}
await page
  .getByRole("button", { name: "المهام والإنجازات", exact: true })
  .click();
await page
  .getByRole("button", { name: "استلام المكافأة", exact: true })
  .click();
await page.getByRole("button", { name: "مجلس الوكلاء", exact: true }).click();
assert.equal(await page.locator(".agent-card").count(), 6);
await page.locator(".agent-card").first().click();
await page.getByRole("dialog").waitFor();
await page.keyboard.press("Escape");
await page.getByRole("button", { name: "التداول", exact: true }).click();
await page.getByRole("spinbutton").fill("40");
await page.getByRole("button", { name: "دراسة الفرصة", exact: true }).click();
await page.waitForTimeout(7200);
assert.ok(await page.getByText(/تم رفض الصفقة: تجاوز الحد/).count());
await page.getByRole("button", { name: "التقارير", exact: true }).click();
await page.getByText("قيمة المملكة مع الزمن").waitFor();
await page
  .getByRole("button", { name: "ربط Binance", exact: true })
  .click();
await page.getByText("التداول الحقيقي مقفول", {exact:true}).waitFor();
await page.getByRole("button", {name:"فتح حساب المؤسس"}).waitFor();
await page.getByRole("button", { name: "المملكة", exact: true }).click();
await page
  .getByRole("button", { name: "تشغيل تداول المحاكاة", exact: true })
  .click();
await page.waitForTimeout(2400);
await page.getByRole("button", { name: "إيقاف طوارئ", exact: true }).click();
await page
  .getByRole("button", { name: "استئناف بعد الطوارئ", exact: true })
  .waitFor();
await page.waitForTimeout(1000);
await page.reload();
await page.getByRole("heading", { name: /هنا تُبنى/ }).waitFor();
assert.equal(
  await page
    .getByRole("button", { name: "استئناف بعد الطوارئ", exact: true })
    .count(),
  1,
);
await page.getByRole("button", { name: "التقارير", exact: true }).click();
const [file] = await Promise.all([
  page.waitForEvent("download"),
  page.getByRole("button", { name: "تصدير تقرير CSV", exact: true }).click(),
]);
assert.match(file.suggestedFilename(), /\.csv$/);
await page.getByRole("button", { name: "المملكة", exact: true }).click();

assert.equal(await page.locator(".resident-marker").count(), 10);
await page
  .getByRole("button", { name: "الشخصية آدم سالم", exact: true })
  .click();
await page
  .getByRole("heading", { name: "ذاكرة الحياة", exact: true })
  .waitFor();
await page.keyboard.press("Escape");
for (const name of [
  "السكان",
  "العائلات",
  "شجرة العائلة",
  "التعليم",
  "الوظائف",
  "الشركات",
  "السكن",
  "سياسات المملكة",
]) {
  await page.getByRole("button", { name, exact: true }).click();
  await page.getByRole("heading", { name, exact: true }).waitFor();
}
await page
  .getByRole("spinbutton", { name: "مبلغ الدعم", exact: true })
  .fill("50");
await page
  .getByRole("button", { name: "صرف الدعم وتسجيل مصدره", exact: true })
  .click();
await page.getByText("دعم أسرة بقرار المؤسس", { exact: true }).waitFor();
await page.getByRole("button", { name: "التعليم", exact: true }).click();
await page
  .locator(".service-card")
  .filter({ hasText: "مكتبة المعرفة" })
  .getByRole("button", { name: "بناء الخدمة", exact: true })
  .click();
await page
  .locator(".service-card")
  .filter({ hasText: "مكتبة المعرفة" })
  .getByText("مبني", { exact: true })
  .waitFor();
await page.getByRole("button", { name: "الوظائف", exact: true }).click();
await page.getByRole("button", { name: "إنشاء الوظيفة", exact: true }).click();
await page.waitForTimeout(350);
assert.equal(await page.locator(".job-list>div").count(), 9);
await page.getByRole("button", { name: "السكن", exact: true }).click();
await page.getByRole("button", { name: /بناء مسكن/ }).click();
await page.waitForTimeout(350);
assert.equal(await page.locator(".housing-grid>div").count(), 15);
await page.getByRole("button", { name: "10×", exact: true }).click();
await page.getByRole("button", { name: "تشغيل المجتمع", exact: true }).click();
await page.waitForTimeout(2300);
await page.getByRole("button", { name: "إيقاف المجتمع", exact: true }).click();
const civic = await page.evaluate(async () => {
  return (await (await fetch("/api/session")).json()).civic;
});
assert.ok(civic.clock.day >= 2);
assert.equal(civic.clock.running, false);
await page.reload();
await page.getByRole("heading", { name: /هنا تُبنى/ }).waitFor();
const after = await page.evaluate(async () => {
  return (await (await fetch("/api/session")).json()).civic;
});
assert.equal(after.clock.day, civic.clock.day);
assert.equal(after.homes.length, 15);
assert.ok(after.facilities.find((f) => f.id === "library").built);
await page.getByRole("button", { name: "تسجيل الدخول أو إنشاء حساب", exact: true }).click();
await page.getByRole("button", {name:"إنشاء حساب جديد",exact:true}).click();
await page
  .getByRole("button", { name: "إنشاء الحساب وحفظ التقدم", exact: true })
  .waitFor();
await page.getByRole("button", {name:"المملكة",exact:true}).click();
await page.setViewportSize({ width: 390, height: 844 });
await page.screenshot({ path: "artifacts/mobile.png", fullPage: true });
const width = await page.evaluate(() => ({
  scroll: document.documentElement.scrollWidth,
  client: document.documentElement.clientWidth,
}));
assert.equal(width.scroll, width.client);
await page.getByRole("button", { name: "البنك", exact: true }).click();
await page.getByRole("dialog").waitFor();
await page.screenshot({ path: "artifacts/mobile-bank.png" });
await page.keyboard.press("Escape");
await page.getByRole("button", { name: "التداول", exact: true }).click();
assert.equal(await page.getByRole("spinbutton").count(), 1);
await page.getByRole("button", { name: "السكان", exact: true }).click();
await page.screenshot({
  path: "artifacts/mobile-population.png",
  fullPage: true,
});
const populationWidth = await page.evaluate(() => ({
  scroll: document.documentElement.scrollWidth,
  client: document.documentElement.clientWidth,
}));
assert.equal(populationWidth.scroll, populationWidth.client);
assert.deepEqual(errors, []);
console.log(
  JSON.stringify(
    {
      result: "PASS",
      buildingClicks: 8,
      agentCards: 6,
      riskRejection: true,
      persistence: true,
      export: true,
      mobileOverflow: width,
      consoleErrors: errors,
    },
    null,
    2,
  ),
);
await browser.close();
await server.close();
