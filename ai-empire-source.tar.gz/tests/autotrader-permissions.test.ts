import test from 'node:test';
import assert from 'node:assert/strict';
import {assertSpotPermissions,SpotBroker} from '../trading/binance-spot.ts';
const permission={enableReading:true,ipRestrict:true,enableSpotAndMarginTrading:true,enableWithdrawals:false,enableInternalTransfer:false,permitsUniversalTransfer:false,enableMargin:false,enableFutures:false,enableVanillaOptions:false,enablePortfolioMarginTrading:false,enableFixApiTrade:false,enableFixReadOnly:true};
test('Spot connection fails closed on any forbidden, missing or newly introduced privilege',()=>{
 assert.doesNotThrow(()=>assertSpotPermissions(permission));
 for(const key of ['enableWithdrawals','enableInternalTransfer','permitsUniversalTransfer','enableMargin','enableFutures','enableVanillaOptions','enablePortfolioMarginTrading','enableFixApiTrade']){assert.throws(()=>assertSpotPermissions({...permission,[key]:true}));const p={...permission} as any;delete p[key];assert.throws(()=>assertSpotPermissions(p));}
 for(const key of ['enableReading','ipRestrict','enableSpotAndMarginTrading'])assert.throws(()=>assertSpotPermissions({...permission,[key]:false}));
 assert.throws(()=>assertSpotPermissions({...permission,enableNewTransfers:true}));
});
test('unverified and withdrawal-enabled keys cannot send any trade request, even if a caller tries directly',async()=>{
 const calls:{method:string;url:string}[]=[];
 const fetcher:typeof fetch=async(url,init)=>{calls.push({method:init?.method??'GET',url:String(url)});return Response.json(String(url).includes('ipify')?{ip:'192.0.2.10'}:String(url).includes('/time')?{serverTime:Date.now()}:{...permission,enableWithdrawals:true});};
 const b=new SpotBroker('k'.repeat(64),'s'.repeat(64),fetcher);
 const f={step:'0.001',tick:'0.01',minQty:.001,maxQty:1000,minNotional:5,maxNotional:1e6,marketStep:'0.001',marketMinQty:.001,marketMaxQty:1000,oco:true};
 await assert.rejects(()=>b.buy('emp-b-12345678901234567890',100,100,f));assert.equal(calls.length,0);
 await assert.rejects(()=>b.verify('192.0.2.10'));await assert.rejects(()=>b.sell('emp-c-12345678901234567890',1,f));assert.ok(calls.every(c=>c.method==='GET'));
});
test('a different observed server IP blocks signed API use rather than trusting a configured string',async()=>{
 let calls=0;const b=new SpotBroker('k'.repeat(64),'s'.repeat(64),async()=>{calls++;return Response.json({ip:'192.0.2.11'});});
 await assert.rejects(()=>b.verify('192.0.2.10'));assert.equal(calls,1);
});
