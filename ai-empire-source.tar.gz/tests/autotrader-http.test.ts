import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomBytes } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { tradingHttpServer } from '../trading/http.ts';
import { TradingRuntime } from '../trading/runtime.ts';
import { TradingStore } from '../trading/store.ts';
import { tradingProcessLock } from '../trading/process-lock.ts';

async function fixture(t:any) {
  const store=new TradingStore(':memory:'),runtime=new TradingRuntime(store,{evidenceDirectory:'/tmp/empire-http-test'},null);
  const token=randomBytes(32).toString('hex'),server=tradingHttpServer(runtime,token);
  server.listen(0,'127.0.0.1');await once(server,'listening');
  const address=server.address();if(!address||typeof address==='string')throw new Error('No HTTP listener');
  t.after(async()=>{server.closeAllConnections();await new Promise<void>(done=>server.close(()=>done()));store.close();});
  const url=`http://127.0.0.1:${address.port}`;
  const call=async(path:string,body?:unknown,authorized=true,marker=true)=>{
    const response=await fetch(url+path,{method:body===undefined?'GET':'POST',headers:{...(authorized?{Authorization:`Bearer ${token}`}:{ }),...(body!==undefined?{'Content-Type':'application/json',...(marker?{'X-Empire-Action-Origin':'user-click'}:{})}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});
    return {status:response.status,data:await response.json() as any};
  };
  return {store,runtime,token,url,call};
}
test('deployment liveness is public but account data always needs the service token',async t=>{
  const f=await fixture(t);
  assert.deepEqual((await f.call('/healthz',undefined,false)).data,{ok:true,service:'ai-empire-trading'});
  assert.equal((await f.call('/v1/status',undefined,false)).status,401);
  const wrong=await fetch(f.url+'/v1/status',{headers:{Authorization:'Bearer wrong'}});assert.equal(wrong.status,401);
  const status=await f.call('/v1/status');assert.equal(status.status,200);assert.equal(status.data.capital,null);assert.equal(status.data.canActivate,false);
  assert.ok(!JSON.stringify(status.data).includes(f.token));assert.equal(f.runtime.state.live,null);
});
test('HTTP controls reject missing user intent, forged proof and withdrawal paths',async t=>{
  const f=await fixture(t);
  assert.equal((await f.call('/v1/configure',{capital:40},true,false)).status,403);
  assert.equal((await f.call('/v1/configure',{capital:40})).status,200);assert.equal(f.store.load().capital,40);
  assert.equal((await f.call('/v1/activate',{ack:'ACTIVATE_LIVE',passed:true,paperDays:60})).status,400);
  assert.equal((await f.call('/v1/withdraw',{amount:10,address:'fake'})).status,404);
  assert.equal((await f.call('/v1/transfer',{amount:10})).status,404);
  assert.equal(f.store.load().live,null);assert.equal(f.store.load().paper,null);
});
test('malformed and oversized Unicode bodies cannot mutate persisted capital',async t=>{
  const f=await fixture(t);
  for(const body of [null,[],{capital:100,padding:'أ'.repeat(6000)}]){
    const result=await f.call('/v1/configure',body);assert.ok([400,413].includes(result.status));assert.equal(f.store.load().capital,null);
  }
  const result=await fetch(f.url+'/v1/configure',{method:'POST',headers:{Authorization:`Bearer ${f.token}`,'X-Empire-Action-Origin':'user-click','Content-Type':'application/json'},body:'{broken'});
  assert.equal(result.status,400);assert.equal(f.store.load().capital,null);
});
test('queued backtests reserve the chosen cap before a busy loop can run the job',async t=>{
  const f=await fixture(t);assert.equal((await f.call('/v1/backtest',{})).status,400);
  await f.runtime.configure(100);
  let release:()=>void=()=>{};
  const barrier=f.runtime.serial(()=>new Promise<void>(resolve=>{release=resolve;}));await Promise.resolve();
  t.mock.method(globalThis,'fetch',async()=>{throw new Error('offline_test');});
  f.runtime.queueHistory();assert.equal(f.runtime.state.job?.kind,'backtest');
  assert.throws(()=>f.runtime.queueHistory());await assert.rejects(()=>f.runtime.configure(200));assert.equal(f.runtime.state.capital,100);
  release();await barrier;await f.runtime.serial(async()=>{});
  assert.equal(f.runtime.state.job,null);assert.equal(f.runtime.state.live,null);assert.equal(f.runtime.state.capital,100);assert.equal(f.runtime.state.error,'offline_test');
});
test('exclusive trading lock prevents two writers and can reopen without trusting old PIDs',()=>{
  const directory=mkdtempSync(join(tmpdir(),'empire-process-lock-')),path=join(directory,'lock.sqlite');
  const release=tradingProcessLock(path);
  try{assert.throws(()=>tradingProcessLock(path));release();release();const reopened=tradingProcessLock(path);assert.throws(()=>tradingProcessLock(path));reopened();}
  finally{release();rmSync(directory,{recursive:true,force:true});}
});
