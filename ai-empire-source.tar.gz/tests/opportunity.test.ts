import test from 'node:test';
import assert from 'node:assert/strict';
import {assignAgentRoles,checkRisk,closeTrade,initialState,scanOpportunities,startCouncil,tick,pause,STRATEGIES} from '../src/engine/game.ts';
import {evaluateOpportunity} from '../src/engine/opportunity.ts';
import {strongMarket} from './opportunity-fixture.ts';

test('75% score is enforced for every strategy and invalid scores never pass',()=>{
 for(const strategy of Object.keys(STRATEGIES)){
  const s=strongMarket(initialState());s.strategy=strategy as typeof s.strategy;
  for(const confidence of [.749999,NaN,Infinity,-1,1.01])assert.equal(checkRisk(s,{symbol:'BTC',amount:1,confidence}).ok,false);
  assert.equal(checkRisk(s,{symbol:'BTC',amount:1,confidence:.75}).ok,true);
 }
});
test('rule scores use prices, not seeded random confidence; malformed data fails closed',()=>{
 const s=strongMarket(initialState(6)),a=s.assets[0];
 assert.equal(evaluateOpportunity(a).score,100);
 assert.deepEqual(evaluateOpportunity(a),evaluateOpportunity(strongMarket(initialState(999)).assets[0]));
 assert.equal(evaluateOpportunity(initialState().assets[0]).eligible,false);
 for(const history of [[],[1,2],Array(35).fill(NaN),Array(35).fill(0)])assert.equal(evaluateOpportunity({...a,history}).score,0);
 assert.equal(evaluateOpportunity({...a,price:Infinity}).eligible,false);
});
test('scout rejects weaker assets, routes the qualified opportunity to director without spending, and keeps searching',()=>{
 let s=strongMarket(initialState());s.assets[0]=initialState().assets[0];
 const before=s.cash;s=scanOpportunities(s);
 assert.equal(s.council?.symbol,'ETH');assert.equal(s.cash,before);assert.equal(s.open.length,0);
 assert.equal(s.opportunitySearch?.candidates.length,3);
 assert.ok(s.logs.some(l=>l.actor==='كشاف الفرص'&&l.text.includes('آدم')));
 const none=scanOpportunities(initialState());assert.equal(none.council,null);assert.equal(none.cash,40);
 assert.match(none.agents.find(a=>a.id==='scout')!.status,/أواصل البحث/);
});
test('executor cannot spend before director approval, rechecks fresh market and rejects invalidated approval',()=>{
 let s=startCouncil(strongMarket(initialState()),'BTC',5);
 for(let i=0;i<7;i++){s=tick(s);assert.equal(s.open.length,0);assert.equal(s.cash,40);}
 assert.equal(s.council?.approved,true);assert.equal(s.council?.messages.at(-1)?.agent,'director');
 s.assets[0].history=Array(35).fill(s.assets[0].price);s=tick(s);
 assert.equal(s.open.length,0);assert.equal(s.rejected,1);assert.equal(s.lastCouncil.at(-1)?.agent,'executor');
 assert.equal(s.cash,40);
});
test('executor reacts to stops and targets on the next cycle and closes exactly once',()=>{
 for(const factor of [.97,1.04]){
  let s=startCouncil(strongMarket(initialState()),'BTC',5);for(let i=0;i<8;i++)s=tick(s);
  const t=s.open[0];assert.equal(t.openedBy,'executor');assert.ok(t.opportunityScore!>=75);
  s.assets[0].price=t.entry*factor;s.running=true;s.ticks=3;s=tick(s);
  assert.equal(s.open.length,0);assert.equal(s.closed.length,1);assert.equal(s.closed[0].closedBy,'executor');
  assert.equal(s.executionWatch?.automaticClosures,1);const cash=s.cash;s=pause(s);assert.equal(tick(s).cash,cash);
 }
});
test('executor exits a confirmed reversal within stop/target bounds',()=>{
 let s=startCouncil(strongMarket(initialState()),'BTC',5);for(let i=0;i<8;i++)s=tick(s);
 const t=s.open[0],a=s.assets[0];a.history=Array.from({length:35},(_,i)=>t.entry*(1.015-i*.0005));a.price=t.entry*.995;
 assert.ok(a.price>t.stopLoss&&a.price<t.takeProfit);s.running=true;s.ticks=3;s=tick(s);
 assert.equal(s.closed[0]?.reason,'انعكاس اتجاه السوق');assert.equal(s.closed[0]?.closedBy,'executor');
});
test('legacy six-agent kingdom adds employees idempotently without changing capital, positions or history',()=>{
 const s=initialState();s.agents=s.agents.slice(0,6);s.cash=37;s.xp=777;s.agents[0].history=['قرار سابق'];
 const before={cash:s.cash,xp:s.xp,open:s.open,closed:s.closed,history:s.agents[0].history};assignAgentRoles(s);
 assert.equal(s.agents.length,8);assignAgentRoles(s);assert.equal(new Set(s.agents.map(a=>a.id)).size,8);
 assert.equal(s.cash,before.cash);assert.equal(s.xp,before.xp);assert.deepEqual(s.open,before.open);assert.deepEqual(s.closed,before.closed);assert.deepEqual(s.agents[0].history,before.history);
 assert.equal(s.agents.filter(a=>/الوحيدة/.test(a.skill)).length,1);
});

test('legacy positions can still close through the new executor without resetting the kingdom',()=>{
 let s=startCouncil(strongMarket(initialState()),'BTC',5);for(let i=0;i<8;i++)s=tick(s);
 const t=s.open[0];s.agents=s.agents.slice(0,6);s=closeTrade(s,t.id);
 assert.equal(s.agents.length,8);assert.equal(s.open.length,0);assert.equal(s.closed[0].closedBy,'executor');assert.equal(s.closed[0].id,t.id);
});

test('director cannot override finance rejection when a limit improves after her review',()=>{
 let s=startCouncil(strongMarket(initialState()),'BTC',8);s.risk.maxTradePct=5;
 for(let i=0;i<6;i++)s=tick(s);assert.equal(s.council?.riskApproved,false);
 s.risk.maxTradePct=25;for(let i=0;i<2;i++)s=tick(s);
 assert.equal(s.open.length,0);assert.equal(s.cash,40);assert.equal(s.rejected,1);assert.match(s.lastCouncil.at(-2)!.text,/لم توافق سلمى/);
});
