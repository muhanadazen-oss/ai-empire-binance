import type {GameState} from '../src/engine/types.ts';
export function strongMarket(s:GameState):GameState {
 s.market={source:'Binance',observedAt:Date.now()};
 for(const a of s.assets){a.history=Array.from({length:35},(_,i)=>a.start*(1+i*.001));a.price=a.history.at(-1)!;}
 return s;
}
