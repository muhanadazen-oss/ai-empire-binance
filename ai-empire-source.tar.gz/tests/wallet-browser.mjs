import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { devServer } from '../scripts/dev-server.ts';
const {server}=await devServer({port:5183});
const browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:390,height:844}});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
try {
  await page.goto('http://127.0.0.1:5183/#wallet');
  await page.getByRole('heading',{name:'إرسال واستقبال USDT'}).waitFor();
  await page.getByRole('link',{name:'فتح اللعبة في MetaMask'}).waitFor();
  await page.addInitScript(()=>{
    const account='0x1234567890123456789012345678901234567890',listeners={};
    window.mockRequests=[];window.mockReject=true;
    window.ethereum={on:(e,f)=>listeners[e]=f,removeListener:()=>{},request:async({method,params})=>{
      window.mockRequests.push({method,params});
      if(method==='eth_requestAccounts'||method==='eth_accounts')return [account];
      if(method==='eth_chainId')return '0x38';
      if(method==='wallet_switchEthereumChain')return null;
      if(method==='eth_getBalance')return '0xde0b6b3a7640000';
      if(method==='eth_gasPrice')return '0x3b9aca00';
      if(method==='eth_estimateGas')return '0xc350';
      if(method==='eth_call'){
        const data=params[0].data;
        if(data.startsWith('0x313ce567'))return '0x'+(18n).toString(16).padStart(64,'0');
        if(data.startsWith('0x70a08231'))return '0x'+(40n*10n**18n).toString(16).padStart(64,'0');
        if(data.startsWith('0xa9059cbb'))return '0x'+(1n).toString(16).padStart(64,'0');
      }
      if(method==='eth_sendTransaction'){if(window.mockReject)throw Object.assign(new Error('User rejected'),{code:4001});return '0x'+'a'.repeat(64);}
      if(method==='eth_blockNumber')return '0x30';
      if(method==='eth_getTransactionReceipt')return {transactionHash:'0x'+'a'.repeat(64),transactionIndex:'0x0',blockHash:'0x'+'b'.repeat(64),blockNumber:'0x10',from:account,to:'0x55d398326f99059ff775485246999027b3197955',cumulativeGasUsed:'0xc350',gasUsed:'0xc350',contractAddress:null,logs:[],logsBloom:'0x'+'0'.repeat(512),status:'0x1',effectiveGasPrice:'0x3b9aca00',type:'0x0'};
      throw Error('Unhandled '+method);
    }};
    window.changeWallet=()=>listeners.accountsChanged?.([]);
  });
  await page.reload();
  await page.getByRole('button',{name:'ربط محفظة المتصفح'}).click();
  await page.getByText('40 USDT',{exact:false}).first().waitFor();
  await page.getByLabel('عنوان إيداع USDT في Binance',{exact:true}).fill('0x2222222222222222222222222222222222222222');
  await page.getByLabel('المبلغ بـUSDT',{exact:true}).fill('41');
  await page.getByRole('button',{name:'مراجعة المبلغ والرسوم'}).click();
  await page.getByText('رصيد USDT غير كافٍ.').waitFor();
  await page.getByLabel('المبلغ بـUSDT',{exact:true}).fill('1.5');
  await page.getByRole('button',{name:'مراجعة المبلغ والرسوم'}).click();
  await page.getByRole('heading',{name:'راجع قبل الإرسال'}).waitFor();
  assert.equal((await page.evaluate(()=>window.mockRequests)).filter(r=>r.method==='eth_sendTransaction').length,0);
  const send=page.getByRole('button',{name:'الموافقة من المحفظة وإرسال'});
  assert.ok(await send.isDisabled());
  await page.getByRole('checkbox').check(); await send.click();
  await page.getByText('تم إلغاء الطلب من المحفظة.').waitFor();
  const sent=(await page.evaluate(()=>window.mockRequests)).filter(r=>r.method==='eth_sendTransaction');
  assert.equal(sent.length,1); assert.equal(sent[0].params[0].to.toLowerCase(),'0x55d398326f99059ff775485246999027b3197955');
  assert.ok(sent[0].params[0].data.startsWith('0xa9059cbb')); assert.equal(sent[0].params[0].from,'0x1234567890123456789012345678901234567890');
  assert.equal(BigInt('0x'+sent[0].params[0].data.slice(-64)),1500000000000000000n);
  await page.evaluate(()=>window.mockReject=false);
  await send.click();
  await page.getByRole('heading',{name:'تم تأكيد التحويل على الشبكة'}).waitFor();
  assert.equal(await page.getByRole('link',{name:'تتبع العملية على BscScan'}).getAttribute('href'),'https://bscscan.com/tx/0x'+'a'.repeat(64));
  await page.evaluate(()=>window.changeWallet());
  await page.getByRole('button',{name:'ربط محفظة المتصفح'}).waitFor();
  assert.equal(await page.getByRole('button',{name:'الموافقة من المحفظة وإرسال'}).count(),0);
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  assert.deepEqual(errors,[]);
  console.log('Wallet mobile: absent provider guidance, real RPC mocked balances, insufficient funds, review before signing, correct transfer target, rejection, account-change reset and responsive layout passed. No live transfer sent.');
}finally{await browser.close();await server.close();}
