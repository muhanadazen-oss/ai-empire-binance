import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import input from '../trading/evidence/input.json' with {type:'json'};
import report from '../trading/evidence/report.json' with {type:'json'};
import {POLICY,POLICY_ID,backtest,newPortfolio,netEquity,markRisk,paperBuy,paperSell,floorStepString,newPaper,heartbeat,paperGate,underperforms,validateCandles,type Filters,type Signal} from '../trading/core.ts';
const filters:Filters={step:'0.001',tick:'0.01',minQty:.001,maxQty:10000,minNotional:5,maxNotional:1e8,marketStep:'0.001',marketMinQty:.001,marketMaxQty:10000,oco:true};
const good:Signal={enter:true,exit:false,score:85,stopPct:.02,reason:'test',at:1000};
test('captured Binance evidence replays exactly, including both-side costs and buy-and-hold',()=>{
 const hash=createHash('sha256').update(JSON.stringify(input)).digest('hex');assert.equal(hash,report.dataHash);
 const actual=backtest(input.candles,input.start,input.end,1000,input.filters,hash);
 assert.deepEqual(actual,report);assert.equal(actual.passed,false);assert.equal(actual.trades,27);
 assert.ok(actual.netReturn<0);assert.ok(actual.buyHoldReturn>actual.netReturn);
 assert.ok(Math.abs(actual.netPnl-actual.roundTrips.reduce((a,t)=>a+t.netPnl,0))<1e-8);
 assert.ok(actual.roundTrips.every(t=>t.cost<=200+1e-8));
});
test('changing future bars cannot change already completed trades',()=>{
 const split=2500,c=structuredClone(input.candles),at=c[split].time;
 for(let i=split;i<c.length;i++){c[i].open*=2;c[i].high*=2;c[i].low*=2;c[i].close*=2;}
 const a=backtest(input.candles,input.start,input.end,1000,input.filters,'a');
 const b=backtest(c,input.start,input.end,1000,input.filters,'b');
 assert.deepEqual(a.roundTrips.filter(t=>t.exitedAt<at),b.roundTrips.filter(t=>t.exitedAt<at));
});
test('missing, duplicate, nonfinite and still-open candles cannot enter historical proof',()=>{
 const bad=structuredClone(input.candles.slice(0,220));bad.splice(5,1);assert.throws(()=>validateCandles(bad,POLICY.intervalMs));
 const duplicate=structuredClone(input.candles.slice(0,220));duplicate[10]=duplicate[9];assert.throws(()=>validateCandles(duplicate,POLICY.intervalMs));
 const corrupt=structuredClone(input.candles.slice(0,220));corrupt[5].close=NaN;assert.throws(()=>validateCandles(corrupt,POLICY.intervalMs));
 assert.throws(()=>backtest(input.candles,input.start+1,input.end,1000,input.filters,'bad'));
});
test('paper fees/slippage conserve capital, are charged twice, and entry never exceeds 20% of initial capital',()=>{
 const p=newPortfolio(1000,2000);assert.equal(paperBuy(p,good,100,2000,filters),true);
 assert.ok(p.position!.cost<=200);assert.ok(p.position!.entry>100);assert.ok(p.position!.stop<p.position!.entry);
 assert.equal(p.position!.entryFees,p.buyFees);
 assert.equal(paperBuy(p,{...good,at:2000},100,2000,filters),false);
 paperSell(p,100,3000,'test');assert.ok(p.cash<1000);assert.ok(p.trades[0].fees>0);assert.ok(p.trades[0].exit<100);
 assert.ok(Math.abs(p.cash-1000-p.trades[0].netPnl)<1e-8);
 const increased=newPortfolio(1000,2000);increased.cash=2000;paperBuy(increased,good,100,2000,filters);assert.ok(increased.position!.cost<=200);
});
test('Binance minimum and stop notional block small entries without increasing capital',()=>{
 const p=newPortfolio(20,2000);assert.equal(paperBuy(p,good,100,2000,filters),false);assert.equal(p.cash,20);assert.equal(p.position,null);
});
test('daily 3% loss is sticky until UTC rollover, while total 15% halt can never auto-resume',()=>{
 const t=Date.UTC(2026,9,3,12),p=newPortfolio(1000,t);p.cash=970;assert.equal(markRisk(p,100,t),'daily_loss_3');
 p.cash=1000;assert.equal(markRisk(p,100,t+1000),'daily_loss_3');assert.equal(markRisk(p,100,t+86400000),null);
 p.cash=850;assert.equal(markRisk(p,100,t+86400001),'total_loss_15');p.cash=2000;
 assert.equal(markRisk(p,100,t+86400000*3),'total_loss_15');assert.equal(p.halted,true);
 assert.throws(()=>{(POLICY as any).totalLoss=.9;});assert.equal(POLICY.totalLoss,.15);
});
test('paper requires real elapsed AND observed time, same cap/version, freshness, net profitability and no gaps',()=>{
 const now=Date.UTC(2026,9,3),duration=60*86400000,p=newPaper(100,now-duration);p.lastHeartbeat=now;p.observedMs=duration;p.lastPrice=100;p.portfolio.cash=101;
 p.portfolio.trades=Array.from({length:3},(_,i)=>({id:String(i),enteredAt:0,exitedAt:0,quantity:1,entry:1,exit:1,cost:1,proceeds:2,netPnl:1,fees:.01,reason:'test'}));
 assert.equal(paperGate(p,now,100),true);assert.equal(paperGate(p,now,200),false);assert.equal(paperGate(p,now,null),false);
 for(const mutation of [(q:typeof p)=>q.observedMs=duration-1,(q:typeof p)=>q.startedAt=now-1000,(q:typeof p)=>q.portfolio.cash=100,(q:typeof p)=>q.policyId='other',(q:typeof p)=>q.invalid=true]){const q=structuredClone(p);mutation(q);assert.equal(paperGate(q,now,100),false);}
 heartbeat(p,now+120001);assert.equal(p.invalid,true);assert.equal(paperGate(p,now+120001,100),false);
 const q=newPaper(100,now);heartbeat(q,now-1);assert.equal(q.invalid,true);
});
test('performance comparison has an explicit window/minimum sample and counts net equity',()=>{
 const now=Date.UTC(2026,9,3),live=newPortfolio(100,now-8*86400000),shadow=newPortfolio(100,now-8*86400000);
 live.cash=90;shadow.cash=100;live.trades=Array(10).fill({});assert.equal(underperforms(live,shadow,now-8*86400000,now,100),true);
 assert.equal(underperforms(live,shadow,now-1000,now,100),false);live.trades=[];assert.equal(underperforms(live,shadow,now-8*86400000,now,100),false);
});
test('quantities round down with decimal arithmetic rather than floating point step rounding',()=>{
 assert.equal(floorStepString(.000029999999999,'0.00001000'),'0.00002');
 assert.equal(floorStepString(.12345678,'0.00001000'),'0.12345');assert.throws(()=>floorStepString(Infinity,'0.001'));
 assert.equal(POLICY_ID,JSON.stringify(POLICY));assert.ok(netEquity(newPortfolio(100,0),100)===100);
});
