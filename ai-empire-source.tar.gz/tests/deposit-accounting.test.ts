import test from 'node:test';
import assert from 'node:assert/strict';
import {encodeEventTopics,erc20Abi,toHex} from 'viem';
import {walletRoute} from '../server/wallet.ts';
import {sqliteDB} from './sqlite.ts';
import {SCHEMA} from '../server/schema.ts';
import {TOKEN} from '../src/integration/wallet-chain.ts';

test('deposit ledger verifies token, recipient, receipt, confirmations and log identity; totals are exact and private',async()=>{
 const {db,sqlite}=sqliteDB();for(const statement of SCHEMA)sqlite.exec(statement);
 const address='0x1111111111111111111111111111111111111111', sender='0x2222222222222222222222222222222222222222';
 sqlite.prepare('INSERT INTO empire_wallets(user_id,address,vault,created_at) VALUES(?,?,?,?)').run('owner',address,'{}','2026-10-03');
 sqlite.prepare('INSERT INTO empire_wallets(user_id,address,vault,created_at) VALUES(?,?,?,?)').run('other',sender,'{}','2026-10-03');
 const user={id:'owner',email:'wallet@test.example'} as any;
 const call=async(path:string,body?:unknown,u=user)=>{const r=await walletRoute(new Request('https://test'+path,{method:body?'POST':'GET',body:body?JSON.stringify(body):undefined}),db,u);return {status:r!.status,data:await r!.json() as any};};
 const hash='0x'+'ab'.repeat(32), value=1000000000000000001n;
 const log=(to=address,token=TOKEN,index='0x0')=>({address:token,logIndex:index,data:toHex(value,{size:32}),topics:encodeEventTopics({abi:erc20Abi,eventName:'Transfer',args:{from:sender as any,to:to as any}})});
 let receipt:any={transactionHash:hash,blockNumber:'0x10',status:'0x1',logs:[log()]},head='0x12';
 const original=globalThis.fetch;
 globalThis.fetch=async(input,init)=>{assert.equal(String(input),'https://bsc-dataseed.bnbchain.org');const p=JSON.parse(String(init?.body));return Response.json({result:p.method==='eth_getTransactionReceipt'?receipt:p.method==='eth_blockNumber'?head:p.method==='eth_call'?toHex(value):p.method==='eth_getBalance'?'0x123':{timestamp:'0x65000000'}});};
 try{
  assert.equal((await call('/api/wallet/deposit',{hash})).status,200);
  assert.equal((await call('/api/wallet/deposit',{hash})).status,200);
  let totals=(await call('/api/wallet/accounting')).data;assert.equal(totals.deposited,value.toString());assert.equal(totals.deposits.length,1);
  assert.equal((await call('/api/wallet/accounting',undefined,{id:'other',email:'other@test.example'} as any)).data.deposited,'0');
  receipt.logs=[log(sender)];assert.equal((await call('/api/wallet/deposit',{hash})).status,400);
  receipt.logs=[log(address,sender as any)];assert.equal((await call('/api/wallet/deposit',{hash})).status,400);
  receipt.logs=[log()];receipt.status='0x0';assert.equal((await call('/api/wallet/deposit',{hash})).status,400);
  receipt.status='0x1';head='0x11';assert.equal((await call('/api/wallet/deposit',{hash})).status,400);
  head='0x12';receipt.transactionHash='0x'+'cd'.repeat(32);assert.equal((await call('/api/wallet/deposit',{hash})).status,400);
  receipt.transactionHash=hash;receipt.logs=[log(address,TOKEN,'0x1')];assert.equal((await call('/api/wallet/deposit',{hash})).status,200);
  for(const status of ['confirmed','pending','reverted'])sqlite.prepare('INSERT INTO empire_wallet_transfers(hash,user_id,recipient,amount,raw,status,created_at) VALUES(?,?,?,?,?,?,?)').run(status,'owner',sender,value.toString(),'SECRET_RAW',status,'2026-10-03');
  totals=(await call('/api/wallet/accounting')).data;assert.equal(totals.deposited,(value*2n).toString());assert.equal(totals.withdrawn,value.toString());assert.equal(totals.pending,value.toString());assert.ok(!JSON.stringify(totals).includes('SECRET_RAW'));
  const summary=(await call('/api/wallet/summary')).data.summary;assert.equal(summary.usdt,value.toString());assert.equal(summary.bnb,'291');assert.equal(summary.deposited,totals.deposited);assert.equal(summary.withdrawn,totals.withdrawn);assert.ok(!JSON.stringify(summary).includes('vault'));
  const otherSummary=(await call('/api/wallet/summary',undefined,{id:'other',email:'other@test.example'} as any)).data.summary;assert.equal(otherSummary.deposited,'0');assert.equal(otherSummary.withdrawn,'0');
  receipt.transactionHash='0x'+'ef'.repeat(32);receipt.logs=[{...log(),data:toHex(999999999999999999n,{size:32})}];
  const small=await call('/api/wallet/deposit',{hash:receipt.transactionHash});assert.equal(small.status,200);assert.equal(small.data.meetsMinimum,false);
  assert.equal((await call('/api/wallet/accounting')).data.deposited,(value*2n+999999999999999999n).toString());
  receipt.transactionHash='0x'+'fa'.repeat(32);receipt.logs=[{...log(),data:toHex(1000000000000000000n,{size:32})}];assert.equal((await call('/api/wallet/deposit',{hash:receipt.transactionHash})).data.meetsMinimum,true);
  assert.equal((await call('/api/wallet/deposit',{hash:'invalid'})).status,400);
 }finally{globalThis.fetch=original;sqlite.close();}
});
