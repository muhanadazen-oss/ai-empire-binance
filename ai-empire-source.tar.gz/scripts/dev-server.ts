import { createServer } from "vite";
import worker from "../server/worker.ts";
import { sqliteDB } from "../tests/sqlite.ts";
export async function devServer({ port = 5180, database = ":memory:" } = {}) {
  const { db, sqlite } = sqliteDB(database);
  const server = await createServer({
    server: { host: "127.0.0.1", port },
    plugins: [
      {
        name: "empire-local-api",
        configureServer(vite) {
          vite.middlewares.use(async (req, res, next) => {
            if (!req.url?.startsWith("/api/")) return next();
            try {
              const chunks: Buffer[] = [];
              for await (const c of req) chunks.push(Buffer.from(c));
              const headers = new Headers();
              for (const [key, value] of Object.entries(req.headers))
                if (value)
                  headers.set(
                    key,
                    Array.isArray(value) ? value.join(",") : value,
                  );
              const body = Buffer.concat(chunks);
              const result = await worker.fetch(
                new Request(`http://${req.headers.host}${req.url}`, {
                  method: req.method,
                  headers,
                  ...(body.length ? { body: new Uint8Array(body) } : {}),
                }),
                { DB: db },
              );
              res.statusCode = result.status;
              result.headers.forEach((value, key) => res.setHeader(key, value));
              res.end(await result.text());
            } catch (e) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: String(e) }));
            }
          });
        },
      },
    ],
  });
  await server.listen();
  return { server, db, sqlite };
}
if (process.argv[1]?.endsWith("dev-server.ts")) {
  await devServer({
    database: process.env.EMPIRE_DEV_DATABASE ?? "/tmp/ai-empire-dev.sqlite",
  });
  console.log("AI EMPIRE + local SQLite at http://127.0.0.1:5180");
}
