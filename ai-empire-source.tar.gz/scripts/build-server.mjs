import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
let esbuild;
try {
  esbuild = require("esbuild");
} catch {
  esbuild = require("../node_modules/.pnpm/esbuild@0.28.0/node_modules/esbuild");
}
const root = path.resolve(import.meta.dirname, "..");
const files = {};
function collect(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) collect(file);
    else {
      const rel =
        "/" +
        path.relative(path.join(root, "dist"), file).replaceAll("\\", "/");
      const type =
        {
          ".html": "text/html; charset=utf-8",
          ".css": "text/css; charset=utf-8",
          ".js": "text/javascript; charset=utf-8",
          ".svg": "image/svg+xml",
        }[path.extname(file)] ?? "application/octet-stream";
      files[rel] = { body: fs.readFileSync(file, "utf8"), type };
    }
  }
}
collect(path.join(root, "dist"));
fs.mkdirSync(path.join(root, "dist/server"), { recursive: true });
await esbuild.build({
  entryPoints: [path.join(root, "server/worker.ts")],
  outfile: path.join(root, "dist/server/index.js"),
  bundle: true,
  format: "esm",
  platform: "browser",
  target: "es2022",
  banner: { js: `const STATIC_FILES=${JSON.stringify(files)};` },
  minify: true,
});
fs.writeFileSync(
  path.join(root, "dist/server/wrangler.json"),
  JSON.stringify({
    name: "ai-empire",
    main: "index.js",
    compatibility_date: "2026-05-15",
    compatibility_flags: ["nodejs_compat"],
    no_bundle: true,
    d1_databases: [
      {
        binding: "DB",
        database_name: "ai-empire-db",
        database_id: "00000000-0000-4000-8000-000000000000",
      },
    ],
  }),
);
console.log("Built server, D1 and embedded client assets");
