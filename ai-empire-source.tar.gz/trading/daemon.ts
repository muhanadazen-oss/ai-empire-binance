import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { TradingStore } from './store.ts';
import { TradingRuntime } from './runtime.ts';
import { SpotBroker } from './binance-spot.ts';
import { POLICY } from './core.ts';
import { tradingHttpServer } from './http.ts';
import { tradingProcessLock } from './process-lock.ts';
const token=process.env.TRADING_SERVER_TOKEN??'';
if(token.length<32)throw new Error('Set a random TRADING_SERVER_TOKEN (at least 32 characters). Never put it in browser code.');
const directory=resolve(process.env.TRADING_DATA_DIRECTORY??'/var/lib/ai-empire');
mkdirSync(directory,{recursive:true,mode:0o700});
const releaseLock=tradingProcessLock(resolve(directory,'process-lock.sqlite'));
const store=new TradingStore(resolve(directory,'trading.sqlite'));
const key=process.env.BINANCE_SPOT_API_KEY,secret=process.env.BINANCE_SPOT_API_SECRET;
const broker=key&&secret?new SpotBroker(key,secret):null;
const runtime=new TradingRuntime(store,{expectedIp:process.env.TRADING_STATIC_EGRESS_IP,webhook:process.env.TRADING_NOTIFICATION_WEBHOOK,webhookToken:process.env.TRADING_NOTIFICATION_TOKEN,evidenceDirectory:resolve(directory,'evidence')},broker);
const server=tradingHttpServer(runtime,token);
const host=process.env.TRADING_BIND_HOST??'127.0.0.1';
if(!['127.0.0.1','0.0.0.0'].includes(host))throw new Error('Unsupported trading bind host.');
const port=Number(process.env.TRADING_PORT??process.env.PORT??8789);
if(!Number.isSafeInteger(port)||port<0||port>65535)throw new Error('Invalid trading port.');
server.on('error',error=>{console.error(error.message);store.close();releaseLock();process.exit(1);});
server.listen(port,host,()=>{const address=server.address();console.log(`AI EMPIRE trading service ready on ${host}:${typeof address==='object'&&address?address.port:port}; live activation remains gated.`);});
let stopping=false,timer:ReturnType<typeof setTimeout>;
async function loop(){if(stopping)return;await runtime.serial(()=>runtime.tick());if(!stopping)timer=setTimeout(loop,POLICY.pollMs);}
void loop();
async function shutdown(){if(stopping)return;stopping=true;clearTimeout(timer);await runtime.serial(async()=>runtime.persist());server.close();store.close();releaseLock();process.exit(0);}
process.on('SIGTERM',()=>void shutdown());process.on('SIGINT',()=>void shutdown());
