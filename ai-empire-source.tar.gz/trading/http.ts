import { createServer } from 'node:http';
import { createHash, timingSafeEqual } from 'node:crypto';
import type { TradingRuntime } from './runtime.ts';

/** Public health checks contain no account data; every control stays authenticated. */
export function tradingHttpServer(runtime:TradingRuntime,token:string) {
  if(token.length<32)throw new Error('Trading service token must have at least 32 characters.');
  const hash=(value:string)=>createHash('sha256').update(value).digest();
  const expected=hash(token);
  const actions=new Set(['/v1/configure','/v1/backtest','/v1/paper','/v1/verify','/v1/test-notifications','/v1/activate','/v1/emergency']);
  const server=createServer(async(req,res)=>{
    const respond=(body:unknown,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));};
    try {
      const path=new URL(req.url??'/', 'http://localhost').pathname;
      if(req.method==='GET'&&path==='/healthz')return respond({ok:true,service:'ai-empire-trading'});
      const supplied=String(req.headers.authorization??'').replace(/^Bearer /,'');
      if(!timingSafeEqual(hash(supplied),expected))return respond({error:'Unauthorized'},401);
      if(req.method==='GET'&&path==='/v1/status')return respond(runtime.snapshot());
      if(req.method!=='POST'||!actions.has(path))return respond({error:'Unknown action'},404);
      if(req.headers['x-empire-action-origin']!=='user-click')return respond({error:'A user action is required.'},403);
      let raw='';for await(const chunk of req){raw+=chunk.toString();if(Buffer.byteLength(raw)>8192)return respond({error:'Request too large'},413);}
      const body=raw?JSON.parse(raw):{};
      if(body===null||typeof body!=='object'||Array.isArray(body))return respond({error:'Invalid request body'},400);
      if(path==='/v1/emergency')runtime.requestEmergency();
      if(path==='/v1/backtest') {
        runtime.queueHistory();
        return respond({queued:true},202);
      }
      await runtime.serial(async()=>{
        if(path==='/v1/configure')await runtime.configure(body.capital);
        else if(path==='/v1/paper')await runtime.startPaper(body.restart===true&&body.ack==='RESTART_60_DAYS');
        else if(path==='/v1/verify')await runtime.verifyConnection();
        else if(path==='/v1/test-notifications')await runtime.testNotifications();
        else if(path==='/v1/activate')await runtime.activate(body.ack);
        else if(path==='/v1/emergency')await runtime.emergency();
      });
      respond(runtime.snapshot());
    } catch(e){respond({error:e instanceof Error?e.message:'Trading service error'},400);}
  });
  server.requestTimeout=15_000;server.headersTimeout=10_000;
  return server;
}
