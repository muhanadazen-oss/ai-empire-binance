import { createHmac } from 'node:crypto';
import { isIP } from 'node:net';
import { POLICY, floorStepString, type Filters, type Signal } from './core.ts';
import { marketGet, type Fetcher } from './market.ts';
export class ExchangeFailure extends Error {
  status:number; code:number|null; ambiguous:boolean;
  constructor(status:number,code:number|null,ambiguous=false) {
    super(status===451?'منطقة الخادم غير مدعومة من Binance؛ لا يتم تجاوز الحظر.':status===429||status===418?'Binance قيّد الطلبات؛ توقف فتح الصفقات.':`تعذر تنفيذ طلب Binance (${status} / ${code??'network'})`);
    this.status=status;this.code=code;this.ambiguous=ambiguous;
  }
}
export function assertSpotPermissions(p:any) {
  for(const k of ['enableReading','enableSpotAndMarginTrading','ipRestrict'])if(p?.[k]!==true)throw new Error('يلزم مفتاح قراءة وSpot مقيّد بعنوان IP الخادم.');
  for(const k of ['enableWithdrawals','enableInternalTransfer','permitsUniversalTransfer','enableMargin','enableFutures','enableVanillaOptions','enablePortfolioMarginTrading','enableFixApiTrade'])if(p?.[k]!==false)throw new Error('مفتاح مرفوض: صلاحية محظورة مفعّلة أو لم تُتحقق؛ السحب والتحويل ممنوعان.');
  const allowed=new Set(['enableReading','enableSpotAndMarginTrading','ipRestrict','enableFixReadOnly']);
  for(const [k,v] of Object.entries(p))if(v===true&&!allowed.has(k))throw new Error('مفتاح مرفوض: صلاحية إضافية غير مسموحة.');
}
export interface Verification { checkedAt:number; ip:string; ipRestricted:true; spotOnly:true; takerFee:number }
export interface Fill { orderId:number; clientId:string; side:'BUY'|'SELL'; quantity:number; baseSpent:number; netBase:number; quote:number; quoteFee:number; otherFee:number; fees:number; price:number; at:number; status:string; commissions:{asset:string;amount:number;valueUSDT:number}[] }
export interface OwnedIds { buy:string; list:string; above:string; below:string }
const BOT=/^emp-[a-z0-9-]{8,30}$/;
export function ownedId(id:string){if(!BOT.test(id))throw new Error('الأمر لا يخص هذا البوت');return id;}
export class SpotBroker {
  #key:string;#secret:string;#fetch:Fetcher;#offset=0;#verifiedAt=0;
  constructor(key:string,secret:string,fetcher:Fetcher=fetch) {
    if(key.length<24||secret.length<24)throw new Error('مفتاح Binance غير مضبوط على الخادم');
    this.#key=key;this.#secret=secret;this.#fetch=fetcher;
  }
  async #request(method:string,path:string,query:Record<string,string>={}) {
    // No wallet withdrawal, transfer, margin, futures, or generic signed proxy exists.
    const allowed:Record<string,string[]>={GET:['/sapi/v1/account/apiRestrictions','/api/v3/account','/api/v3/order','/api/v3/openOrders','/api/v3/orderList','/api/v3/myTrades'],POST:['/api/v3/order','/api/v3/orderList/oco'],DELETE:['/api/v3/orderList','/api/v3/order']};
    if(!allowed[method]?.includes(path))throw new Error('مسار التداول غير مسموح');
    if(method!=='GET'&&Date.now()-this.#verifiedAt>60_000)throw new Error('لم يُتحقق حديثًا من صلاحيات المفتاح؛ الأمر مرفوض.');
    const params=new URLSearchParams({...query,recvWindow:'5000',timestamp:String(Date.now()+this.#offset)});
    const signature=createHmac('sha256',this.#secret).update(params.toString()).digest('hex');params.set('signature',signature);
    let r:Response;
    try{r=await this.#fetch(`https://api.binance.com${path}${method==='GET'?'?'+params:''}`,{method,headers:{'X-MBX-APIKEY':this.#key,...(method!=='GET'?{'Content-Type':'application/x-www-form-urlencoded'}:{})},...(method!=='GET'?{body:params.toString()}:{}),signal:AbortSignal.timeout(10_000)});}catch{throw new ExchangeFailure(0,null,method==='POST');}
    const data=await r.json().catch(()=>null);
    if(!r.ok)throw new ExchangeFailure(r.status,typeof data?.code==='number'?data.code:null,method==='POST'&&(r.status>=500||data?.code===-1007||data?.code===-1006));
    return data;
  }
  async syncTime() {
    const sent=Date.now();let r:Response;
    try{r=await this.#fetch('https://api.binance.com/api/v3/time',{signal:AbortSignal.timeout(10_000)});}catch{throw new ExchangeFailure(0,null);}
    if(!r.ok)throw new ExchangeFailure(r.status,null);
    const data=await r.json() as {serverTime:number};if(!Number.isSafeInteger(data.serverTime))throw new Error('توقيت Binance غير صالح');
    this.#offset=data.serverTime-(sent+Date.now())/2;
    if(Math.abs(this.#offset)>30_000)throw new Error('اضبط ساعة الخادم بـNTP قبل التداول');
  }
  async verify(expectedIp:string):Promise<Verification> {
    this.#verifiedAt=0;
    if(isIP(expectedIp)!==4)throw new Error('يلزم IP خروج ثابت IPv4 يقيّد به المفتاح');
    const ipResponse=await this.#fetch('https://api.ipify.org?format=json',{signal:AbortSignal.timeout(10_000)});
    if(!ipResponse.ok)throw new Error('تعذر التحقق من IP الخادم');
    const ip=String((await ipResponse.json() as {ip:string}).ip);
    if(ip!==expectedIp)throw new Error('IP خروج الخادم مختلف عن IP المحدد؛ التداول مقفول');
    await this.syncTime();const permissions=await this.#request('GET','/sapi/v1/account/apiRestrictions');assertSpotPermissions(permissions);
    const account=await this.account();
    const fee=Number(account.commissionRates?.taker);
    if(account.canTrade!==true||!Number.isFinite(fee)||fee<0||fee>POLICY.fee)throw new Error('حساب غير مؤهل أو رسومه أعلى من افتراضات الإثبات');
    this.#verifiedAt=Date.now();return {checkedAt:this.#verifiedAt,ip,ipRestricted:true,spotOnly:true,takerFee:fee};
  }
  account(){return this.#request('GET','/api/v3/account');}
  openOrders(){return this.#request('GET','/api/v3/openOrders',{symbol:POLICY.symbol});}
  async order(id:string) {
    try{return await this.#request('GET','/api/v3/order',{symbol:POLICY.symbol,origClientOrderId:ownedId(id)});}catch(e){if(e instanceof ExchangeFailure&&e.code===-2013)return null;throw e;}
  }
  async orderList(id:string) {
    try{return await this.#request('GET','/api/v3/orderList',{origClientOrderId:ownedId(id)});}catch(e){if(e instanceof ExchangeFailure&&(e.code===-2013||e.code===-2026))return null;throw e;}
  }
  buy(id:string,quote:number,price:number,f:Filters) {
    if(!(quote>0)||!Number.isFinite(quote))throw new Error('حجم شراء غير صالح');
    const limit=floorStepString(price*(1+POLICY.slippage),f.tick),quantity=floorStepString(quote/Number(limit),f.step);
    if(Number(quantity)<f.minQty||Number(quantity)*Number(limit)>quote+1e-9)throw new Error('حجم الشراء لا يطابق حدود Binance');
    // FOK limits adverse entry slippage and cannot leave a resting partial buy.
    return this.#request('POST','/api/v3/order',{symbol:POLICY.symbol,side:'BUY',type:'LIMIT',timeInForce:'FOK',price:limit,quantity,newClientOrderId:ownedId(id),newOrderRespType:'FULL'});
  }
  sell(id:string,quantity:number,f:Filters) {
    const q=floorStepString(quantity,f.marketStep);
    if(Number(q)<f.marketMinQty)throw new Error('الكمية المتبقية أقل من حد Binance؛ لم يُؤكّد إغلاقها');
    return this.#request('POST','/api/v3/order',{symbol:POLICY.symbol,side:'SELL',type:'MARKET',quantity:q,newClientOrderId:ownedId(id),newOrderRespType:'FULL'});
  }
  protect(ids:OwnedIds,quantity:number,entry:number,s:Signal,f:Filters) {
    if(!f.oco)throw new Error('الأصل لا يدعم أمر وقف على Binance');
    const q=floorStepString(quantity,f.step),stop=floorStepString(entry*(1-s.stopPct),f.tick),target=floorStepString(entry*(1+2*s.stopPct),f.tick);
    if(Number(q)<f.minQty||Number(q)*Number(stop)<f.minNotional)throw new Error('حجم الصفقة لا يكفي لأمر وقف Binance؛ يلزم الإغلاق');
    return this.#request('POST','/api/v3/orderList/oco',{symbol:POLICY.symbol,side:'SELL',quantity:q,listClientOrderId:ownedId(ids.list),aboveClientOrderId:ownedId(ids.above),aboveType:'TAKE_PROFIT',aboveStopPrice:target,belowClientOrderId:ownedId(ids.below),belowType:'STOP_LOSS',belowStopPrice:stop,newOrderRespType:'FULL'});
  }
  async cancelProtection(id:string) {return this.#request('DELETE','/api/v3/orderList',{symbol:POLICY.symbol,listClientOrderId:ownedId(id)});}
  async cancelBuy(id:string) {return this.#request('DELETE','/api/v3/order',{symbol:POLICY.symbol,origClientOrderId:ownedId(id)});}
  async fill(order:any):Promise<Fill> {
    if(!Number.isSafeInteger(order?.orderId)||!['BUY','SELL'].includes(order.side)||!BOT.test(order.clientOrderId)||!(Number(order.executedQty)>0))throw new Error('تنفيذ Binance غير صالح');
    const trades=await this.#request('GET','/api/v3/myTrades',{symbol:POLICY.symbol,orderId:String(order.orderId),limit:'1000'});
    if(!Array.isArray(trades)||!trades.length)throw new Error('لم يصل سجل التنفيذ والرسوم؛ أُوقف فتح أوامر جديدة');
    const selected=trades.filter((t:any)=>t.orderId===order.orderId),seen=new Set<number>();
    let quantity=0,quote=0,baseFee=0,quoteFee=0,otherFee=0,fees=0,at=0;
    const commissions:Fill['commissions']=[];
    for(const t of selected) {
      if(seen.has(t.id))throw new Error('تنفيذ مكرر');seen.add(t.id);
      const qty=Number(t.qty),price=Number(t.price),q=Number(t.quoteQty),commission=Number(t.commission);
      if(![qty,price,q,commission,Number(t.time)].every(Number.isFinite)||qty<=0||price<=0||q<=0||commission<0)throw new Error('سجل رسوم غير صالح');
      quantity+=qty;quote+=q;at=Math.max(at,Number(t.time));let value=commission;
      if(t.commissionAsset==='BTC'){baseFee+=commission;value=commission*price;}
      else if(t.commissionAsset==='USDT')quoteFee+=commission;
      else if(commission>0) {
        // Actual commission quantity; non-USDT value is marked at the last closed 1m candle.
        const c=await marketGet('/api/v3/klines',{symbol:String(t.commissionAsset)+'USDT',interval:'1m',startTime:String(Math.floor(Number(t.time)/60_000)*60_000-60_000),limit:'1'},this.#fetch);
        const rate=Number(c?.[0]?.[4]);if(!(rate>0)||!Number.isFinite(rate))throw new Error('تعذر تقييم عملة الرسوم');
        value=commission*rate;otherFee+=value;
      }
      fees+=value;commissions.push({asset:String(t.commissionAsset),amount:commission,valueUSDT:value});
    }
    if(Math.abs(quantity-Number(order.executedQty))>1e-10||Math.abs(quote-Number(order.cummulativeQuoteQty))>1e-5)throw new Error('سجل التنفيذ غير مكتمل؛ يلزم المصالحة');
    return {orderId:order.orderId,clientId:order.clientOrderId,side:order.side,quantity,baseSpent:quantity+(order.side==='SELL'?baseFee:0),netBase:quantity-(order.side==='BUY'?baseFee:0),quote,quoteFee,otherFee,fees,price:quote/quantity,at,status:order.status,commissions};
  }
}
