import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, chmodSync } from 'node:fs';
import { dirname } from 'node:path';
import { POLICY_ID, type BacktestReport, type PaperProof, type Portfolio, type Signal, type Filters } from './core.ts';
import type { Verification, OwnedIds, Fill } from './binance-spot.ts';
export interface Notice { id:string; at:number; kind:string; text:string; data:Record<string,unknown>; deliveredAt:number|null; attempts:number }
export interface Intent { kind:'buy'|'protect'|'close'; ids:OwnedIds; closeId:string|null; signal:Signal; attemptedAt:number; orderId:number|null; reason:string; flatten:boolean }
export interface LiveState { startedAt:number; portfolio:Portfolio; shadow:Portfolio; intent:Intent|null; ids:OwnedIds|null; protected:boolean; accountedOrders:number[]; fills:Fill[]; lastSeenSignal:number; closeReason:string|null; totalFees:number; baselineQuote:number; riskNoticeDay:string|null }
export interface RuntimeState {
  revision:number; policyId:string; capital:number|null; phase:'setup'|'paper'|'paper_complete'|'live'|'halted';
  backtest:BacktestReport|null; paper:PaperProof|null; live:LiveState|null;
  filters:Filters|null; lastHeartbeat:number; lastPrice:number; lastPaperSignal:number;
  completedAt:number|null; verification:Verification|null; emergency:boolean; error:string|null;
  job:{kind:'backtest';startedAt:number}|null; notices:Notice[]; lastReportDay:string|null;
}
export function emptyRuntime():RuntimeState {return {revision:0,policyId:POLICY_ID,capital:null,phase:'setup',backtest:null,paper:null,live:null,filters:null,lastHeartbeat:0,lastPrice:0,lastPaperSignal:0,completedAt:null,verification:null,emergency:false,error:null,job:null,notices:[],lastReportDay:null};}
export class TradingStore {
  #db:DatabaseSync;
  constructor(path:string) {
    if(path!==':memory:')mkdirSync(dirname(path),{recursive:true,mode:0o700});
    this.#db=new DatabaseSync(path);this.#db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS runtime(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL,data TEXT NOT NULL);');
    if(path!==':memory:')chmodSync(path,0o600);
    const initial=emptyRuntime();this.#db.prepare('INSERT OR IGNORE INTO runtime(id,revision,data) VALUES(1,0,?)').run(JSON.stringify(initial));
  }
  load():RuntimeState {const row=this.#db.prepare('SELECT revision,data FROM runtime WHERE id=1').get() as {revision:number;data:string};const s=JSON.parse(row.data) as RuntimeState;s.revision=row.revision;return s;}
  save(state:RuntimeState) {
    const next=state.revision+1;
    const result=this.#db.prepare('UPDATE runtime SET revision=?,data=? WHERE id=1 AND revision=?').run(next,JSON.stringify({...state,revision:next}),state.revision);
    if(result.changes!==1)throw new Error('تعارض خادمي؛ يُمنع إرسال أمر جديد');state.revision=next;
  }
  close(){this.#db.close();}
}
