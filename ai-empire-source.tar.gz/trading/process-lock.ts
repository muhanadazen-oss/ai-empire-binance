import { DatabaseSync } from 'node:sqlite';
import { chmodSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

/** An OS-backed SQLite lock survives PID reuse and releases on process death. */
export function tradingProcessLock(path:string):()=>void {
  mkdirSync(dirname(path),{recursive:true,mode:0o700});
  const database=new DatabaseSync(path);
  try {
    chmodSync(path,0o600);
    database.exec('PRAGMA busy_timeout=0; PRAGMA journal_mode=DELETE; CREATE TABLE IF NOT EXISTS process_guard(id INTEGER PRIMARY KEY); BEGIN EXCLUSIVE;');
  } catch {database.close();throw new Error('Another trading service is running, or the exclusive disk lock is unavailable.');}
  let released=false;
  return ()=>{if(!released){released=true;database.close();}};
}
