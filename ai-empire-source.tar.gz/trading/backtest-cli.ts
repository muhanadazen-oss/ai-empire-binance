import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { backtest, POLICY } from './core.ts';
import { historicalCandles, exchangeFilters, marketGet, twoYearWindow } from './market.ts';
export async function runBacktest(capital:number, directory:string) {
  const now=Number((await marketGet('/api/v3/time')).serverTime);
  if(!Number.isSafeInteger(now))throw new Error('توقيت Binance غير صالح');
  const {start,end}=twoYearWindow(now);
  const filters=await exchangeFilters();
  const candles=await historicalCandles(start,end,fetch,n=>console.log(`Binance: ${n} closed candles downloaded`));
  const input={symbol:POLICY.symbol,interval:POLICY.interval,start,end,filters,candles};
  const dataHash=createHash('sha256').update(JSON.stringify(input)).digest('hex');
  const report=backtest(candles,start,end,capital,filters,dataHash);
  await mkdir(directory,{recursive:true});
  await writeFile(resolve(directory,'input.json'),JSON.stringify(input));
  await writeFile(resolve(directory,'report.json'),JSON.stringify(report,null,2));
  await writeFile(resolve(directory,'candles.csv'),'open_time,open,high,low,close,volume,close_time\n'+candles.map(b=>[b.time,b.open,b.high,b.low,b.close,b.volume,b.closeTime].join(',')).join('\n')+'\n');
  return report;
}
if(process.argv[1]?.endsWith('backtest-cli.ts')) {
  const capital=Number(process.argv[2]??1000),dir=resolve(process.argv[3]??'trading/evidence');
  if(process.argv.includes('--replay')) {
    const input=JSON.parse(await readFile(resolve(dir,'input.json'),'utf8'));
    const hash=createHash('sha256').update(JSON.stringify(input)).digest('hex');
    const report=backtest(input.candles,input.start,input.end,capital,input.filters,hash);
    console.log(JSON.stringify({...report,roundTrips:undefined}));
  } else {
    const report=await runBacktest(capital,dir);
    console.log(JSON.stringify({...report,roundTrips:undefined}));
  }
}
