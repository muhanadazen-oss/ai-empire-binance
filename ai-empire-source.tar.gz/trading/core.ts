/** Server-authoritative policy. No API or agent may patch these values. */
export const POLICY = Object.freeze({
  version: 'btc-4h-trend-v1', symbol: 'BTCUSDT', baseAsset: 'BTC', quoteAsset: 'USDT',
  interval: '4h', intervalMs: 14_400_000, warmup: 210,
  fee: 0.001, slippage: 0.0005, allocation: 0.20,
  dailyLoss: 0.03, totalLoss: 0.15, proofDays: 60,
  minScore: 75, stopMin: 0.01, stopMax: 0.04,
  maxHeartbeatGapMs: 120_000, pollMs: 15_000,
  underperformancePoints: 0.05, comparisonDays: 7, comparisonTrades: 10,
});
export const POLICY_ID = JSON.stringify(POLICY);
export interface Candle { time:number; open:number; high:number; low:number; close:number; volume:number; closeTime:number }
export interface Filters { step:string; tick:string; minQty:number; maxQty:number; minNotional:number; maxNotional:number; marketStep:string; marketMinQty:number; marketMaxQty:number; oco:boolean }
export interface Signal { enter:boolean; exit:boolean; score:number; stopPct:number; reason:string; at:number }
export interface Position { id:string; quantity:number; entry:number; cost:number; stop:number; target:number; at:number; score:number; entryFees?:number }
export interface RoundTrip { id:string; enteredAt:number; exitedAt:number; quantity:number; entry:number; exit:number; cost:number; proceeds:number; netPnl:number; fees:number; reason:string }
export interface Portfolio {
  initial:number; cash:number; position:Position|null; trades:RoundTrip[]; buyFees:number;
  day:string; dayStart:number; pausedDay:string|null; halted:boolean; haltReason:string|null;
  lastSignal:number; peak:number; maxDrawdown:number;
  dust?:{quantity:number;cost:number;entryFees:number};
}
export interface BacktestReport {
  policyId:string; strategy:string; source:string; dataHash:string; start:number; end:number;
  warmupCandles:number; candles:number; capital:number; finalEquity:number; netPnl:number; netReturn:number;
  fees:number; slippagePerSide:number; feePerSide:number; trades:number; winRate:number;
  maxDrawdown:number; buyHoldEquity:number; buyHoldReturn:number; beatBuyHold:boolean;
  passed:boolean; halted:boolean; haltReason:string|null; roundTrips:RoundTrip[]; assumptions:string[];
}
export function utcDay(t:number) { return new Date(t).toISOString().slice(0,10); }
export function newPortfolio(capital:number, now:number):Portfolio {
  if (!Number.isFinite(capital) || capital <= 0 || capital > 1_000_000) throw new Error('حدد سقف رأس مال موجبًا بنفسك، بحد أقصى مليون USDT.');
  return {initial:capital,cash:capital,position:null,trades:[],buyFees:0,day:utcDay(now),dayStart:capital,pausedDay:null,halted:false,haltReason:null,lastSignal:0,peak:capital,maxDrawdown:0};
}
export function netEquity(p:Portfolio, price:number) {
  return p.cash+((p.position?.quantity??0)+(p.dust?.quantity??0))*price*(1-POLICY.slippage)*(1-POLICY.fee);
}
export function markRisk(p:Portfolio, price:number, now:number):string|null {
  if (!(price>0) || !Number.isFinite(price)) throw new Error('سعر سوق غير صالح');
  const value=netEquity(p,price), day=utcDay(now);
  if(p.day!==day){p.day=day;p.dayStart=value;p.pausedDay=null;}
  p.peak=Math.max(p.peak,value);p.maxDrawdown=Math.max(p.maxDrawdown,1-value/p.peak);
  if(p.halted) return p.haltReason;
  if(value<=p.initial*(1-POLICY.totalLoss)) { p.halted=true;p.haltReason='total_loss_15';return p.haltReason; }
  if(value<=p.dayStart*(1-POLICY.dailyLoss) || p.pausedDay===day){p.pausedDay=day;return 'daily_loss_3';}
  return null;
}
const SCALE=10n**18n;
function atoms(s:string):bigint {
  if(!/^\d+(?:\.\d+)?$/.test(s))throw new Error('قيمة عشرية غير صالحة');
  const [a,b='']=s.split('.');
  if(b.slice(18).replace(/0/g,'').length)throw new Error('دقة عدد غير مدعومة');
  return BigInt(a)*SCALE+BigInt(b.slice(0,18).padEnd(18,'0'));
}
function decimal(v:bigint):string {const a=v/SCALE,b=(v%SCALE).toString().padStart(18,'0').replace(/0+$/,'');return `${a}${b?'.'+b:''}`;}
export function floorStep(value:number,step:string):number { return Number(floorStepString(value,step)); }
export function floorStepString(value:number,step:string):string {
  if(!Number.isFinite(value)||value<0)throw new Error('كمية غير صالحة');
  const unit=atoms(step);if(unit<=0n)throw new Error('دقة كمية غير صالحة');
  return decimal(atoms(value.toFixed(18))/unit*unit);
}
export function entryQuantity(budget:number,price:number,f:Filters):number {
  const q=floorStep(budget/(price*(1+POLICY.fee)),f.marketStep);
  const cost=q*price*(1+POLICY.fee);
  if(q<f.marketMinQty || q>f.marketMaxQty || q<f.minQty || q>f.maxQty || q*price<f.minNotional || q*price>f.maxNotional || cost>budget+1e-9)return 0;
  return q;
}
function mean(v:number[]) {return v.reduce((a,b)=>a+b,0)/v.length;}
export function signal(candles:Candle[]):Signal {
  const last=candles.at(-1);
  const none={enter:false,exit:false,score:0,stopPct:POLICY.stopMin,reason:'بيانات غير كافية',at:last?.closeTime??0};
  if(candles.length<POLICY.warmup)return none;
  const c=candles.slice(-POLICY.warmup),cl=c.map(x=>x.close),price=last!.close;
  const sma20=mean(cl.slice(-20)),sma50=mean(cl.slice(-50)),sma200=mean(cl.slice(-200));
  const before50=mean(cl.slice(-55,-5));
  let gain=0,loss=0;
  for(let i=cl.length-14;i<cl.length;i++){const d=cl[i]-cl[i-1];gain+=Math.max(0,d);loss+=Math.max(0,-d);}
  const rsi=loss===0?(gain===0?50:100):100-100/(1+gain/loss);
  let tr=0;for(let i=c.length-14;i<c.length;i++)tr+=Math.max(c[i].high-c[i].low,Math.abs(c[i].high-c[i-1].close),Math.abs(c[i].low-c[i-1].close));
  const atr=tr/14;
  const trend=price>sma20&&sma20>sma50&&sma50>sma200&&sma50>before50;
  const momentum=rsi>=55&&rsi<=75;
  const breakout=price>Math.max(...c.slice(-21,-1).map(x=>x.high));
  const volume=last!.volume>=mean(c.slice(-21,-1).map(x=>x.volume));
  const score=(trend?35:0)+(momentum?25:0)+(breakout?25:0)+(volume?15:0);
  return {enter:trend&&momentum&&breakout&&score>=POLICY.minScore,exit:sma20<sma50,score,stopPct:Math.min(POLICY.stopMax,Math.max(POLICY.stopMin,2*atr/price)),reason:`اتجاه ${trend?'صاعد':'غير مؤهل'}؛ RSI ${rsi.toFixed(1)}؛ اختراق ${breakout?'نعم':'لا'}؛ تقييم قواعد ${score}/100`,at:last!.closeTime};
}
export function paperBuy(p:Portfolio,s:Signal,market:number,now:number,f:Filters) {
  if(p.position||p.halted||p.pausedDay===utcDay(now)||!s.enter||s.at<=p.lastSignal)return false;
  p.lastSignal=s.at;
  const price=market*(1+POLICY.slippage),budget=Math.min(p.initial*POLICY.allocation,p.cash);
  const quantity=entryQuantity(budget,price,f);if(!quantity)return false;
  const protectedQty=floorStep(quantity*(1-POLICY.fee),f.step);
  if(protectedQty<f.minQty||protectedQty*floorStep(price*(1-s.stopPct),f.tick)<f.minNotional)return false;
  const cost=quantity*price*(1+POLICY.fee);p.cash-=cost;p.buyFees+=quantity*price*POLICY.fee;
  p.position={id:`paper-${s.at}`,quantity,entry:price,cost,stop:price*(1-s.stopPct),target:price*(1+2*s.stopPct),at:now,score:s.score,entryFees:quantity*price*POLICY.fee};
  return true;
}
export function paperSell(p:Portfolio,market:number,now:number,reason:string) {
  const pos=p.position;if(!pos)return null;
  const price=market*(1-POLICY.slippage),proceeds=pos.quantity*price*(1-POLICY.fee);
  const trade:RoundTrip={id:pos.id,enteredAt:pos.at,exitedAt:now,quantity:pos.quantity,entry:pos.entry,exit:price,cost:pos.cost,proceeds,netPnl:proceeds-pos.cost,fees:pos.quantity*pos.entry*POLICY.fee+pos.quantity*price*POLICY.fee,reason};
  p.cash+=proceeds;p.position=null;p.trades.push(trade);return trade;
}
/** Signals use only the preceding CLOSED bar. Executions occur on the next bar. */
export function backtest(candles:Candle[],start:number,end:number,capital:number,f:Filters,dataHash:string):BacktestReport {
  validateCandles(candles,POLICY.intervalMs);
  const first=candles.findIndex(c=>c.time>=start);let last=candles.length-1;while(last>=0&&candles[last].closeTime>=end)last--;
  if(first<POLICY.warmup || last<=first || candles[first].time!==start || candles[last].closeTime+1!==end)throw new Error('نافذة الاختبار أو فترة التهيئة ناقصة');
  const p=newPortfolio(capital,start);
  for(let i=first;i<=last;i++) {
    const bar=candles[i],s=signal(candles.slice(Math.max(0,i-POLICY.warmup),i));
    let risk=markRisk(p,bar.open,bar.time);
    if(risk&&p.position)paperSell(p,bar.open,bar.time,risk);
    if(p.position&&s.exit)paperSell(p,bar.open,bar.time,'trend_exit');
    // A position closed in this bar cannot re-enter until a subsequent bar.
    if(!p.position&&!risk)paperBuy(p,s,bar.open,bar.time,f);
    const pos=p.position;
    if(pos) {
      if(bar.low<=pos.stop)paperSell(p,Math.min(bar.open,pos.stop),bar.time,'stop_loss');
      else if(bar.high>=pos.target)paperSell(p,pos.target,bar.time,'take_profit');
    }
    risk=markRisk(p,bar.close,bar.closeTime);
    if(risk&&p.position)paperSell(p,bar.close,bar.closeTime,risk);
  }
  if(p.position)paperSell(p,candles[last].close,end-1,'test_end_liquidation');
  markRisk(p,candles[last].close,end-1);
  const holdQ=entryQuantity(capital,candles[first].open*(1+POLICY.slippage),f);
  const holdCost=holdQ*candles[first].open*(1+POLICY.slippage)*(1+POLICY.fee);
  const buyHoldEquity=capital-holdCost+holdQ*candles[last].close*(1-POLICY.slippage)*(1-POLICY.fee);
  return {policyId:POLICY_ID,strategy:POLICY.version,source:'Binance public market data',dataHash,start,end,warmupCandles:first,candles:last-first+1,capital,finalEquity:p.cash,netPnl:p.cash-capital,netReturn:p.cash/capital-1,fees:p.trades.reduce((a,t)=>a+t.fees,0),feePerSide:POLICY.fee,slippagePerSide:POLICY.slippage,trades:p.trades.length,winRate:p.trades.length?p.trades.filter(t=>t.netPnl>0).length/p.trades.length:0,maxDrawdown:p.maxDrawdown,buyHoldEquity,buyHoldReturn:buyHoldEquity/capital-1,beatBuyHold:p.cash>buyHoldEquity,passed:p.cash>capital&&p.trades.length>=3&&!p.halted,halted:p.halted,haltReason:p.haltReason,roundTrips:p.trades,assumptions:['تكلفة كل جهة: رسوم 0.1% وانزلاق 0.05%؛ لا عوائد على النقد.','إشارات شموع 4 ساعات مغلقة، تنفيذ في افتتاح الشمعة التالية.','إذا لمس السعر الوقف والهدف في الشمعة نفسها، يُفترض تنفيذ الوقف أولًا؛ فجوة الوقف بالسعر الأسوأ.','حدود كمية وقيمة الأوامر الحالية؛ بيانات حدود Binance التاريخية غير متاحة في الشموع.','اشترِ واحتفظ بكامل رأس المال في نفس الفترة، مع نفس تكاليف الدخول والخروج.','نتيجة تاريخية؛ ليست احتمال نجاح أو ضمان أرباح.']};
}
export function validateCandles(c:Candle[],interval:number) {
  if(!c.length)throw new Error('بيانات أسعار فارغة');
  for(let i=0;i<c.length;i++) {
    const b=c[i];
    if(![b.time,b.open,b.high,b.low,b.close,b.volume,b.closeTime].every(Number.isFinite)||b.time%interval!==0||b.closeTime!==b.time+interval-1||Math.min(b.open,b.high,b.low,b.close)<=0||b.volume<0||b.high<Math.max(b.open,b.close,b.low)||b.low>Math.min(b.open,b.close,b.high)||(i>0&&b.time!==c[i-1].time+interval))throw new Error('شموع ناقصة أو مكررة أو غير صالحة؛ توقف الإثبات');
  }
}
export interface PaperProof { startedAt:number; lastHeartbeat:number; observedMs:number; missedMs:number; invalid:boolean; invalidReason:string|null; policyId:string; portfolio:Portfolio; lastPrice:number }
export function newPaper(capital:number,now:number):PaperProof {return {startedAt:now,lastHeartbeat:now,observedMs:0,missedMs:0,invalid:false,invalidReason:null,policyId:POLICY_ID,portfolio:newPortfolio(capital,now),lastPrice:0};}
export function heartbeat(proof:PaperProof,now:number) {
  const gap=now-proof.lastHeartbeat;
  if(gap<0) {proof.invalid=true;proof.invalidReason='clock_moved_backwards';return;}
  if(gap>POLICY.maxHeartbeatGapMs){proof.missedMs+=gap;proof.invalid=true;proof.invalidReason='server_or_market_data_gap';}
  else proof.observedMs+=gap;
  proof.lastHeartbeat=now;
}
export function paperGate(proof:PaperProof|null,now:number,capital:number|null) {
  if(!proof||capital===null)return false;
  return !proof.invalid&&proof.policyId===POLICY_ID&&proof.portfolio.initial===capital&&!proof.portfolio.halted&&proof.portfolio.trades.length>=3&&now-proof.startedAt>=POLICY.proofDays*86400000&&proof.observedMs>=POLICY.proofDays*86400000&&now-proof.lastHeartbeat<=POLICY.maxHeartbeatGapMs&&proof.lastPrice>0&&netEquity(proof.portfolio,proof.lastPrice)>capital;
}
export function underperforms(live:Portfolio,shadow:Portfolio,startedAt:number,now:number,price:number) {
  return now-startedAt>=POLICY.comparisonDays*86400000&&live.trades.length>=POLICY.comparisonTrades&&netEquity(live,price)/live.initial-netEquity(shadow,price)/shadow.initial<=-POLICY.underperformancePoints;
}
