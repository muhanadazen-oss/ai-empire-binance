import { randomUUID } from 'node:crypto';
import { POLICY, POLICY_ID, paperGate, newPaper, newPortfolio, paperBuy, paperSell, netEquity, signal, heartbeat, markRisk, utcDay, underperforms, floorStep, type Candle, type Signal } from './core.ts';
import { recentCandles, spotPrices, exchangeFilters, marketGet } from './market.ts';
import { TradingStore, type RuntimeState, type Notice, type Intent } from './store.ts';
import { SpotBroker, ExchangeFailure, type Fill, type OwnedIds } from './binance-spot.ts';
import { runBacktest } from './backtest-cli.ts';
export interface RuntimeConfig { expectedIp?:string; webhook?:string; webhookToken?:string; evidenceDirectory:string }
export function activationReasons(s:RuntimeState,now:number,notificationsReady:boolean):string[] {
  const reasons:string[]=[];
  if(s.capital===null)reasons.push('حدد سقف رأس المال بنفسك؛ الوكلاء لا يحددونه.');
  if(s.policyId!==POLICY_ID)reasons.push('نسخة الاستراتيجية مختلفة؛ يلزم إثبات جديد.');
  if(!s.backtest||s.backtest.policyId!==POLICY_ID||s.backtest.capital!==s.capital||!s.backtest.passed)reasons.push('اختبار السنتين لم يربح بعد التكاليف على سقفك المحدد.');
  if(!paperGate(s.paper,now,s.capital)||s.completedAt===null)reasons.push('لم يكتمل إثبات 60 يومًا خادميًا مربحًا على الأسعار الحقيقية.');
  if(now-s.lastHeartbeat>POLICY.maxHeartbeatGapMs||s.lastPrice<=0)reasons.push('خادم التداول أو بيانات السوق غير متصلة.');
  if(!s.verification||now-s.verification.checkedAt>60_000)reasons.push('لم يُتحقق حديثًا من مفتاح Spot وصلاحياته وIP الخادم.');
  if(!notificationsReady)reasons.push('إشعاراتك اليومية والتنبيهات لم تُوصل وتُختبر.');
  if(s.emergency||s.phase==='halted'||s.live?.portfolio.halted)reasons.push('إيقاف الطوارئ أو الإيقاف الدائم مفعّل.');
  if(s.live||s.job)reasons.push('جلسة حقيقية قائمة أو اختبار قيد التشغيل.');
  return reasons;
}
export class TradingRuntime {
  state:RuntimeState; store:TradingStore; config:RuntimeConfig; broker:SpotBroker|null;
  #queue:Promise<unknown>=Promise.resolve();#candles:Candle[]=[];#lastCandleFetch=0;#webhookReady=false;#lastDelivery=0;#clockCheck=0;
  constructor(store:TradingStore,config:RuntimeConfig,broker:SpotBroker|null) {
    this.store=store;this.state=store.load();this.config=config;this.broker=broker;
    if(this.state.policyId!==POLICY_ID){this.state.phase='halted';this.state.error='تغيّرت نسخة الاستراتيجية؛ التداول مقفول ويحتاج إثباتًا جديدًا.';}
    if(this.state.job){this.state.job=null;this.state.error='توقف الاختبار قبل اكتماله؛ أعد تشغيله.';}
    this.persist();
  }
  serial<T>(operation:()=>Promise<T>):Promise<T> {const next=this.#queue.then(operation,operation);this.#queue=next.catch(()=>{});return next;}
  persist(){this.store.save(this.state);}
  notice(kind:string,text:string,data:Record<string,unknown>={}) {
    this.state.notices.push({id:randomUUID(),at:Date.now(),kind,text,data,deliveredAt:null,attempts:0});this.persist();
  }
  async deliverNotices() {
    if(!this.config.webhook)return;
    const url=new URL(this.config.webhook);if(url.protocol!=='https:')throw new Error('إشعاراتك تحتاج عنوان HTTPS');
    for(const n of this.state.notices.filter(v=>v.deliveredAt===null).slice(0,3)) {
      n.attempts++;this.persist();
      try {
        const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':n.id,...(this.config.webhookToken?{Authorization:`Bearer ${this.config.webhookToken}`}:{})},body:JSON.stringify({application:'AI EMPIRE',...n}),signal:AbortSignal.timeout(8_000),redirect:'error'});
        if(!r.ok)throw new Error('notification_delivery_failed');n.deliveredAt=Date.now();this.#webhookReady=true;this.#lastDelivery=Date.now();this.persist();
      } catch {this.#webhookReady=false;this.persist();break;}
    }
  }
  async configure(capital:unknown) {
    if(this.state.paper||this.state.live||this.state.job)throw new Error('السقف ثابت بعد بدء الإثبات؛ لا يستطيع البوت تعديله.');
    if(typeof capital!=='number')throw new Error('اكتب المبلغ بنفسك');newPortfolio(capital,Date.now());
    this.state.capital=capital;this.state.backtest=null;this.state.error=null;this.persist();
  }
  queueHistory() {
    this.reserveHistory();
    void this.serial(()=>this.runHistory()).catch(()=>{});
  }
  reserveHistory() {
    const s=this.state;if(s.capital===null||s.paper||s.live||s.job||s.phase==='halted')throw new Error('حدد السقف قبل الاختبار؛ لا يبدأ اختبار أثناء جلسة تداول أو إيقاف دائم.');
    s.job={kind:'backtest',startedAt:Date.now()};s.error=null;this.persist();
  }
  async testHistory() {this.reserveHistory();await this.runHistory();}
  private async runHistory() {
    const s=this.state;
    try{if(s.capital===null)throw new Error('حدد سقف رأس المال أولًا.');s.backtest=await runBacktest(s.capital,this.config.evidenceDirectory);s.filters=await exchangeFilters();this.notice('backtest',s.backtest.passed?'اجتاز الاختبار التاريخي؛ يلزم إثبات 60 يومًا قبل التفعيل.':'الاختبار التاريخي خسر أو لم يجتز؛ التداول الحقيقي مقفول.',{netPnl:s.backtest.netPnl,netReturn:s.backtest.netReturn,buyHoldReturn:s.backtest.buyHoldReturn});}
    catch(e){s.error=safeError(e);throw e;}finally{s.job=null;this.persist();}
  }
  async startPaper(restart=false) {
    const s=this.state;
    if(s.capital===null||!s.backtest||s.live||s.job||s.phase==='halted')throw new Error('أكمل الاختبار التاريخي على سقفك أولًا.');
    if(s.paper&&!restart)throw new Error('التجربة قائمة؛ لن تُعاد كتابة تاريخ بدايتها.');
    const bars=await recentCandles();s.filters=await exchangeFilters();
    s.paper=newPaper(s.capital,Date.now());s.phase='paper';s.completedAt=null;s.lastPaperSignal=bars.at(-1)!.closeTime;s.error=null;s.emergency=false;this.#candles=bars;this.#lastCandleFetch=Date.now();this.persist();
    this.notice('paper_started','بدأت تجربة خادمية جديدة لمدة 60 يومًا فعليًا، بلا مال حقيقي.',{capital:s.capital});
  }
  async verifyConnection() {
    if(!this.broker||!this.config.expectedIp)throw new Error('مفتاح Spot وIP ثابت لم يُجهزا على الخادم.');
    this.state.verification=null;this.persist();
    this.state.verification=await this.broker.verify(this.config.expectedIp);this.persist();
    return this.state.verification;
  }
  async testNotifications() {
    if(!this.config.webhook)throw new Error('عنوان إشعاراتك لم يُجهز على الخادم.');
    this.notice('notification_test','إشعارات AI EMPIRE متصلة؛ هذا فحص اتصال دون تداول.');await this.deliverNotices();
    if(!this.#webhookReady)throw new Error('فشل اختبار الإشعارات.');
  }
  async activate(ack:unknown) {
    if(ack!=='ACTIVATE_LIVE')throw new Error('يلزم ضغط زر التفعيل يدويًا.');
    // Check proofs before touching an exchange credential.
    const reasons=activationReasons(this.state,Date.now(),this.#webhookReady).filter(v=>!v.startsWith('لم يُتحقق حديثًا'));
    if(reasons.length)throw new Error(reasons.join(' '));
    await this.verifyConnection();
    const s=this.state,account=await this.broker!.account();
    if(!Array.isArray(account.balances))throw new Error('رصيد Binance غير صالح');
    const usdt=Number(account.balances.find((v:any)=>v.asset==='USDT')?.free);
    if(!Number.isFinite(usdt)||usdt<s.capital!)throw new Error('رصيد USDT الحر لا يغطي السقف المحدد.');
    // Require an isolated Spot account for this symbol; never sell a user's pre-existing BTC.
    const btc=account.balances.find((v:any)=>v.asset==='BTC');
    if(Number(btc?.free??0)+Number(btc?.locked??0)>1e-12||(await this.broker!.openOrders()).length)throw new Error('يلزم حساب Spot مخصص خالٍ من BTC وأوامر BTC أخرى؛ البوت لا يبيع مقتنياتك السابقة.');
    const now=Date.now();s.live={startedAt:now,portfolio:newPortfolio(s.capital!,now),shadow:newPortfolio(s.capital!,now),intent:null,ids:null,protected:false,accountedOrders:[],fills:[],lastSeenSignal:this.#candles.at(-1)?.closeTime??0,closeReason:null,totalFees:0,baselineQuote:usdt,riskNoticeDay:null};
    s.phase='live';s.error=null;this.persist();this.notice('live_activated','فعّلت التداول الحقيقي يدويًا بعد الإثبات؛ حدود المخاطر ثابتة.',{capital:s.capital});
  }
  async emergency() {
    const s=this.state;this.requestEmergency();
    if(s.live){s.live.portfolio.halted=true;s.live.portfolio.haltReason='emergency_stop';s.live.closeReason='emergency_stop';s.phase='halted';this.persist();try{await this.closeLive('emergency_stop');}catch(e){s.error=safeError(e);this.notice('emergency_close_pending','الطوارئ مفعلة، لكن إغلاق Binance لم يُؤكد بعد؛ لم يُرسل بيع مكرر.',{error:s.error,remainingQuantity:(s.live.portfolio.position?.quantity??0)+(s.live.portfolio.dust?.quantity??0)});await this.deliverNotices();throw e;}}
    else if(s.paper){paperSell(s.paper.portfolio,s.lastPrice||s.paper.lastPrice,Date.now(),'emergency_stop');s.paper.invalid=true;s.paper.invalidReason='manual_emergency';s.phase='halted';this.persist();}
    else {s.phase='halted';this.persist();}
    this.notice('emergency','تم منع الصفقات الجديدة وطلب إغلاق مراكز البوت. راجع حالة الإغلاق؛ لا يُعتبر مغلقًا حتى يؤكده Binance.',{remainingQuantity:(s.live?.portfolio.position?.quantity??0)+(s.live?.portfolio.dust?.quantity??0)});
    await this.deliverNotices();
  }
  requestEmergency(){this.state.emergency=true;this.persist();}
  async tick() {
    const s=this.state,now=Date.now();
    try {
      if(now-this.#clockCheck>60_000){const t=Number((await marketGet('/api/v3/time')).serverTime);if(!Number.isSafeInteger(t)||Math.abs(t-Date.now())>30_000)throw new Error('clock_or_exchange_time_error');this.#clockCheck=now;}
      const prices=await spotPrices();s.lastPrice=prices.prices.BTC;
      if(now-this.#lastCandleFetch>60_000||!this.#candles.length){this.#candles=await recentCandles();this.#lastCandleFetch=now;}
      const analysis=signal(this.#candles);
      if(s.paper&&(s.phase==='paper'||s.phase==='paper_complete')) {
        heartbeat(s.paper,now);s.paper.lastPrice=s.lastPrice;
        if(s.phase==='paper') {
          this.paperStep(s.paper.portfolio,analysis,s.lastPrice,now,s.lastPaperSignal);
          s.lastPaperSignal=analysis.at;
          if(s.paper.observedMs>=POLICY.proofDays*86400000&&now-s.paper.startedAt>=POLICY.proofDays*86400000){paperSell(s.paper.portfolio,s.lastPrice,now,'paper_60_days_complete');s.completedAt=now;s.phase='paper_complete';this.notice('paper_complete','اكتملت فترة الإثبات. لا يبدأ التداول الحقيقي تلقائيًا؛ يلزم اجتياز الشروط وزر التفعيل.',{netPnl:s.paper.portfolio.cash-s.paper.portfolio.initial,valid:!s.paper.invalid});}
        }
        if(s.paper.invalid&&!s.error){s.error='انقطع الخادم أو بيانات السوق؛ هذه التجربة لا تجتاز الإثبات، ويلزم بدء 60 يومًا جديدة.';this.notice('paper_gap',s.error);}
      }
      if(s.live) {
        const live=s.live;
        if(!s.verification||now-s.verification.checkedAt>60_000)await this.verifyConnection();
        if(s.lastHeartbeat&&now-s.lastHeartbeat>POLICY.maxHeartbeatGapMs){live.portfolio.halted=true;live.portfolio.haltReason='server_gap';live.closeReason='server_gap';s.phase='halted';this.notice('server_gap','انقطع خادم التداول؛ أُوقفت الصفقات الجديدة ويجري إغلاق مراكز البوت.');}
        await this.reconcile();
        const risk=markRisk(live.portfolio,s.lastPrice,now);
        if(risk){live.closeReason=risk;if(live.portfolio.halted)s.phase='halted';if(live.riskNoticeDay!==`${risk}:${utcDay(now)}`){live.riskNoticeDay=`${risk}:${utcDay(now)}`;this.notice('risk_stop',risk==='total_loss_15'?'وصل حد الخسارة الكلي 15%؛ توقف البوت نهائيًا وطلب الإغلاق.':risk==='daily_loss_3'?'وصل حد الخسارة اليومي 3%؛ توقف البوت حتى يوم UTC التالي وطلب الإغلاق.':'البوت متوقف ويعمل على تأكيد إغلاق مراكزه.',{reason:risk,equity:netEquity(live.portfolio,s.lastPrice)});}this.persist();await this.closeLive(risk);}
        if(s.phase==='live'&&!live.portfolio.halted&&!s.emergency) {
          this.paperStep(live.shadow,analysis,s.lastPrice,now,live.lastSeenSignal);
          if(underperforms(live.portfolio,live.shadow,live.startedAt,now,s.lastPrice)){live.portfolio.halted=true;live.portfolio.haltReason='paper_underperformance';live.closeReason='paper_underperformance';s.phase='halted';this.notice('underperformance','الأداء الحقيقي أقل من تجربة موازية بـ5 نقاط مئوية أو أكثر، بعد 7 أيام و10 صفقات؛ أُوقف التداول.',{liveEquity:netEquity(live.portfolio,s.lastPrice),paperEquity:netEquity(live.shadow,s.lastPrice)});await this.closeLive('paper_underperformance');}
          else if(live.portfolio.position&&analysis.exit)await this.closeLive('trend_exit');
          else if(!live.portfolio.position&&!live.intent&&analysis.at>live.lastSeenSignal&&analysis.enter&&!risk)await this.openLive(analysis);
          live.lastSeenSignal=analysis.at;
        }
        if((s.phase==='halted'||live.closeReason)&&live.portfolio.position)await this.closeLive(live.closeReason??'halted');
      }
      s.lastHeartbeat=now;
      if(s.lastReportDay!==utcDay(now)&&!s.job&&(s.paper||s.live)) {
        const p=s.live?.portfolio??s.paper!.portfolio,value=netEquity(p,s.lastPrice),previous=s.lastReportDay;
        this.notice('daily_report','تقرير AI EMPIRE اليومي: الرصيد والصفقات وصافي الربح/الخسارة بعد الرسوم.',{day:utcDay(now),mode:s.live?'live':'paper',capital:p.initial,cash:p.cash,equity:value,netPnl:value-p.initial,realizedNetPnl:p.trades.reduce((a,t)=>a+t.netPnl,0),openPositions:p.position?1:0,closedTrades:p.trades.length,trades:p.trades.filter(t=>!previous||utcDay(t.exitedAt)>=previous),actualFees:s.live?.totalFees??(p.trades.reduce((a,t)=>a+t.fees,0)+(p.position?.entryFees??0)+(p.dust?.entryFees??0)),feeValuation:'عملات الرسوم الأخرى تُقيّم بـUSDT بسعر آخر شمعة دقيقة مغلقة وقت التنفيذ؛ كمية الرسوم فعلية.'});s.lastReportDay=utcDay(now);
      }
      this.persist();await this.deliverNotices();
      if(s.phase==='live'&&!this.#webhookReady&&now-this.#lastDelivery>30*60_000){s.live!.portfolio.halted=true;s.live!.portfolio.haltReason='notifications_unavailable';s.live!.closeReason='notifications_unavailable';s.phase='halted';this.notice('notifications_unavailable','تعذر إيصال الإشعارات؛ أوقف البوت فتح الصفقات وطلب الإغلاق.');await this.closeLive('notifications_unavailable');}
    } catch(e) {
      s.error=safeError(e);
      if(s.live){if(!s.live.portfolio.halted){s.live.portfolio.halted=true;s.live.portfolio.haltReason='data_or_execution_error';}s.live.closeReason=s.live.portfolio.haltReason??'data_or_execution_error';s.phase='halted';this.persist();try{await this.closeLive(s.live.closeReason);}catch{/* never claim a failed close succeeded */}}
      this.persist();const last=s.notices.at(-1);if(last?.kind!=='runtime_error'||now-last.at>300_000)this.notice('runtime_error',s.error,{remainingQuantity:s.live?.portfolio.position?.quantity??0});
      await this.deliverNotices();
    }
  }
  paperStep(p:ReturnType<typeof newPortfolio>,a:Signal,price:number,now:number,lastSeen:number) {
    const risk=markRisk(p,price,now);
    if(p.position) {
      const reason=risk??(price<=p.position.stop?'stop_loss':price>=p.position.target?'take_profit':a.exit?'trend_exit':null);
      if(reason)paperSell(p,price,now,reason);
    }
    if(!p.position&&!risk&&a.at>lastSeen&&now-a.at<=POLICY.maxHeartbeatGapMs)paperBuy(p,a,price,now,this.state.filters!);
  }
  ids():OwnedIds {const suffix=randomUUID().replaceAll('-','').slice(0,20);return {buy:'emp-b-'+suffix,list:'emp-l-'+suffix,above:'emp-t-'+suffix,below:'emp-s-'+suffix};}
  async openLive(a:Signal) {
    const s=this.state,l=s.live!;if(l.intent||l.portfolio.position||l.portfolio.halted||s.phase!=='live'||s.emergency)return;
    await this.verifyConnection();s.filters=await exchangeFilters();
    if((await this.broker!.openOrders()).some((o:any)=>!String(o.clientOrderId).startsWith('emp-')))throw new Error('وجدت أوامر BTC خارج البوت؛ توقف التنفيذ.');
    await this.verifyManagedBalance();
    if((await this.broker!.openOrders()).length)throw new Error('وجدت أوامر غير مسوّاة على الأصل؛ لا يمكن إنفاق مال جديد.');
    const budget=Math.min(s.capital!*POLICY.allocation-(l.portfolio.dust?.cost??0),l.portfolio.cash),quote=Math.floor(budget/(1+POLICY.fee)*1e8)/1e8;
    const price=(await spotPrices()).prices.BTC;
    const limit=floorStep(price*(1+POLICY.slippage),s.filters.tick),gross=floorStep(quote/limit,s.filters.step),protectedQ=floorStep(gross*(1-POLICY.fee),s.filters.step);
    // Respect the stop's minimum notional BEFORE buying; never raise capital to meet it.
    if(protectedQ<s.filters.minQty||protectedQ*floorStep(price*(1-a.stopPct),s.filters.tick)<s.filters.minNotional||s.emergency||l.portfolio.halted)return;
    l.intent={kind:'buy',ids:this.ids(),closeId:null,signal:a,attemptedAt:Date.now(),orderId:null,reason:'strategy_entry',flatten:false};this.persist();
    try{const result=await this.broker!.buy(l.intent.ids.buy,quote,price,s.filters);l.intent.orderId=result.orderId;this.persist();}
    catch(e){if(e instanceof ExchangeFailure&&!e.ambiguous){l.intent=null;this.persist();throw e;}throw e;}
    await this.reconcile();
    if(s.emergency)await this.closeLive('emergency_stop');
  }
  async accountFill(fill:Fill,reason:string) {
    const l=this.state.live!,p=l.portfolio;if(l.accountedOrders.includes(fill.orderId))return;
    if(fill.side==='BUY') {
      if(p.position)throw new Error('شراء مكرر؛ توقف المصالحة');
      const cost=fill.quote+fill.quoteFee+fill.otherFee;
      if(cost+(p.dust?.cost??0)>this.state.capital!*POLICY.allocation+1e-8||cost>p.cash+1e-8) {p.halted=true;p.haltReason='capital_limit_violation';l.closeReason='capital_limit_violation';this.state.phase='halted';}
      const a=l.intent!.signal;p.cash-=cost;p.buyFees+=fill.fees;
      p.position={id:fill.clientId,quantity:fill.netBase+(p.dust?.quantity??0),entry:fill.price,cost:cost+(p.dust?.cost??0),stop:fill.price*(1-a.stopPct),target:fill.price*(1+2*a.stopPct),at:fill.at,score:a.score,entryFees:fill.fees+(p.dust?.entryFees??0)};p.dust=undefined;
      l.ids=l.intent!.ids;l.protected=false;
    } else {
      const pos=p.position;if(!pos)throw new Error('بيع لا يطابق مركز البوت');
      if(fill.baseSpent>pos.quantity+1e-10)throw new Error('التنفيذ يتجاوز كمية البوت؛ توقف المصالحة');
      const fraction=Math.min(1,fill.baseSpent/pos.quantity),cost=pos.cost*fraction,proceeds=fill.quote-fill.quoteFee-fill.otherFee;
      p.cash+=proceeds;p.trades.push({id:fill.clientId,enteredAt:pos.at,exitedAt:fill.at,quantity:fill.baseSpent,entry:pos.entry,exit:fill.price,cost,proceeds,netPnl:proceeds-cost,fees:(pos.entryFees??0)*fraction+fill.fees,reason});
      pos.quantity=Math.max(0,pos.quantity-fill.baseSpent);pos.cost-=cost;pos.entryFees=(pos.entryFees??0)*(1-fraction);
      if(pos.quantity<1e-12){p.position=null;l.ids=null;l.protected=false;l.closeReason=null;}
      else if(pos.quantity<Number(this.state.filters!.step)) {p.dust={quantity:pos.quantity,cost:pos.cost,entryFees:pos.entryFees??0};p.position=null;l.ids=null;l.protected=false;l.closeReason=null;}
      else {l.protected=false;l.closeReason='remaining_partial_fill';p.halted=true;p.haltReason=l.closeReason;this.state.phase='halted';}
    }
    l.totalFees+=fill.fees;l.fills.push(fill);l.accountedOrders.push(fill.orderId);this.persist();
  }
  async reconcile() {
    const l=this.state.live;if(!l||!this.broker)return;
    const intent=l.intent;
    if(intent?.kind==='buy') {
      const order=await this.finalBuy(intent.ids.buy);
      if(!order)throw new Error('نتيجة أمر الشراء غير محسومة؛ لن يُكرر أو يُرسل أمر جديد.');
      if(Number(order.executedQty)>0) {await this.accountFill(await this.broker.fill(order),'buy');intent.kind='protect';this.persist();}
      else if(['REJECTED','EXPIRED','CANCELED'].includes(order.status)){l.intent=null;this.persist();return;}
      else throw new Error('أمر الشراء غير مكتمل؛ يلزم التحقق قبل أي إنفاق جديد.');
    }
    if(l.intent?.kind==='protect'&&l.portfolio.position) {
      const pos=l.portfolio.position,ids=l.intent.ids;
      let list=await this.broker.orderList(ids.list);
      if(!list) {
        if(l.intent.orderId===-1)throw new Error('نتيجة أمر الحماية غير محسومة؛ لم يُكرر الأمر.');
        await this.verifyConnection();l.intent.orderId=-1;this.persist();
        try{await this.broker.protect(ids,pos.quantity,pos.entry,l.intent.signal,this.state.filters!);list=await this.broker.orderList(ids.list);}
        catch(e){if(!(e instanceof ExchangeFailure)||!e.ambiguous)l.intent.orderId=0;l.intent.flatten=true;l.closeReason='protection_failed';l.portfolio.halted=true;l.portfolio.haltReason='protection_failed';this.state.phase='halted';this.persist();throw e;}
      }
      const stop=await this.broker.order(ids.below);
      if(!list||!stop||stop.symbol!==POLICY.symbol||stop.side!=='SELL'||stop.type!=='STOP_LOSS'||Math.abs(Number(stop.origQty)-floorStep(pos.quantity,this.state.filters!.step))>1e-10||Number(stop.stopPrice)!==floorStep(pos.stop,this.state.filters!.tick))throw new Error('لم يؤكد Binance وقف الخسارة الصحيح لكمية المركز؛ يُمنع فتح صفقات أخرى.');
      l.protected=true;l.intent=null;this.persist();
    }
    if(l.ids&&l.portfolio.position) {
      const owned=l.ids;
      for(const id of [owned.below,owned.above]) {
        const order=await this.broker.order(id);
        if(order&&Number(order.executedQty)>0&&!l.accountedOrders.includes(order.orderId)) {
          if(!['FILLED','EXPIRED','CANCELED'].includes(order.status))throw new Error('أمر إغلاق جزئي غير نهائي؛ أُوقف التداول للمصالحة.');
          await this.accountFill(await this.broker.fill(order),id===owned.below?'stop_loss':'take_profit');
        }
      }
      if(l.portfolio.position&&l.protected) {
        const stop=await this.broker.order(owned.below);
        if(!stop||!['NEW','PARTIALLY_FILLED','FILLED'].includes(stop.status))throw new Error('أمر وقف Binance غير قائم؛ أُوقف التداول ويجب الإغلاق.');
      }
    }
    if(l.intent?.kind==='close') {
      const order=await this.broker.order(l.intent.closeId!);
      if(!order)throw new Error('نتيجة أمر الإغلاق غير محسومة؛ لن يُكرر البيع.');
      if(Number(order.executedQty)>0&&['FILLED','EXPIRED','CANCELED'].includes(order.status)){await this.accountFill(await this.broker.fill(order),l.intent.reason);l.intent=null;this.persist();}
      else if(['REJECTED','EXPIRED','CANCELED'].includes(order.status)){l.intent=null;this.persist();throw new Error('لم ينفذ Binance إغلاق المركز.');}
      else throw new Error('ينتظر تأكيد إغلاق Binance.');
    }
  }
  async closeLive(reason:string) {
    const s=this.state,l=s.live;if(!l||!this.broker)return;
    // Recover a buy that may have been accepted before a timeout/crash.
    if(l.intent?.kind==='buy'){const order=await this.finalBuy(l.intent.ids.buy);if(!order)throw new Error('أمر شراء غير محسوم؛ يلزم فحص Binance.');if(Number(order.executedQty)>0){await this.accountFill(await this.broker.fill(order),'buy');l.intent.kind='protect';l.intent.flatten=true;this.persist();}else if(['REJECTED','EXPIRED','CANCELED'].includes(order.status)){l.intent=null;this.persist();return;}else throw new Error('شراء غير محسوم؛ لا بيع لكمية غير مؤكدة.');}
    if(l.intent?.kind==='close'){await this.reconcile();return;}
    if(!l.portfolio.position)return;
    await this.verifyConnection();
    if(l.ids) {
      const list=await this.broker.orderList(l.ids.list);
      if(!list&&l.intent?.kind==='protect'&&l.intent.orderId===-1)throw new Error('نتيجة أمر الحماية غير محسومة؛ راجع Binance قبل بيع قد يتكرر.');
      if(list&&list.listOrderStatus!=='ALL_DONE'){await this.broker.cancelProtection(l.ids.list);}
      // Cancellation can race with a stop/target. Reconcile fills before selling any remainder.
      const owned=l.ids;
      for(const id of [owned.below,owned.above]){const order=await this.broker.order(id);if(order&&Number(order.executedQty)>0&&!l.accountedOrders.includes(order.orderId)){if(!['FILLED','CANCELED','EXPIRED'].includes(order.status))throw new Error('أمر الوقف ما زال ينفذ؛ يُمنع البيع المكرر.');await this.accountFill(await this.broker.fill(order),reason);}}
    }
    const pos=l.portfolio.position;if(!pos){l.intent=null;this.persist();return;}
    const f=s.filters!,quantity=floorStep(pos.quantity,f.marketStep);
    if(quantity<f.marketMinQty||quantity*s.lastPrice<f.minNotional)throw new Error('تبقى رصيد صغير أو كمية دون حد Binance؛ لم يُؤكد إغلاق كل الرصيد.');
    const ids=l.ids??this.ids(),closeId='emp-c-'+randomUUID().replaceAll('-','').slice(0,20);
    const a:Signal={enter:false,exit:true,score:pos.score,stopPct:(pos.entry-pos.stop)/pos.entry,reason,at:Date.now()};
    l.intent={kind:'close',ids,closeId,signal:a,attemptedAt:Date.now(),orderId:null,reason,flatten:true};l.protected=false;this.persist();
    try{const result=await this.broker.sell(closeId,quantity,f);l.intent.orderId=result.orderId;this.persist();}
    catch(e){if(e instanceof ExchangeFailure&&!e.ambiguous){l.intent=null;this.persist();}throw e;}
    await this.reconcile();
  }
  async finalBuy(id:string) {
    let order=await this.broker!.order(id);
    if(order&&['NEW','PARTIALLY_FILLED'].includes(order.status)) {
      await this.verifyConnection();await this.broker!.cancelBuy(id);order=await this.broker!.order(id);
      if(!order||!['FILLED','CANCELED','EXPIRED','REJECTED'].includes(order.status))throw new Error('أمر شراء جزئي غير محسوم؛ أوقف الإنفاق.');
    }
    return order;
  }
  async verifyManagedBalance() {
    const l=this.state.live;if(!l||l.intent)return;
    let account=await this.broker!.account();if(!Array.isArray(account.balances))throw new Error('تعذر مصالحة رصيد Spot');
    const btc=account.balances.find((v:any)=>v.asset==='BTC');
    const actual=Number(btc?.free??0)+Number(btc?.locked??0),tracked=(l.portfolio.position?.quantity??0)+(l.portfolio.dust?.quantity??0);
    if(!Number.isFinite(actual)||Math.abs(actual-tracked)>1e-10){await this.reconcile();account=await this.broker!.account();if(!Array.isArray(account.balances))throw new Error('تعذر مصالحة رصيد Spot');const latestBTC=account.balances.find((v:any)=>v.asset==='BTC'),amount=Number(latestBTC?.free??0)+Number(latestBTC?.locked??0),managed=(l.portfolio.position?.quantity??0)+(l.portfolio.dust?.quantity??0);if(!Number.isFinite(amount)||Math.abs(amount-managed)>1e-10)throw new Error('تغير BTC خارج سجل البوت؛ أُوقف التداول ولا تُباع أموال غير متتبعة.');}
    const quote=Number(account.balances.find((v:any)=>v.asset==='USDT')?.free);
    const expected=l.baselineQuote+l.fills.reduce((a,f)=>a+(f.side==='BUY'?-f.quote-f.quoteFee:f.quote-f.quoteFee),0);
    if(!Number.isFinite(quote)||Math.abs(quote-expected)>0.01)throw new Error('تغير USDT خارج سجل البوت؛ يلزم مصالحة يدوية، والسقف لن يُزاد تلقائيًا.');
  }
  snapshot() {
    const s=this.state,p=s.live?.portfolio??s.paper?.portfolio;
    return {policy:POLICY,phase:s.phase,capital:s.capital,connected:true,lastHeartbeat:s.lastHeartbeat,price:s.lastPrice,backtest:s.backtest,paper:s.paper?{startedAt:s.paper.startedAt,observedDays:s.paper.observedMs/86400000,missedMs:s.paper.missedMs,invalid:s.paper.invalid,invalidReason:s.paper.invalidReason,completedAt:s.completedAt,passed:paperGate(s.paper,Date.now(),s.capital),portfolio:s.paper.portfolio}:null,live:s.live?{startedAt:s.live.startedAt,portfolio:s.live.portfolio,shadow:s.live.shadow,protected:s.live.protected,orderPending:!!s.live.intent,actualFees:s.live.totalFees,fills:s.live.fills}:null,portfolio:p??null,verification:s.verification,notificationsReady:this.#webhookReady,canActivate:activationReasons(s,Date.now(),this.#webhookReady).length===0,activationReasons:activationReasons(s,Date.now(),this.#webhookReady),emergency:s.emergency,error:s.error,job:s.job,notices:s.notices.slice(-100).reverse()};
  }
}
function safeError(e:unknown){return e instanceof Error?e.message:'تعذر تحديث خادم التداول؛ التداول مقفول.';}
