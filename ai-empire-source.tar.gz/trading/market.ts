import { POLICY, validateCandles, type Candle, type Filters } from './core.ts';
const DATA='https://data-api.binance.vision';
export type Fetcher=typeof fetch;
export async function marketGet(path:string,query:Record<string,string>={},fetcher:Fetcher=fetch):Promise<any> {
  if(!['/api/v3/time','/api/v3/klines','/api/v3/ticker/price','/api/v3/exchangeInfo'].includes(path))throw new Error('مسار بيانات سوق غير مسموح');
  const r=await fetcher(`${DATA}${path}?${new URLSearchParams(query)}`,{signal:AbortSignal.timeout(12_000)});
  if(!r.ok)throw new Error(r.status===451?'Binance غير متاح من هذا الخادم؛ اختر خادمًا في منطقة مدعومة دون تجاوز الحظر.':`تعذر جلب أسعار Binance (${r.status})`);
  return r.json();
}
export function parseKlines(raw:unknown,interval=POLICY.intervalMs):Candle[] {
  if(!Array.isArray(raw))throw new Error('استجابة أسعار غير صالحة');
  const c=raw.map((v:any)=>({time:Number(v[0]),open:Number(v[1]),high:Number(v[2]),low:Number(v[3]),close:Number(v[4]),volume:Number(v[5]),closeTime:Number(v[6])}));
  validateCandles(c,interval);return c;
}
export async function recentCandles(fetcher:Fetcher=fetch,now=Date.now()):Promise<Candle[]> {
  const data=await marketGet('/api/v3/klines',{symbol:POLICY.symbol,interval:POLICY.interval,limit:String(POLICY.warmup+2)},fetcher);
  const bars=parseKlines(data);const closed=bars.filter(b=>b.closeTime<now);
  if(closed.length<POLICY.warmup||now-closed.at(-1)!.closeTime>POLICY.intervalMs+60_000)throw new Error('البيانات قديمة أو فترة التهيئة ناقصة');
  return closed;
}
export async function spotPrices(fetcher:Fetcher=fetch) {
  const started=Date.now();const data=await marketGet('/api/v3/ticker/price',{symbols:JSON.stringify(['BTCUSDT','ETHUSDT','SOLUSDT'])},fetcher);
  if(!Array.isArray(data))throw new Error('أسعار غير صالحة');
  const prices:Record<string,number>={};for(const s of ['BTC','ETH','SOL']){const value=Number(data.find((v:any)=>v.symbol===s+'USDT')?.price);if(!(value>0)||!Number.isFinite(value))throw new Error('سعر غير صالح');prices[s]=value;}
  return {source:'Binance',observedAt:started,prices};
}
export function parseFilters(raw:any):Filters {
  const s=raw?.symbols?.find((v:any)=>v.symbol===POLICY.symbol);
  if(!s||s.status!=='TRADING'||s.isSpotTradingAllowed!==true)throw new Error('الأصل غير متاح لتداول Spot');
  const find=(type:string)=>s.filters.find((v:any)=>v.filterType===type),lot=find('LOT_SIZE'),market=find('MARKET_LOT_SIZE'),price=find('PRICE_FILTER'),n=find('NOTIONAL')??find('MIN_NOTIONAL');
  if(!lot||!price||!n||!(Number(lot.stepSize)>0)||!(Number(price.tickSize)>0))throw new Error('حدود أوامر Binance ناقصة');
  const marketStep=Number(market?.stepSize)>0?market.stepSize:lot.stepSize;
  return {step:lot.stepSize,tick:price.tickSize,minQty:Number(lot.minQty),maxQty:Number(lot.maxQty),minNotional:Number(n.minNotional),maxNotional:Number(n.maxNotional??'1e30'),marketStep,marketMinQty:Math.max(Number(lot.minQty),Number(market?.minQty??0)),marketMaxQty:Math.min(Number(lot.maxQty),Number(market?.maxQty??lot.maxQty)),oco:s.ocoAllowed===true};
}
export async function exchangeFilters(fetcher:Fetcher=fetch):Promise<Filters>{return parseFilters(await marketGet('/api/v3/exchangeInfo',{symbol:POLICY.symbol},fetcher));}
export function twoYearWindow(now:number) {
  const end=Math.floor(now/POLICY.intervalMs)*POLICY.intervalMs, date=new Date(end);date.setUTCFullYear(date.getUTCFullYear()-2);
  const start=Math.floor(date.getTime()/POLICY.intervalMs)*POLICY.intervalMs;
  return {start,end};
}
export async function historicalCandles(start:number,end:number,fetcher:Fetcher=fetch,onProgress?:(count:number)=>void):Promise<Candle[]> {
  const all:Candle[]=[];let cursor=start-POLICY.warmup*POLICY.intervalMs;
  while(cursor<end) {
    const bars=parseKlines(await marketGet('/api/v3/klines',{symbol:POLICY.symbol,interval:POLICY.interval,startTime:String(cursor),endTime:String(end-1),limit:'1000'},fetcher));
    if(!bars.length||bars[0].time!==cursor)throw new Error('فجوة في بيانات الاختبار');
    all.push(...bars);cursor=bars.at(-1)!.time+POLICY.intervalMs;onProgress?.(all.length);
  }
  validateCandles(all,POLICY.intervalMs);if(all.at(-1)!.closeTime+1!==end)throw new Error('آخر شمعة اختبار ناقصة');return all;
}
