import type { User } from './auth.ts';
import type { DB } from './db.ts';
import { POLICY, newPortfolio } from '../trading/core.ts';
import { spotPrices } from '../trading/market.ts';
import reference from '../trading/evidence/report.json' with { type:'json' };
export interface AutotraderEnv { DB:DB; TRADING_SERVER_URL?:string; TRADING_SERVER_TOKEN?:string; TRADING_OWNER_EMAIL?:string }
const paths:Record<string,string>={'configure':'configure','backtest':'backtest','paper':'paper','verify':'verify','test-notifications':'test-notifications','activate':'activate','emergency':'emergency'};
const response=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function autotraderRoute(req:Request,env:AutotraderEnv,user:User|null) {
  const url=new URL(req.url),path=url.pathname;
  if(!path.startsWith('/api/autotrader'))return null;
  if(!user?.email)return response({error:'سجل الدخول بحسابك أولًا.'},401);
  try {
    if(path==='/api/autotrader/market'&&req.method==='GET')return response(await spotPrices());
    const saved=await env.DB.prepare('SELECT capital FROM empire_autotrader_preferences WHERE user_id=?').bind(user.id).first<{capital:string}>();
    const configured=!!(env.TRADING_SERVER_URL&&env.TRADING_SERVER_TOKEN&&env.TRADING_OWNER_EMAIL);
    const owner=env.TRADING_OWNER_EMAIL?.toLowerCase()===user.email.toLowerCase();
    if(path==='/api/autotrader/configure'&&req.method==='POST'&&!configured) {
      const body=await req.json() as {capital:unknown};
      if(typeof body.capital!=='number')throw new Error('اكتب سقف رأس المال بنفسك.');newPortfolio(body.capital,Date.now());
      await env.DB.prepare('INSERT INTO empire_autotrader_preferences(user_id,capital,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET capital=excluded.capital,updated_at=excluded.updated_at').bind(user.id,String(body.capital),new Date().toISOString()).run();
      return response({saved:true,connected:false,capital:body.capital,message:'حُفظ السقف الذي اخترته. يبدأ الاختبار الخاص بسقفك بعد تجهيز الخادم.'});
    }
    if(path==='/api/autotrader'&&req.method==='GET'&&(!configured||!owner)) {
      return response({policy:POLICY,phase:'setup',connected:false,capital:saved?Number(saved.capital):null,referenceBacktest:reference,backtest:null,paper:null,live:null,portfolio:null,verification:null,notificationsReady:false,canActivate:false,emergency:false,lastHeartbeat:0,price:0,job:null,error:null,notices:[],activationReasons:['خادم التداول المستمر وIP ثابت لم يُجهزا لهذا الحساب.','الاختبار المرجعي خاسر؛ يلزم اختبار مربح على سقف رأس مالك.','تجربة 60 يومًا خادمية لم تبدأ بعد.','مفتاح Spot المقيّد بـIP والإشعارات لم يُتحقق منهما.']});
    }
    if(!configured||!owner)return response({error:'خادم تداول مخصص لهذا الحساب لم يُوصل بعد. لا يمكن بدء التجربة أو تفعيل المال الحقيقي.'},503);
    const host=new URL(env.TRADING_SERVER_URL!);
    if(host.protocol!=='https:'||host.username||host.password||host.search||host.hash)throw new Error('إعداد عنوان خادم التداول غير صالح؛ يلزم HTTPS.');
    const action=path==='/api/autotrader'&&req.method==='GET'?'status':path.split('/').at(-1)!;
    if(action!=='status'&&(req.method!=='POST'||!paths[action]))return response({error:'أمر غير معروف'},404);
    const payload=action==='status'?undefined:await req.text();
    if(payload&&payload.length>8192)return response({error:'الطلب كبير جدًا'},413);
    const target=new URL(`/v1/${action}`,host);
    const upstream=await fetch(target,{method:action==='status'?'GET':'POST',headers:{Authorization:`Bearer ${env.TRADING_SERVER_TOKEN}`,...(action!=='status'?{'Content-Type':'application/json','X-Empire-Action-Origin':'user-click'}:{})},...(payload?{body:payload}:{}),signal:AbortSignal.timeout(15_000),redirect:'error'});
    const data=await upstream.json() as any;
    if(upstream.ok&&action==='configure'&&typeof data.capital==='number')await env.DB.prepare('INSERT INTO empire_autotrader_preferences(user_id,capital,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET capital=excluded.capital,updated_at=excluded.updated_at').bind(user.id,String(data.capital),new Date().toISOString()).run();
    return response({...data,referenceBacktest:reference},upstream.status);
  } catch(e){return response({error:e instanceof Error&&e.name==='TimeoutError'?'خادم التداول لا يستجيب؛ لا يبدأ التداول من المتصفح.':e instanceof Error?e.message:'تعذر الاتصال بخادم التداول'},400);}
}
