import type { DB } from './db.ts';
import { passwordHash, throttle, type User } from './auth.ts';

export interface BinanceEnv { DB: DB; BINANCE_CREDENTIAL_ENCRYPTION_KEY?: string }
type Credentials = { apiKey: string; apiSecret: string };
type Snapshot = { balances: { asset: string; free: string; locked: string }[]; checkedAt: string };
const encode = new TextEncoder();
const base64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const bytes = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const invalid = () => new Error('تعذر فحص الاتصال. تأكد من مفتاح HMAC وصلاحيات القراءة وعنوان IP المسموح، ثم أعد المحاولة.');
export class ConnectionError extends Error {
  code: string;
  httpStatus: number;
  constructor(code: string, message: string, httpStatus = 400) { super(message); this.code = code; this.httpStatus = httpStatus; }
}
export function exchangeError(status: number, code?: number): ConnectionError {
  if (status >= 300 && status < 400) return new ConnectionError('EXCHANGE_REDIRECT_BLOCKED', 'رفض الخادم إعادة توجيه طلب Binance لحماية المفاتيح. لم يتم إرسال المفاتيح إلى عنوان آخر.', 503);
  if (status === 451) return new ConnectionError('EXCHANGE_REGION_BLOCKED', 'Binance رفض الوصول من موقع خادم اللعبة (HTTP 451). المشكلة لا تُحل بتغيير مفتاحك أو VPN الهاتف؛ يلزم التحقق من توفر الخدمة وموقع الاستضافة.', 503);
  if (status === 403) return new ConnectionError('EXCHANGE_ACCESS_BLOCKED', 'Binance حجب طلب خادم اللعبة (HTTP 403). هذا لا يثبت وجود خطأ في المفتاح؛ يلزم فحص اتصال الخادم.', 503);
  if (status === 429 || status === 418) return new ConnectionError('EXCHANGE_RATE_LIMIT', 'Binance قيّد طلبات خادم اللعبة مؤقتًا. انتظر قبل المحاولة مجددًا.', 503);
  if (status >= 500) return new ConnectionError('EXCHANGE_UNAVAILABLE', 'خدمة Binance غير متاحة مؤقتًا من الخادم. أعد المحاولة لاحقًا.', 503);
  if (code === -1022) return new ConnectionError('INVALID_SIGNATURE', 'Binance رفض التوقيع (-1022). تحقق أن API Secret يخص نفس API Key وأن نوع المفتاح HMAC.');
  if (code === -2014) return new ConnectionError('INVALID_KEY_FORMAT', 'Binance رفض صيغة API Key (-2014). انسخ المفتاح كاملًا من إعدادات API.');
  if (code === -2015) return new ConnectionError('KEY_IP_OR_PERMISSIONS', 'Binance رفض المفتاح أو صلاحياته أو IP الخادم (-2015). تحقق من القراءة وصلاحية المفتاح؛ إذا كان مقيّدًا بـIP فهو يحتاج عنوان خادم ثابت، وليس IP هاتفك. لا تلغِ قيد IP لمجرد تجربة الربط.');
  if (code === -1021) return new ConnectionError('TIMESTAMP_REJECTED', 'Binance رفض توقيت الطلب (-1021). يلزم إعادة مزامنة ساعة الاتصال على الخادم.');
  return new ConnectionError('EXCHANGE_REQUEST_REJECTED', `Binance رفض طلب القراءة (HTTP ${status}${Number.isSafeInteger(code) ? '، رمز ' + code : ''}). لا يوجد اتصال محفوظ من هذه المحاولة.`);
}
async function exchangeGet(url: string, headers?: Record<string, string>): Promise<Record<string, any>> {
  let res: Response;
  try { res = await fetch(url, { method: 'GET', headers, redirect: 'manual', signal: AbortSignal.timeout(10000) }); }
  catch { throw new ConnectionError('EXCHANGE_NETWORK_ERROR', 'تعذر وصول خادم اللعبة إلى Binance أو انتهت مهلة الاتصال. جرّب فحص اتصال الخادم بدون مفتاح.', 503); }
  let data: Record<string, any>;
  try { data = await res.json() as Record<string, any>; }
  catch { throw res.ok ? new ConnectionError('EXCHANGE_INVALID_RESPONSE', 'استلم الخادم ردًا غير صالح من Binance.', 503) : exchangeError(res.status); }
  if (!res.ok) throw exchangeError(res.status, typeof data?.code === 'number' ? data.code : undefined);
  if (!data || typeof data !== 'object') throw new ConnectionError('EXCHANGE_INVALID_RESPONSE', 'استلم الخادم ردًا غير صالح من Binance.', 503);
  return data;
}
export async function exchangeClock() {
  const { serverTime } = await exchangeGet('https://api.binance.com/api/v3/time');
  if (!Number.isSafeInteger(serverTime)) throw new ConnectionError('EXCHANGE_INVALID_RESPONSE', 'لم يرجع Binance توقيتًا صالحًا.', 503);
  return { serverTime: serverTime as number, receivedAt: Date.now() };
}
async function vaultKey(key: string) {
  const raw = bytes(key);
  if (raw.length !== 32) throw new Error('إعداد حماية الاتصال غير متاح');
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
export async function seal(value: Credentials, user: string, key: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encode.encode(user) }, await vaultKey(key), encode.encode(JSON.stringify(value)));
  return JSON.stringify({ v: 1, iv: base64(iv), data: base64(new Uint8Array(encrypted)) });
}
export async function unseal(value: string, user: string, key: string): Promise<Credentials> {
  const p = JSON.parse(value);
  const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: bytes(p.iv), additionalData: encode.encode(user) }, await vaultKey(key), bytes(p.data));
  return JSON.parse(new TextDecoder().decode(decrypted));
}
async function signedGet(path: '/sapi/v1/account/apiRestrictions' | '/api/v3/account', credentials: Credentials, timestamp: number) {
  const query = new URLSearchParams({ timestamp: String(timestamp), recvWindow: '10000' });
  if (path === '/api/v3/account') query.set('omitZeroBalances', 'true');
  const key = await crypto.subtle.importKey('raw', encode.encode(credentials.apiSecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('HMAC', key, encode.encode(query.toString()));
  query.set('signature', Array.from(new Uint8Array(signature), b => b.toString(16).padStart(2, '0')).join(''));
  return exchangeGet(`https://api.binance.com${path}?${query}`, { 'X-MBX-APIKEY': credentials.apiKey });
}
export function assertReadOnly(p: Record<string, unknown>) {
  const prohibited = ['enableWithdrawals', 'enableInternalTransfer', 'permitsUniversalTransfer', 'enableSpotAndMarginTrading', 'enableMargin', 'enableFutures', 'enableVanillaOptions', 'enableFixApiTrade', 'enablePortfolioMarginTrading'];
  if (p.enableReading !== true || p.enableWithdrawals !== false || prohibited.some(k => p[k] === true))
    throw new Error('هذا الربط يقبل القراءة فقط. عطّل التداول والسحب والتحويل والهامش والعقود الآجلة من إعدادات المفتاح.');
}
export async function inspect(credentials: Credentials): Promise<Snapshot> {
  const { serverTime, receivedAt } = await exchangeClock();
  assertReadOnly(await signedGet('/sapi/v1/account/apiRestrictions', credentials, serverTime));
  const account = await signedGet('/api/v3/account', credentials, serverTime + Date.now() - receivedAt);
  if (!Array.isArray(account.balances)) throw invalid();
  return { balances: account.balances.filter((b: any) => Number(b.free) > 0 || Number(b.locked) > 0).map((b: any) => ({ asset: String(b.asset), free: String(b.free), locked: String(b.locked) })), checkedAt: new Date().toISOString() };
}
export async function binanceRoute(req: Request, env: BinanceEnv, user: User | null): Promise<Response | null> {
  const path = new URL(req.url).pathname;
  if (!['/api/binance/health', '/api/binance/status', '/api/binance/connect', '/api/binance/refresh', '/api/binance/disconnect'].includes(path)) return null;
  const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
  try {
    // Public clock only: no credentials, account data or external caller-controlled URL.
    if (path === '/api/binance/health') {
      if (req.method !== 'GET') return reply({ error: 'طريقة طلب غير مسموحة' }, 405);
      await throttle(env.DB, req);
      await exchangeClock();
      return reply({ reachable: true, checkedAt: new Date().toISOString(), message: 'اتصال خادم اللعبة بـBinance يعمل. هذا الفحص لا يتحقق من مفاتيح حسابك.' });
    }
    if (!user) return reply({ error: 'يرجى تسجيل الدخول' }, 401);
    if (path === '/api/binance/status' && req.method === 'GET') {
      if (!user.email) return reply({ registered: false, configured: !!env.BINANCE_CREDENTIAL_ENCRYPTION_KEY, connected: false, liveTrading: false });
      const row = await env.DB.prepare('SELECT snapshot FROM empire_binance_connections WHERE user_id=?').bind(user.id).first<{ snapshot: string }>();
      return reply({ registered: true, configured: !!env.BINANCE_CREDENTIAL_ENCRYPTION_KEY, connected: !!row, liveTrading: false, ...(row ? JSON.parse(row.snapshot) : {}) });
    }
    if (req.method !== 'POST') return reply({ error: 'طريقة طلب غير مسموحة' }, 405);
    if (!user.email || !user.password_hash || !user.salt) return reply({ error: 'سجّل حساب المؤسس أولًا لحفظ الاتصال باسم حسابك' }, 403);
    if (!env.BINANCE_CREDENTIAL_ENCRYPTION_KEY) return reply({ error: 'الخادم غير جاهز لحفظ مفاتيح الاتصال' }, 503);
    await throttle(env.DB, req);
    const raw = await req.text();
    if (raw.length > 4096) return reply({ error: 'الطلب كبير جدًا' }, 413);
    const body = JSON.parse(raw);
    const password = typeof body.password === 'string' ? body.password : '';
    if (password.length > 128 || await passwordHash(password, user.salt) !== user.password_hash) return reply({ error: 'كلمة مرور حساب اللعبة غير صحيحة' }, 401);
    const audit = (action: string) => env.DB.prepare('INSERT INTO empire_binance_audit(id,user_id,action,created_at) VALUES(?,?,?,?)').bind(crypto.randomUUID(), user.id, action, new Date().toISOString());
    if (path === '/api/binance/disconnect') {
      await env.DB.batch([env.DB.prepare('DELETE FROM empire_binance_connections WHERE user_id=?').bind(user.id), audit('disconnect')]);
      return reply({ connected: false, liveTrading: false });
    }
    let credentials: Credentials;
    if (path === '/api/binance/connect') {
      if (typeof body.apiKey !== 'string' || typeof body.apiSecret !== 'string' || !/^[A-Za-z0-9]{32,128}$/.test(body.apiKey) || !/^[A-Za-z0-9]{32,128}$/.test(body.apiSecret)) return reply({ error: 'أدخل مفتاح HMAC وSecret صحيحين؛ لا ترسلهما بالمحادثة' }, 400);
      credentials = { apiKey: body.apiKey, apiSecret: body.apiSecret };
    } else {
      const row = await env.DB.prepare('SELECT encrypted FROM empire_binance_connections WHERE user_id=?').bind(user.id).first<{ encrypted: string }>();
      if (!row) return reply({ error: 'لا يوجد اتصال محفوظ' }, 404);
      credentials = await unseal(row.encrypted, user.id, env.BINANCE_CREDENTIAL_ENCRYPTION_KEY);
    }
    const snapshot = await inspect(credentials);
    const encrypted = await seal(credentials, user.id, env.BINANCE_CREDENTIAL_ENCRYPTION_KEY);
    await env.DB.batch([env.DB.prepare('INSERT INTO empire_binance_connections(user_id,encrypted,snapshot) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET encrypted=excluded.encrypted,snapshot=excluded.snapshot').bind(user.id, encrypted, JSON.stringify(snapshot)), audit(path.endsWith('connect') ? 'connect-read-only' : 'refresh-read-only')]);
    return reply({ connected: true, liveTrading: false, ...snapshot });
  } catch (e) {
    if (e instanceof ConnectionError) return reply({ error: e.message, code: e.code, ...(path === '/api/binance/health' ? { reachable: false } : {}) }, e.httpStatus);
    const message = e instanceof Error ? e.message : '';
    const safe = message.startsWith('هذا الربط') || message.startsWith('محاولات كثيرة') ? message : invalid().message;
    return reply({ error: safe }, 400);
  }
}
