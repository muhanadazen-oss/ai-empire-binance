import { SCHEMA } from "./schema.ts";
import { binanceRoute } from './binance.ts';
import { walletRoute } from './wallet.ts';
import { researchRoute } from './research.ts';
import { autotraderRoute, type AutotraderEnv } from './autotrader.ts';
import type { DB } from "./db.ts";
import {
  sessionUser,
  makeSession,
  passwordHash,
  digest,
  throttle,
  type User,
} from "./auth.ts";
import { initialState } from "../src/engine/game.ts";
import { initialCivilization } from "../src/civilization/initial.ts";
import { applyCivicAction } from "../src/civilization/engine.ts";
import type { Civilization, CivAction } from "../src/civilization/types.ts";
import type { GameState } from "../src/engine/types.ts";
declare const STATIC_FILES: Record<string, { body: string; type: string }>;
interface Env extends AutotraderEnv {
  DB: DB;
  BINANCE_CREDENTIAL_ENCRYPTION_KEY?: string;
}
const schemas = new WeakMap<DB, Promise<void>>();
async function init(db: DB) {
  let promise = schemas.get(db);
  if (!promise) {
    promise = db
      .batch(SCHEMA.map((sql) => db.prepare(sql)))
      .then(() => {})
      .catch((e) => {
        schemas.delete(db);
        throw e;
      });
    schemas.set(db, promise);
  }
  await promise;
}
function validTrading(s: GameState) {
  return (
    s?.version === 1 &&
    Number.isFinite(s.cash) &&
    Number.isFinite(s.capital) &&
    s.cash >= 0 &&
    Array.isArray(s.agents) &&
    [6, 8].includes(s.agents.length) &&
    Array.isArray(s.open) &&
    Array.isArray(s.closed) &&
    Array.isArray(s.logs) &&
    !("apiSecret" in s)
  );
}
async function ensureCivil(db: DB, user: User) {
  const first = initialCivilization();
  await db.batch([
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_civilizations(user_id,data) VALUES(?,?)",
      )
      .bind(user.id, JSON.stringify(first)),
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_ledger(user_id,entry_id,game_day,source,destination,amount,reason) VALUES(?,?,?,?,?,?,?)",
      )
      .bind(
        user.id,
        "genesis",
        0,
        "initial-allocation",
        "all-accounts",
        first.totalMoney,
        first.ledger[0].reason,
      ),
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_civic_events(user_id,event_id,game_day,data) VALUES(?,?,?,?)",
      )
      .bind(user.id, first.events[0].id, 0, JSON.stringify(first.events[0])),
  ]);
}
async function responseState(db: DB, user: User) {
  const trading = await db
    .prepare("SELECT version,data FROM empire_states WHERE user_id=?")
    .bind(user.id)
    .first<{ version: number; data: string }>();
  const row = await db
    .prepare("SELECT revision,data FROM empire_civilizations WHERE user_id=?")
    .bind(user.id)
    .first<{ revision: number; data: string }>();
  const civic = JSON.parse(row!.data) as Civilization;
  civic.revision = row!.revision;
  return {
    user: { id: user.id, name: user.name, email: user.email },
    trading: JSON.parse(trading!.data),
    tradingVersion: trading!.version,
    civic,
  };
}
async function civicCommand(
  db: DB,
  user: User,
  action: CivAction,
  requestId: string,
  revision: number,
  now: number,
) {
  const hash = await digest(JSON.stringify(action));
  const seen = await db
    .prepare(
      "SELECT payload_hash FROM empire_requests WHERE user_id=? AND request_id=?",
    )
    .bind(user.id, requestId)
    .first<{ payload_hash: string }>();
  if (seen) {
    if (seen.payload_hash !== hash)
      throw new Error("مفتاح الطلب مستخدم لأمر آخر");
    return responseState(db, user);
  }
  const row = await db
    .prepare(
      "SELECT revision,data,last_tick FROM empire_civilizations WHERE user_id=?",
    )
    .bind(user.id)
    .first<{ revision: number; data: string; last_tick: number }>();
  if (row!.revision !== revision) throw new Error("CONFLICT");
  const old = JSON.parse(row!.data) as Civilization;
  if (
    action.type === "step" &&
    (now - row!.last_tick < 900 || !old.clock.running)
  )
    return responseState(db, user);
  const next = applyCivicAction(old, action),
    rev = revision + 1;
  next.revision = rev;
  const ledgerIds = new Set(old.ledger.map((t) => t.id)),
    eventIds = new Set(old.events.map((e) => e.id));
  const entries = next.ledger.filter((t) => !ledgerIds.has(t.id)),
    events = next.events.filter((e) => !eventIds.has(e.id));
  next.ledger = next.ledger.slice(-350);
  next.events = next.events.slice(-400);
  const statements = [
    db
      .prepare(
        "UPDATE empire_civilizations SET data=?,revision=revision+1,last_op=?,last_tick=? WHERE user_id=? AND revision=? AND NOT EXISTS (SELECT 1 FROM empire_requests WHERE user_id=? AND request_id=?)",
      )
      .bind(
        JSON.stringify(next),
        requestId,
        action.type === "step" ? now : row!.last_tick,
        user.id,
        revision,
        user.id,
        requestId,
      ),
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_requests(user_id,request_id,payload_hash,created_at) SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM empire_civilizations WHERE user_id=? AND last_op=? AND revision=?)",
      )
      .bind(user.id, requestId, hash, now, user.id, requestId, rev),
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_ledger(user_id,entry_id,game_day,source,destination,amount,reason) SELECT ?,json_extract(value,'$.id'),json_extract(value,'$.day'),json_extract(value,'$.from'),json_extract(value,'$.to'),json_extract(value,'$.amount'),json_extract(value,'$.reason') FROM json_each(?) WHERE EXISTS (SELECT 1 FROM empire_civilizations WHERE user_id=? AND last_op=? AND revision=?)",
      )
      .bind(user.id, JSON.stringify(entries), user.id, requestId, rev),
    db
      .prepare(
        "INSERT OR IGNORE INTO empire_civic_events(user_id,event_id,game_day,data) SELECT ?,json_extract(value,'$.id'),json_extract(value,'$.day'),value FROM json_each(?) WHERE EXISTS (SELECT 1 FROM empire_civilizations WHERE user_id=? AND last_op=? AND revision=?)",
      )
      .bind(user.id, JSON.stringify(events), user.id, requestId, rev),
  ];
  const results = await db.batch(statements);
  if (
    !results[0].meta.changes &&
    !(await db
      .prepare(
        "SELECT request_id FROM empire_requests WHERE user_id=? AND request_id=?",
      )
      .bind(user.id, requestId)
      .first())
  )
    throw new Error("CONFLICT");
  return responseState(db, user);
}
export default {
  async fetch(req: Request, env: Env) {
    const url = new URL(req.url);
    const headers = {
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "same-origin",
      "Content-Security-Policy":
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self' https://chatgpt.com; base-uri 'self'; form-action 'self'",
    };
    const json = (body: unknown, status = 200, cookie?: string) =>
      new Response(JSON.stringify(body), {
        status,
        headers: {
          ...headers,
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "no-store",
          ...(cookie ? { "Set-Cookie": cookie } : {}),
        },
      });
    if (!url.pathname.startsWith("/api/")) {
      const path = url.pathname === "/" ? "/index.html" : url.pathname;
      const file =
        STATIC_FILES[path] ??
        (!path.includes(".") ? STATIC_FILES["/index.html"] : undefined);
      return file
        ? new Response(file.body, {
            headers: {
              ...headers,
              "Content-Type": file.type,
              "Cache-Control":
                path === "/index.html" ? "no-cache" : "public,max-age=3600",
            },
          })
        : new Response("Not found", { status: 404 });
    }
    try {
      if (!env.DB)
        return json({ error: "قاعدة البيانات الخادمية غير متاحة" }, 503);
      const db = env.DB;
      await init(db);
      if (req.method !== "GET" && req.headers.get("origin") !== url.origin)
        return json({ error: "مصدر طلب غير مسموح" }, 403);
      if (
        req.method !== "GET" &&
        Number(req.headers.get("content-length") ?? 0) > 5000000
      )
        return json({ error: "الطلب كبير جدًا" }, 413);
      let user = await sessionUser(req, db),
        cookie: string | undefined;
      const path = url.pathname;
      if (path === "/api/session" && req.method === "GET" && !user) {
        user = { id: crypto.randomUUID(), name: "مهند صلاح", email: null };
        await db.batch([
          db
            .prepare(
              "INSERT INTO empire_users(id,name,created_at) VALUES(?,?,?)",
            )
            .bind(user.id, user.name, new Date().toISOString()),
          db
            .prepare("INSERT INTO empire_states(user_id,data) VALUES(?,?)")
            .bind(user.id, JSON.stringify(initialState())),
        ]);
        cookie = await makeSession(db, user.id, url.protocol === "https:");
      }
      if (path === "/api/auth/register" && req.method === "POST") {
        await throttle(db, req);
        const payload = (await req.json()) as {
          email: string;
          password: string;
          name: string;
        };
        const email = String(payload.email ?? "")
            .toLowerCase()
            .trim(),
          name = String(payload.name ?? "").trim(),
          password = String(payload.password ?? "");
        if (
          !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
          email.length > 254 ||
          name.length < 2 ||
          name.length > 40 ||
          password.length < 10 ||
          password.length > 128
        )
          return json(
            { error: "أدخل اسمًا وإيميلًا صحيحًا وكلمة مرور من 10–128 حرفًا" },
            400,
          );
        if (user?.email)
          return json({ error: "الحساب مرتبط ببريد بالفعل" }, 400);
        if (
          await db
            .prepare("SELECT id FROM empire_users WHERE email=?")
            .bind(email)
            .first()
        )
          return json({ error: "البريد مستخدم. جرّب تسجيل الدخول." }, 400);
        const id = user?.id ?? crypto.randomUUID(),
          salt = crypto.randomUUID(),
          hash = await passwordHash(password, salt);
        if (user)
          await db
            .prepare(
              "UPDATE empire_users SET email=?,name=?,password_hash=?,salt=? WHERE id=?",
            )
            .bind(email, name, hash, salt, id)
            .run();
        else
          await db.batch([
            db
              .prepare(
                "INSERT INTO empire_users(id,email,name,password_hash,salt,created_at) VALUES(?,?,?,?,?,?)",
              )
              .bind(id, email, name, hash, salt, new Date().toISOString()),
            db
              .prepare("INSERT INTO empire_states(user_id,data) VALUES(?,?)")
              .bind(id, JSON.stringify(initialState())),
          ]);
        user = { id, email, name };
        cookie = await makeSession(db, id, url.protocol === "https:");
      }
      if (path === "/api/auth/login" && req.method === "POST") {
        await throttle(db, req);
        const p = (await req.json()) as { email: string; password: string };
        const found = await db
          .prepare("SELECT * FROM empire_users WHERE email=?")
          .bind(
            String(p.email ?? "")
              .toLowerCase()
              .trim(),
          )
          .first<User>();
        const hash = await passwordHash(
          String(p.password ?? ""),
          found?.salt ?? "dummy",
        );
        if (!found || found.password_hash !== hash)
          return json({ error: "البريد أو كلمة المرور غير صحيحين" }, 401);
        user = found;
        cookie = await makeSession(db, user.id, url.protocol === "https:");
      }
      if (path === "/api/auth/logout" && req.method === "POST") {
        const token = req.headers
          .get("cookie")
          ?.match(/(?:^|;\s*)empire_session=([^;]+)/)?.[1];
        if (token)
          await db
            .prepare("DELETE FROM empire_sessions WHERE token_hash=?")
            .bind(await digest(token))
            .run();
        return json(
          { ok: true },
          200,
          `empire_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${url.protocol === "https:" ? "; Secure" : ""}`,
        );
      }
      const binance = await binanceRoute(req, env, user);
      if (binance) return binance;
      const wallet = await walletRoute(req, db, user);
      if (wallet) return wallet;
      const research = await researchRoute(req, db, user);
      if (research) return research;
      const autotrader = await autotraderRoute(req, env, user);
      if (autotrader) return autotrader;
      if (!user) return json({ error: "يرجى تسجيل الدخول" }, 401);
      await ensureCivil(db, user);
      if (path === "/api/migrate" && req.method === "POST") {
        const p = (await req.json()) as { trading: GameState };
        if (!validTrading(p.trading))
          return json({ error: "الحفظ القديم غير صالح" }, 400);
        await db
          .prepare(
            "UPDATE empire_states SET data=?,version=1 WHERE user_id=? AND version=0",
          )
          .bind(
            JSON.stringify({ ...p.trading, running: false, council: null }),
            user.id,
          )
          .run();
        return json(await responseState(db, user));
      }
      if (path === "/api/trading" && req.method === "POST") {
        const p = (await req.json()) as {
          trading: GameState;
          version: number;
          userId: string;
        };
        if (p.userId !== user.id)
          return json({ error: "تغير الحساب أثناء الحفظ" }, 409);
        if (!validTrading(p.trading))
          return json({ error: "حالة تداول تجريبي غير صالحة" }, 400);
        const result = await db
          .prepare(
            "UPDATE empire_states SET data=?,version=version+1 WHERE user_id=? AND version=?",
          )
          .bind(JSON.stringify(p.trading), user.id, p.version)
          .run();
        if (!result.meta.changes) return json({ error: "CONFLICT" }, 409);
        return json({ version: p.version + 1 });
      }
      if (path === "/api/civilization" && req.method === "POST") {
        const p = (await req.json()) as {
          action: CivAction;
          requestId: string;
          revision: number;
        };
        if (
          !p.action ||
          typeof p.requestId !== "string" ||
          p.requestId.length < 8 ||
          p.requestId.length > 100 ||
          !Number.isSafeInteger(p.revision)
        )
          return json({ error: "طلب غير صالح" }, 400);
        return json(
          await civicCommand(
            db,
            user,
            p.action,
            p.requestId,
            p.revision,
            Date.now(),
          ),
        );
      }
      if (path === "/api/civilization/export" && req.method === "GET") {
        const events = await db
          .prepare(
            "SELECT data FROM empire_civic_events WHERE user_id=? ORDER BY game_day,event_id",
          )
          .bind(user.id)
          .all<{ data: string }>();
        const ledger = await db
          .prepare(
            "SELECT entry_id,game_day,source,destination,amount,reason FROM empire_ledger WHERE user_id=? ORDER BY game_day,entry_id",
          )
          .bind(user.id)
          .all();
        return json({
          mode: "simulation",
          ...(await responseState(db, user)),
          events: events.results.map((e) => JSON.parse(e.data)),
          ledger: ledger.results,
        });
      }
      if (path === "/api/trading/reset" && req.method === "POST") {
        await db
          .prepare(
            "UPDATE empire_states SET data=?,version=version+1 WHERE user_id=?",
          )
          .bind(JSON.stringify(initialState()), user.id)
          .run();
        return json(await responseState(db, user));
      }
      if (path === "/api/session" || path.startsWith("/api/auth/"))
        return json(await responseState(db, user), 200, cookie);
      return json(
        { error: "عملية غير متاحة؛ التداول الحقيقي والسحب مقفولان" },
        404,
      );
    } catch (e) {
      const message = e instanceof Error ? e.message : "تعذر تنفيذ الطلب";
      return json({ error: message }, message === "CONFLICT" ? 409 : 400);
    }
  },
};
