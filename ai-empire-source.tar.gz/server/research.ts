import type {DB} from './db.ts';
import type {User} from './auth.ts';
export type Idea={title:string;url:string;publishedAt:string;asset:'BTC'|'ETH'|'SOL';bias:'up'|'down'|'neutral'};
export type Evidence={price:number;sma20:number;sma50:number;rsi:number;atr:number;volumeRatio:number;closedAt:string};
export type Candidate=Idea & {researcher:string[];trader:string[];decision:'watch'|'rejected'|'reviewed';evidence?:Evidence;plan?:{entry:number;stop:number;target:number;rewardRisk:number};};
export type Report={scannedAt:string;sources:string[];candidates:Candidate[];errors:string[];execution:'manual-only';};
const FEED='https://www.coindesk.com/arc/outboundfeeds/rss';
function plain(s:string){return s.replace(/^<!\[CDATA\[|\]\]>$/g,'').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim();}
export function parseIdeas(xml:string,now=Date.now()):Idea[]{
 const ideas:Idea[]=[];const links=new Set<string>();
 for(const match of xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)){
  const item=match[1];const tag=(name:string)=>plain(item.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`,'i'))?.[1]??'');
  const title=tag('title').slice(0,180),url=tag('link'),date=Date.parse(tag('pubDate'));
  let u;try{u=new URL(url);}catch{continue;}
  if(u.protocol!=='https:'||u.hostname!=='www.coindesk.com'||u.username||u.password||!Number.isFinite(date)||date>now+300000||now-date>48*3600000||links.has(url))continue;
  const assets=[['BTC',/\bbitcoin\b|\bBTC\b/i],['ETH',/\bethereum\b|\bether\b|\bETH\b/i],['SOL',/\bsolana\b|\bSOL\b/i]] as const;
  const asset=assets.find(([,r])=>r.test(title))?.[0];if(!asset)continue;
  const up=/\bbullish\b|\bbreakout\b|\brall(?:y|ies)\b|\bbuy\b/i.test(title),down=/\bbearish\b|\bcrash\b|\bsell\b|\bslump\b/i.test(title);
  ideas.push({title,url,publishedAt:new Date(date).toISOString(),asset,bias:up&&!down?'up':down&&!up?'down':'neutral'});links.add(url);if(ideas.length===8)break;
 }
 return ideas;
}
export function analyseCandles(input:unknown,now=Date.now()):Evidence{
 if(!Array.isArray(input))throw new Error('بيانات السوق ليست شموعًا صالحة.');
 const rows=input.filter(r=>Array.isArray(r)&&Number(r[6])<now).slice(-100);
 if(rows.length<60)throw new Error('شموع مغلقة غير كافية لدراسة السوق.');
 for(let i=0;i<rows.length;i++){
  const r=rows[i],v=[1,2,3,4,5].map(k=>Number(r[k]));
  if(!Number.isSafeInteger(r[0])||!Number.isSafeInteger(r[6])||r[6]-r[0]!==3599999||v.some(n=>!Number.isFinite(n))||v.slice(0,4).some(n=>n<=0)||v[4]<0||v[1]<Math.max(v[0],v[3])||v[2]>Math.min(v[0],v[3])||v[2]>v[1]||(i>0&&r[0]-rows[i-1][0]!==3600000))throw new Error('بيانات السوق ناقصة أو غير متسقة.');
 }
 const last=rows.at(-1)!;if(now-last[6]>90*60000||last[6]>now)throw new Error('بيانات السوق قديمة. لا تُعتمد توصية أو صفقة.');
 const closes=rows.map(r=>Number(r[4])),mean=(a:number[])=>a.reduce((s,n)=>s+n,0)/a.length;
 let gain=0,loss=0;for(let i=1;i<=14;i++){const d=closes[i]-closes[i-1];gain+=Math.max(d,0)/14;loss+=Math.max(-d,0)/14;}
 for(let i=15;i<closes.length;i++){const d=closes[i]-closes[i-1];gain=(gain*13+Math.max(d,0))/14;loss=(loss*13+Math.max(-d,0))/14;}
 const rsi=gain===0&&loss===0?50:loss===0?100:100-100/(1+gain/loss);
 const tr=rows.slice(-14).map((r,j)=>{const prev=Number(rows[rows.length-15+j][4]);return Math.max(Number(r[2])-Number(r[3]),Math.abs(Number(r[2])-prev),Math.abs(Number(r[3])-prev));});
 const volumes=rows.slice(-21,-1).map(r=>Number(r[5])),avgVolume=mean(volumes);
 if(avgVolume<=0)throw new Error('لا توجد سيولة قابلة للتحقق.');
 return {price:closes.at(-1)!,sma20:mean(closes.slice(-20)),sma50:mean(closes.slice(-50)),rsi,atr:mean(tr),volumeRatio:Number(last[5])/avgVolume,closedAt:new Date(last[6]).toISOString()};
}
export function reviewIdea(idea:Idea,evidence?:Evidence,error?:string):Candidate{
 const c:Candidate={...idea,researcher:['رؤى: تحققت من رابط المصدر ووقت النشر وتحديد العملة.','العنوان يعطي سياقًا أوليًا؛ لا يعني أن الكاتب أوصى بصفقة. لم يتم الادعاء بقراءة المقال كاملًا.'],trader:[],decision:'watch'};
 if(!evidence){c.trader=[`رائد: أوقف الدراسة — ${error??'السوق غير متاح.'}`];c.decision='rejected';return c;}
 c.evidence=evidence;
 if(idea.bias==='neutral'){c.trader=['رائد: الخبر لا يحدد اتجاهًا واضحًا؛ مراقبة فقط.'];return c;}
 if(idea.bias==='down'){c.trader=['رائد: الفكرة هبوطية. هذه الخطة تفحص شراء Spot فقط؛ لا فتح بيع مكشوف أو اقتراض.'];c.decision='rejected';return c;}
 const tests:[boolean,string][]=[[evidence.price>evidence.sma20&&evidence.sma20>evidence.sma50,'السعر أعلى من متوسط 20 ساعة، ومتوسط 20 أعلى من 50'],[evidence.rsi>=45&&evidence.rsi<=65,'RSI بين 45 و65؛ تجنّب التشبع'],[evidence.volumeRatio>=1.1,'حجم آخر ساعة أعلى من متوسط 20 ساعة بنسبة 10% على الأقل'],[evidence.atr>0&&evidence.atr/evidence.price<=0.035,'تقلب ATR إيجابي وأقل من 3.5%']];
 c.trader=tests.map(([ok,text])=>`رائد: ${ok?'اجتاز':'رفض'} — ${text}.`);
 if(tests.some(([ok])=>!ok)){c.decision='rejected';return c;}
 c.plan={entry:evidence.price,stop:evidence.price-evidence.atr*1.5,target:evidence.price+evidence.atr*3,rewardRisk:2};
 c.trader.push('سلمى: خطة مرجعية بعائد/مخاطرة 2:1. حجم الصفقة غير محسوب دون معرفة الرصيد والمخاطرة المسموحة.','التنفيذ الحقيقي موقوف: المحفظة غير مرتبطة بمنصة مبادلات؛ لا تخصم المحفظة ولا تُفتح صفقة تلقائية.');c.decision='reviewed';return c;
}
async function fetchBounded(url:string,max:number){
 const res=await fetch(url,{headers:{Accept:'application/json, application/rss+xml, text/xml','Cache-Control':'no-cache'},redirect:'manual',signal:AbortSignal.timeout(12000)});
 if(!res.ok||!res.body)throw new Error('المصدر غير متاح من خادم اللعبة.');
 const reader=res.body.getReader();let size=0;const chunks:Uint8Array[]=[];
 while(true){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>max){await reader.cancel();throw new Error('رد المصدر أكبر من الحد المسموح.');}chunks.push(r.value);}
 const raw=new Uint8Array(size);let offset=0;for(const chunk of chunks){raw.set(chunk,offset);offset+=chunk.length;}return new TextDecoder().decode(raw);
}
export async function researchRoute(req:Request,db:DB,user:User|null):Promise<Response|null>{
 const path=new URL(req.url).pathname;if(path!=='/api/research')return null;
 const reply=(p:unknown,status=200)=>new Response(JSON.stringify(p),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(!user)return reply({error:'سجّل الدخول أولًا.'},401);
 const saved=await db.prepare('SELECT report,scanned_at FROM empire_research WHERE user_id=?').bind(user.id).first<{report:string;scanned_at:string}>();
 if(req.method==='GET')return reply({report:saved?JSON.parse(saved.report):null});
 if(req.method!=='POST')return reply({error:'طلب غير متاح.'},405);
 if(saved&&Date.now()-Date.parse(saved.scanned_at)<300000)return reply({report:JSON.parse(saved.report),cached:true});
 const bucket=`research:${user.id}:${Math.floor(Date.now()/300000)}`;
 await db.prepare('INSERT INTO empire_auth_attempts(bucket,count,expires) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1').bind(bucket,Date.now()+600000).run();
 const rate=await db.prepare('SELECT count FROM empire_auth_attempts WHERE bucket=?').bind(bucket).first<{count:number}>();
 if((rate?.count??0)>1)return reply({error:'هناك فحص جارٍ أو حديث. انتظر خمس دقائق قبل المحاولة.'},429);
 const report:Report={scannedAt:new Date().toISOString(),sources:[FEED,'https://data-api.binance.vision'],candidates:[],errors:[],execution:'manual-only'};
 let ideas:Idea[]=[];try{ideas=parseIdeas(await fetchBounded(FEED,250000));if(!ideas.length)report.errors.push('لا توجد أفكار حديثة للعملات المدعومة في المصدر.');}catch{report.errors.push('تعذر جلب مصدر الأخبار؛ لم تُختلق توصيات بديلة.');}
 const market=new Map<string,{evidence?:Evidence;error?:string}>();
 await Promise.all([...new Set(ideas.map(i=>i.asset))].map(async asset=>{try{const endTime=Math.floor(Date.now()/300000)*300000;const data=JSON.parse(await fetchBounded(`https://data-api.binance.vision/api/v3/klines?symbol=${asset}USDT&interval=1h&limit=120&endTime=${endTime}`,100000));market.set(asset,{evidence:analyseCandles(data)});}catch(e){market.set(asset,{error:e instanceof Error?e.message:'تعذر فحص السوق.'});}}));
 report.candidates=ideas.map(i=>reviewIdea(i,market.get(i.asset)?.evidence,market.get(i.asset)?.error));
 await db.prepare('INSERT INTO empire_research(user_id,report,scanned_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET report=excluded.report,scanned_at=excluded.scanned_at').bind(user.id,JSON.stringify(report),report.scannedAt).run();
 return reply({report,cached:false});
}
