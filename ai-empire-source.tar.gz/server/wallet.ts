import { encodeFunctionData, decodeEventLog, decodeFunctionData, erc20Abi, keccak256, parseTransaction, recoverTransactionAddress, zeroAddress, type Hex, type TransactionSerialized } from 'viem';
import type { DB } from './db.ts';
import type { User } from './auth.ts';
import { validVault } from '../src/integration/wallet-vault.ts';
import {checkWithdrawal,MIN_DEPOSIT} from '../src/integration/wallet-limits.ts';
import { TOKEN } from '../src/integration/wallet-chain.ts';
type DepositRow = {id:string;hash:Hex;sender:string;amount:string;created_at:string};
type WalletRow = {address: string; vault: string};
type TransferRow = {hash: Hex; user_id: string; recipient: string; amount: string; raw: Hex; status: string; created_at: string};
export async function chainRpc(method: string, params: unknown[]) {
  let res: Response;
  try { res = await fetch('https://bsc-dataseed.bnbchain.org', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}), redirect:'manual', signal:AbortSignal.timeout(12000) }); }
  catch { throw new Error('تعذر الوصول للشبكة. حالة الإرسال تبقى غير محسومة حتى فحصها.'); }
  if (!res.ok) throw new Error('خدمة الشبكة غير متاحة مؤقتًا.');
  const body = await res.text();
  if (body.length > 150000) throw new Error('رد الشبكة غير صالح.');
  let p; try { p = JSON.parse(body); } catch { throw new Error('رد الشبكة غير صالح.'); }
  if (p.error || !('result' in p)) throw new Error('الشبكة رفضت الطلب. افحص الرصيد والرسوم وحالة المعاملة.');
  return p.result;
}
export async function validateRaw(raw: Hex, address: string) {
  if (typeof raw !== 'string' || !/^0x[\da-f]+$/i.test(raw) || raw.length > 3000) throw new Error('معاملة غير صالحة.');
  const t = parseTransaction(raw);
  if (t.chainId !== 56 || t.to?.toLowerCase() !== TOKEN.toLowerCase() || (t.value ?? 0n) !== 0n || !t.data || !t.gas || t.gas > 300000n || !t.gasPrice || t.gasPrice > 100000000000n) throw new Error('الإرسال مسموح لعملة USDT على شبكة BEP20 فقط.');
  if ((await recoverTransactionAddress({serializedTransaction:raw as TransactionSerialized})).toLowerCase() !== address.toLowerCase()) throw new Error('التوقيع لا يخص محفظتك.');
  const d = decodeFunctionData({abi:erc20Abi,data:t.data});
  if (d.functionName !== 'transfer') throw new Error('عملية غير مسموحة.');
  const [recipient, amount] = d.args;
  checkWithdrawal(amount);
  if (amount <= 0n || [zeroAddress,TOKEN,address].some(a=>a.toLowerCase()===recipient.toLowerCase())) throw new Error('عنوان أو مبلغ غير صالح.');
  return { hash:keccak256(raw), recipient, amount:amount.toString() };
}
export async function walletRoute(req: Request, db: DB, user: User | null): Promise<Response | null> {
  const path = new URL(req.url).pathname;
  if (!path.startsWith('/api/wallet/')) return null;
  const reply = (data: unknown, status=200) => new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
  if (!user?.email) return reply({error:'سجّل الدخول بحساب اللعبة أولًا حتى تحفظ محفظتك.'},401);
  try {
    const bucket=`wallet:${user.id}:${Math.floor(Date.now()/60000)}`;
    await db.prepare('INSERT INTO empire_auth_attempts(bucket,count,expires) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1').bind(bucket,Date.now()+120000).run();
    const rate=await db.prepare('SELECT count FROM empire_auth_attempts WHERE bucket=?').bind(bucket).first<{count:number}>();
    if((rate?.count??0)>120) return reply({error:'طلبات كثيرة. انتظر دقيقة قبل المحاولة.'},429);
    await db.prepare('DELETE FROM empire_auth_attempts WHERE expires<?').bind(Date.now()).run();
    const wallet = await db.prepare('SELECT address,vault FROM empire_wallets WHERE user_id=?').bind(user.id).first<WalletRow>();
    if (path === '/api/wallet/vault' && req.method === 'GET') return reply({vault:wallet ? JSON.parse(wallet.vault) : null});
    let p: any = null;
    if (req.method === 'POST') { const body=await req.text(); if(body.length>6000) throw new Error('الطلب كبير جدًا.'); p=JSON.parse(body); }
    if (path === '/api/wallet/vault' && req.method === 'POST') {
      if (!validVault(p.vault) || p.vault.owner !== user.id) throw new Error('نسخة المحفظة لا تخص هذا الحساب.');
      if(wallet) { if(wallet.vault!==JSON.stringify(p.vault)) return reply({error:'لديك محفظة محفوظة بالفعل. لن نستبدل عنوانها.'},409); return reply({vault:p.vault}); }
      await db.prepare('INSERT OR IGNORE INTO empire_wallets(user_id,address,vault,created_at) VALUES(?,?,?,?)').bind(user.id,p.vault.address,JSON.stringify(p.vault),new Date().toISOString()).run();
      const saved=await db.prepare('SELECT vault FROM empire_wallets WHERE user_id=?').bind(user.id).first<{vault:string}>();
      return reply({vault:JSON.parse(saved!.vault)});
    }
    if(!wallet && path==='/api/wallet/summary' && req.method==='GET')return reply({summary:null});
    if(!wallet) throw new Error('أنشئ المحفظة أولًا.');
    if(path==='/api/wallet/rpc' && req.method==='POST') {
      const methods=['eth_chainId','eth_getBalance','eth_call','eth_estimateGas','eth_gasPrice','eth_getTransactionCount','eth_blockNumber'];
      if(!methods.includes(p.method) || !Array.isArray(p.params) || p.params.length>2) throw new Error('طلب شبكة غير مسموح.');
      if(['eth_getBalance','eth_getTransactionCount'].includes(p.method) && p.params[0]?.toLowerCase()!==wallet.address.toLowerCase()) throw new Error('طلب حساب آخر غير مسموح.');
      if(['eth_call','eth_estimateGas'].includes(p.method)) {
        const c=p.params[0];
        if(c?.to?.toLowerCase()!==TOKEN.toLowerCase() || (c.from && c.from.toLowerCase()!==wallet.address.toLowerCase()) || (c.value && BigInt(c.value)!==0n)) throw new Error('عقد غير مسموح.');
        const d=decodeFunctionData({abi:erc20Abi,data:c.data});
        if(!['balanceOf','decimals','transfer'].includes(d.functionName)) throw new Error('عملية غير مسموحة.');
        if(d.functionName==='balanceOf' && d.args[0].toLowerCase()!==wallet.address.toLowerCase()) throw new Error('طلب حساب آخر غير مسموح.');
      }
      return reply({jsonrpc:'2.0',id:p.id ?? 1,result:await chainRpc(p.method,p.params)});
    }
    const rows=()=>db.prepare('SELECT * FROM empire_wallet_transfers WHERE user_id=? ORDER BY created_at DESC LIMIT 20').bind(user.id).all<TransferRow>();
    const visible=(r:TransferRow)=>({hash:r.hash,recipient:r.recipient,amount:r.amount,status:r.status,createdAt:r.created_at});
    if(path==='/api/wallet/transfers' && req.method==='GET') return reply({transfers:(await rows()).results.map(visible)});
    if(path==='/api/wallet/summary' && req.method==='GET') {
      const data=encodeFunctionData({abi:erc20Abi,functionName:'balanceOf',args:[wallet.address as Hex]});
      const [usdt,bnb,incoming,outgoing]=await Promise.all([chainRpc('eth_call',[{to:TOKEN,data},'latest']),chainRpc('eth_getBalance',[wallet.address,'latest']),db.prepare('SELECT amount FROM empire_wallet_deposits WHERE user_id=?').bind(user.id).all<{amount:string}>(),db.prepare('SELECT amount,status FROM empire_wallet_transfers WHERE user_id=?').bind(user.id).all<{amount:string;status:string}>()]);
      const sum=(rows:{amount:string}[])=>rows.reduce((n,r)=>n+BigInt(r.amount),0n).toString();
      return reply({summary:{address:wallet.address,usdt:BigInt(usdt).toString(),bnb:BigInt(bnb).toString(),deposited:sum(incoming.results),withdrawn:sum(outgoing.results.filter(r=>r.status==='confirmed')),pending:sum(outgoing.results.filter(r=>r.status==='pending')),checkedAt:new Date().toISOString()}});
    }
    if(path==='/api/wallet/deposit' && req.method==='POST') {
      if(typeof p.hash!=='string' || !/^0x[\da-f]{64}$/i.test(p.hash)) throw new Error('انسخ TxID كاملًا من سجل السحب في Binance.');
      const hash=p.hash.toLowerCase();
      const receipt=await chainRpc('eth_getTransactionReceipt',[hash]);
      if(!receipt || receipt.transactionHash?.toLowerCase()!==hash || receipt.status!=='0x1' || !receipt.blockNumber) throw new Error('الإيداع لم يتأكد على شبكة BEP20 بعد، أو أن المعاملة مرفوضة.');
      const head=BigInt(await chainRpc('eth_blockNumber',[]));
      if(head-BigInt(receipt.blockNumber)+1n<3n) throw new Error('انتظر ثلاثة تأكيدات للشبكة ثم أعد الفحص.');
      const block=await chainRpc('eth_getBlockByNumber',[receipt.blockNumber,false]);
      const timestamp=Number(BigInt(block.timestamp))*1000;
      if(!Number.isSafeInteger(timestamp)) throw new Error('تاريخ المعاملة غير صالح.');
      let matched=false,total=0n;
      for(const log of receipt.logs??[]) {
        if(log.address?.toLowerCase()!==TOKEN.toLowerCase() || log.removed || !/^0x[\da-f]+$/i.test(log.logIndex??'')) continue;
        let event;
        try { event=decodeEventLog({abi:erc20Abi,data:log.data,topics:log.topics,strict:true}); } catch { continue; }
        {
          if(event.eventName!=='Transfer' || event.args.to.toLowerCase()!==wallet.address.toLowerCase() || event.args.value<=0n) continue;
          matched=true;total+=event.args.value;
          await db.prepare('INSERT OR IGNORE INTO empire_wallet_deposits(id,user_id,hash,sender,amount,created_at) VALUES(?,?,?,?,?,?)').bind(hash+':'+BigInt(log.logIndex).toString(),user.id,hash,event.args.from,event.args.value.toString(),new Date(timestamp).toISOString()).run();
        }
      }
      if(!matched) throw new Error('المعاملة لا تحتوي إيداع USDT إلى عنوان محفظتك على BEP20.');
      return reply({verified:true,meetsMinimum:total>=MIN_DEPOSIT,amount:total.toString()});
    }
    if(path==='/api/wallet/accounting' && req.method==='GET') {
      const incoming=(await db.prepare('SELECT * FROM empire_wallet_deposits WHERE user_id=? ORDER BY created_at DESC').bind(user.id).all<DepositRow>()).results;
      const outgoing=(await db.prepare('SELECT * FROM empire_wallet_transfers WHERE user_id=? ORDER BY created_at DESC').bind(user.id).all<TransferRow>()).results;
      const sum=(rows:{amount:string}[])=>rows.reduce((n,r)=>n+BigInt(r.amount),0n).toString();
      return reply({deposited:sum(incoming),withdrawn:sum(outgoing.filter(r=>r.status==='confirmed')),pending:sum(outgoing.filter(r=>r.status==='pending')),deposits:incoming.slice(0,100).map(r=>({id:r.id,hash:r.hash,sender:r.sender,amount:r.amount,createdAt:r.created_at})),transfers:outgoing.slice(0,100).map(visible)});
    }
    if(path==='/api/wallet/send' && req.method==='POST') {
      const t=await validateRaw(p.raw,wallet.address);
      await db.prepare("INSERT OR IGNORE INTO empire_wallet_transfers(hash,user_id,recipient,amount,raw,status,created_at) SELECT ?,?,?,?,?, 'pending',? WHERE NOT EXISTS(SELECT 1 FROM empire_wallet_transfers WHERE user_id=? AND status='pending')").bind(t.hash,user.id,t.recipient,t.amount,p.raw,new Date().toISOString(),user.id).run();
      const saved=await db.prepare('SELECT * FROM empire_wallet_transfers WHERE hash=? AND user_id=?').bind(t.hash,user.id).first<TransferRow>();
      if(!saved) throw new Error('هناك إرسال سابق غير محسوم. افحصه قبل إرسال مبلغ جديد.');
      let broadcast=false;
      if(saved.status==='pending') { try { broadcast=(await chainRpc('eth_sendRawTransaction',[saved.raw]))===saved.hash; } catch { /* Persisted before broadcast; uncertainty is never reported as failure. */ } }
      return reply({transfer:visible(saved),broadcast});
    }
    if(['/api/wallet/receipt','/api/wallet/retry'].includes(path) && req.method==='POST') {
      if(!/^0x[\da-f]{64}$/i.test(p.hash)) throw new Error('معرّف غير صالح.');
      const row=await db.prepare('SELECT * FROM empire_wallet_transfers WHERE hash=? AND user_id=?').bind(p.hash,user.id).first<TransferRow>();
      if(!row) throw new Error('المعاملة غير موجودة.');
      if(path.endsWith('/retry') && row.status==='pending') { try { await chainRpc('eth_sendRawTransaction',[row.raw]); } catch {} }
      const receipt=await chainRpc('eth_getTransactionReceipt',[row.hash]);
      if(receipt?.blockNumber && receipt.transactionHash?.toLowerCase()===row.hash.toLowerCase()) {
        const block=BigInt(await chainRpc('eth_blockNumber',[]));
        if(block-BigInt(receipt.blockNumber)+1n>=3n) {
          row.status=receipt.status==='0x1' ? 'confirmed' : 'reverted';
          await db.prepare('UPDATE empire_wallet_transfers SET status=? WHERE hash=? AND user_id=?').bind(row.status,row.hash,user.id).run();
        }
      }
      return reply({transfer:visible(row)});
    }
    return reply({error:'عملية غير متاحة.'},404);
  } catch(e) { return reply({error:e instanceof Error && !/JSON|hex|ABI|signature|Invalid|Cannot/i.test(e.message) ? e.message : 'طلب المحفظة غير صالح.'},400); }
}
