/** Future server-only contract. This file is not imported by the browser bundle.
 * No exchange API client or real trading endpoint is implemented in phase one.
 */
export type ExecutionMode = "simulation" | "real";
export interface ServerOrderRequest {
  proposalId: string;
  symbol: "BTCUSDT" | "ETHUSDT" | "SOLUSDT";
  side: "BUY" | "SELL";
  quoteAmount: string;
  idempotencyKey: string;
}
export interface ExchangePermissions {
  read: true;
  spotTrade: boolean;
  withdrawal: false;
}
export interface ServerSecretStore {
  getForOwner(ownerId: string): Promise<{ apiKey: string; apiSecret: string }>;
}
export interface ServerRiskGate {
  // Must recalculate against server wallet and exchange balances. Never trust browser state.
  authorize(
    ownerId: string,
    request: ServerOrderRequest,
  ): Promise<{ allowed: boolean; reason: string }>;
}
export interface AuditRepository {
  append(event: {
    ownerId: string;
    proposalId: string;
    action: string;
    at: string;
    reason: string;
  }): Promise<void>;
}
export class DisabledRealBroker {
  readonly permissions: ExchangePermissions = {
    read: true,
    spotTrade: false,
    withdrawal: false,
  };
  execute(_ownerId: string, _request: ServerOrderRequest): never {
    throw new Error("REAL_EXECUTION_DISABLED: Simulation phase only");
  }
  // No withdrawal operation exists in this interface or implementation.
}
