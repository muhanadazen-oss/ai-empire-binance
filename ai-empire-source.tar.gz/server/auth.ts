import type { DB } from "./db.ts";
const enc = new TextEncoder();
export const hex = (v: ArrayBuffer | Uint8Array) =>
  Array.from(new Uint8Array(v), (b) => b.toString(16).padStart(2, "0")).join(
    "",
  );
export const digest = async (s: string) =>
  hex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
export async function passwordHash(password: string, salt: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  return hex(
    await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: enc.encode(salt),
        iterations: 100000,
        hash: "SHA-256",
      },
      key,
      256,
    ),
  );
}
export interface User {
  id: string;
  name: string;
  email: string | null;
  password_hash?: string;
  salt?: string;
}
export async function sessionUser(req: Request, db: DB) {
  const token = req.headers
    .get("cookie")
    ?.match(/(?:^|;\s*)empire_session=([^;]+)/)?.[1];
  return token
    ? db
        .prepare(
          "SELECT u.* FROM empire_users u JOIN empire_sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires>?",
        )
        .bind(await digest(token), Date.now())
        .first<User>()
    : null;
}
export async function makeSession(db: DB, id: string, secure: boolean) {
  const token = hex(crypto.getRandomValues(new Uint8Array(32)));
  await db
    .prepare(
      "INSERT INTO empire_sessions(token_hash,user_id,expires) VALUES(?,?,?)",
    )
    .bind(await digest(token), id, Date.now() + 30 * 86400000)
    .run();
  return `empire_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${secure ? "; Secure" : ""}`;
}
export async function throttle(db: DB, req: Request) {
  const bucket = await digest(
    (req.headers.get("cf-connecting-ip") ?? "local") +
      Math.floor(Date.now() / 600000),
  );
  await db
    .prepare(
      "INSERT INTO empire_auth_attempts(bucket,count,expires) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1",
    )
    .bind(bucket, Date.now() + 600000)
    .run();
  const row = await db
    .prepare("SELECT count FROM empire_auth_attempts WHERE bucket=?")
    .bind(bucket)
    .first<{ count: number }>();
  if (row!.count > 20)
    throw new Error("محاولات كثيرة. أعد المحاولة بعد عشر دقائق");
}
