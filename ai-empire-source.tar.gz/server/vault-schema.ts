import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
// Existing kingdom tables stay intact; only new vault tables are migrated.
export const connections = sqliteTable('empire_binance_connections', {
  userId: text('user_id').primaryKey(),
  encrypted: text('encrypted').notNull(),
  snapshot: text('snapshot').notNull(),
});
export const audit = sqliteTable('empire_binance_audit', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  action: text('action').notNull(),
  createdAt: text('created_at').notNull(),
});
export const wallets = sqliteTable('empire_wallets', {
  userId: text('user_id').primaryKey(), address: text('address').notNull(),
  vault: text('vault').notNull(), createdAt: text('created_at').notNull(),
});
export const transfers = sqliteTable('empire_wallet_transfers', {
  hash: text('hash').primaryKey(), userId: text('user_id').notNull(),
  recipient: text('recipient').notNull(), amount: text('amount').notNull(),
  raw: text('raw').notNull(), status: text('status').notNull(), createdAt: text('created_at').notNull(),
});
export const research = sqliteTable('empire_research', {
  userId: text('user_id').primaryKey(), report: text('report').notNull(), scannedAt: text('scanned_at').notNull(),
});

export const deposits = sqliteTable('empire_wallet_deposits', {
 id: text('id').primaryKey(), userId: text('user_id').notNull(), hash: text('hash').notNull(), sender: text('sender').notNull(), amount: text('amount').notNull(), createdAt: text('created_at').notNull(),
});
export const autotraderPreferences = sqliteTable('empire_autotrader_preferences', {
 userId:text('user_id').primaryKey(),capital:text('capital').notNull(),updatedAt:text('updated_at').notNull(),
});
