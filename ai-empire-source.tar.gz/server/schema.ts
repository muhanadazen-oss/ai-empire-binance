export const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS empire_users (id TEXT PRIMARY KEY,email TEXT UNIQUE,name TEXT NOT NULL,password_hash TEXT,salt TEXT,created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS empire_sessions (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES empire_users(id),expires INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS empire_states (user_id TEXT PRIMARY KEY REFERENCES empire_users(id),version INTEGER NOT NULL DEFAULT 0,data TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS empire_auth_attempts (bucket TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS empire_civilizations (user_id TEXT PRIMARY KEY REFERENCES empire_users(id),revision INTEGER NOT NULL DEFAULT 0,data TEXT NOT NULL,last_op TEXT,last_tick INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS empire_requests (user_id TEXT NOT NULL,request_id TEXT NOT NULL,payload_hash TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(user_id,request_id))`,
  `CREATE TABLE IF NOT EXISTS empire_civic_events (user_id TEXT NOT NULL,event_id TEXT NOT NULL,game_day INTEGER NOT NULL,data TEXT NOT NULL,PRIMARY KEY(user_id,event_id))`,
  `CREATE TABLE IF NOT EXISTS empire_ledger (user_id TEXT NOT NULL,entry_id TEXT NOT NULL,game_day INTEGER NOT NULL,source TEXT NOT NULL,destination TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),reason TEXT NOT NULL,PRIMARY KEY(user_id,entry_id))`,
];
