import type { GameState } from "../engine/types";
import type { Civilization, CivAction } from "../civilization/types";
export interface Session {
  user: { id: string; name: string; email: string | null };
  trading: GameState;
  tradingVersion: number;
  civic: Civilization;
}
export let session: Session | null = null;
export async function api<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(path, {
    credentials: "same-origin",
    headers: body ? { "Content-Type": "application/json" } : {},
    method: body ? "POST" : "GET",
    body: body ? JSON.stringify(body) : undefined,
  });
  let data: { error?: string };
  try {
    data = await response.json();
  } catch {
    throw new Error("الخادم غير متاح. لم يتم تعديل البيانات المحفوظة.");
  }
  if (!response.ok) throw new Error(data.error ?? "تعذر التواصل مع الخادم");
  return data as T;
}
let sessionRequest: Promise<Session> | null = null;
export function getSession() {
  if (!sessionRequest)
    sessionRequest = api<Session>("/api/session")
      .then((r) => {
        session = r;
        return r;
      })
      .finally(() => {
        sessionRequest = null;
      });
  return sessionRequest;
}
export async function civicAction(
  action: CivAction,
  revision: number,
  requestId = crypto.randomUUID(),
) {
  return api<Session>("/api/civilization", { action, revision, requestId });
}
let queue = Promise.resolve();
export async function flushSaves() {
  await queue;
}
export function writeTrading(state: GameState) {
  const owner = session?.user.id;
  if (!owner) return Promise.reject(new Error("لا توجد جلسة"));
  const task = queue
    .catch(() => {})
    .then(async () => {
      if (owner !== session?.user.id)
        throw new Error("تغير الحساب أثناء الحفظ");
      const r = await api<{ version: number }>("/api/trading", {
        trading: state,
        version: session!.tradingVersion,
        userId: owner,
      });
      session!.tradingVersion = r.version;
      session!.trading = state;
    });
  queue = task;
  return task;
}
