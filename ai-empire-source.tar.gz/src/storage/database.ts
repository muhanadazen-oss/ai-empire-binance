import type { GameState } from "../engine/types";
import { api, getSession, session, writeTrading, type Session } from "./cloud";
let connection: Promise<IDBDatabase> | undefined;
function connect() {
  return (connection ??= new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open("ai-empire-v1", 1);
    req.onupgradeneeded = () => {
      for (const store of ["kingdom", "audit", "trades", "agents"])
        req.result.createObjectStore(store);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      connection = undefined;
      reject(req.error);
    };
    req.onblocked = () => reject(new Error("أغلق النسخة القديمة لفتح الحفظ"));
  }));
}
async function legacySave(): Promise<GameState | null> {
  try {
    const db = await connect();
    return new Promise((resolve, reject) => {
      const req = db
        .transaction("kingdom", "readonly")
        .objectStore("kingdom")
        .get("personal");
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}
export async function loadGame() {
  let current = await getSession();
  if (
    current.tradingVersion === 0 &&
    !localStorage.getItem("ai-empire-legacy-migrated-to")
  ) {
    const legacy = await legacySave();
    if (legacy?.version === 1) {
      current = await api<Session>("/api/migrate", { trading: legacy });
      session!.trading = current.trading;
      session!.tradingVersion = current.tradingVersion;
      localStorage.setItem("ai-empire-legacy-migrated-to", current.user.id);
    }
  }
  return { ...current.trading, running: false, council: null };
}
export async function saveGame(state: GameState) {
  await writeTrading(state);
  try {
    const db = await connect();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("kingdom", "readwrite");
      tx.objectStore("kingdom").put(state, `cloud:${session!.user.id}`);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    /* Successful cloud write remains authoritative if local cache is unavailable. */
  }
}
export async function resetDatabase() {
  const current = await api<Session>("/api/trading/reset", {});
  session!.tradingVersion = current.tradingVersion;
  session!.trading = current.trading;
}
