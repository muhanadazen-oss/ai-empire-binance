import { useEffect, useState } from 'react';
import { Lock, ShieldCheck, Link, RefreshCw, Unplug } from 'lucide-react';
import { api } from '../storage/cloud';
import './binance.css';
interface Status { registered: boolean; configured: boolean; connected: boolean; liveTrading: false; checkedAt?: string; balances?: { asset: string; free: string; locked: string }[] }
export function BinanceConnection({ onAccount }: { onAccount: () => void }) {
  const [status, setStatus] = useState<Status | null>(null);
  const [apiKey, setKey] = useState(''), [apiSecret, setSecret] = useState(''), [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [notice, setNotice] = useState('');
  const [checking, setChecking] = useState(false), [health, setHealth] = useState('');
  async function checkServer() {
    setChecking(true); setHealth('');
    try { const r = await api<{message:string}>('/api/binance/health'); setHealth(r.message); }
    catch(e) { setHealth((e as Error).message); }
    finally { setChecking(false); }
  }
  async function load() { setError(''); try { setStatus(await api<Status>('/api/binance/status')); } catch(e) { setError((e as Error).message); } }
  useEffect(() => { void load(); }, []);
  async function act(action: 'connect' | 'refresh' | 'disconnect') {
    setBusy(true); setError(''); setNotice('');
    try {
      await api(`/api/binance/${action}`, { password, ...(action === 'connect' ? { apiKey, apiSecret } : {}) });
      await load();
      setNotice(action === 'disconnect' ? 'تم حذف المفاتيح المحفوظة وفصل الاتصال.' : 'تم فحص الصلاحيات وقراءة الرصيد من Binance.');
    } catch(e) { setError((e as Error).message); }
    finally { setKey(''); setSecret(''); setPassword(''); setBusy(false); }
  }
  return <div className="binance-connection" dir="rtl">
    <span className="tiny-badge"><ShieldCheck size={14}/> ربط للقراءة فقط</span>
    <ol className="connection-steps"><li className={status?.registered ? "complete" : "current"}>1 · تسجيل الدخول</li><li className={status?.registered && !status.connected ? "current" : status?.connected ? "complete" : ""}>2 · إضافة المفتاح</li><li className={status?.connected ? "complete" : ""}>3 · فحص الاتصال</li></ol>
    <h2>جسر المملكة إلى Binance</h2>
    <p>شاهد أرصدة حسابك الحقيقي داخل اللعبة. محفظة المحاكاة واقتصاد السكان منفصلان تمامًا عن هذا الحساب.</p>
    <div className="connection-warning"><Lock size={20}/><div><strong>التداول الحقيقي مقفول</strong><p>لا أوامر شراء أو بيع، ولا إيداع أو سحب أو تحويل عبر اللعبة. الربط وحده لا يحقق أرباحًا.</p></div></div>
    {error && <p role="alert" className="connection-error">{error}</p>}
    {notice && <p role="status" className="connection-success">{notice}</p>}
    <div className="connection-diagnostics"><button className="button outline" disabled={checking || busy} onClick={() => void checkServer()}>{checking ? 'جارٍ فحص الخادم…' : 'فحص اتصال الخادم بدون مفتاح'}</button>{health && <p role="status">{health}</p>}</div>
    {!status && <button className="button outline" onClick={load}>إعادة تحميل حالة الاتصال</button>}
    {status && <>
      <div className="connection-status"><span className={status.connected ? 'connected' : ''}>{status.connected ? 'متصل · قراءة فقط' : 'غير متصل'}</span><span>حماية الخادم: {status.configured ? 'جاهزة' : 'غير جاهزة'}</span></div>
      {!status.registered ? <div className="connection-warning"><p>سجّل الدخول أو أنشئ حسابًا لحفظ الربط باسمك. إنشاء الحساب يحتفظ بتقدم المملكة الحالي، وبعده تنتقل تلقائيًا لإضافة المفتاح.</p><button className="button gold" onClick={onAccount}>فتح حساب المؤسس</button></div> : <>
        {status.connected && <div className="connection-balances"><h3>أرصدة Binance الفعلية</h3><p>آخر فحص: {status.checkedAt ? new Date(status.checkedAt).toLocaleString('ar') : '—'} · الأرصدة ليست أرباحًا</p><div className="balance-table"><table><thead><tr><th>العملة</th><th>المتاح</th><th>المحجوز</th></tr></thead><tbody>{status.balances?.map(b => <tr key={b.asset}><td>{b.asset}</td><td dir="ltr">{b.free}</td><td dir="ltr">{b.locked}</td></tr>)}</tbody></table></div>{!status.balances?.length && <p>لا توجد أرصدة غير صفرية في المحفظة الفورية.</p>}</div>}
        <form onSubmit={e => { e.preventDefault(); void act(status.connected ? 'refresh' : 'connect'); }} autoComplete="off" className="connection-form">
          {!status.connected && <><h3>إضافة مفتاح HMAC جديد</h3><p>فعّل القراءة فقط في Binance، وعطّل جميع صلاحيات التداول والسحب والتحويل. لا تستخدم المفتاح الذي شاركته سابقًا.</p><label>API Key<input disabled={busy} type="password" dir="ltr" value={apiKey} onChange={e => setKey(e.target.value.trim())} maxLength={128} required autoComplete="off" spellCheck={false}/></label><label>API Secret<input disabled={busy} type="password" dir="ltr" value={apiSecret} onChange={e => setSecret(e.target.value.trim())} maxLength={128} required autoComplete="off" spellCheck={false}/></label></>}
          <label>كلمة مرور حساب اللعبة لتأكيد العملية<input disabled={busy} type="password" value={password} onChange={e => setPassword(e.target.value)} required maxLength={128} autoComplete="off"/></label>
          <p className="connection-note">تُرسل المفاتيح إلى خادم اللعبة عبر HTTPS وتُحفظ مشفّرة. لا تُحفظ في التخزين المحلي ولا تُعرض مجددًا.</p>
          <div className="connection-actions"><button className="button gold" type="submit" disabled={busy || !status.configured}>{status.connected ? <RefreshCw size={17}/> : <Link size={17}/>} {busy ? 'جارٍ الفحص…' : status.connected ? 'تحديث الرصيد وفحص الصلاحيات' : 'فحص المفتاح وحفظ الربط'}</button>{status.connected && <button className="button outline" type="button" disabled={busy || !password} onClick={() => void act('disconnect')}><Unplug size={17}/> فصل وحذف المفاتيح</button>}</div>
        </form>
      </>}
    </>}
    <div className="source-links"><a href="https://www.binance.com/en/my/settings/api-management" target="_blank" rel="noreferrer">إدارة المفاتيح في Binance</a><a href="https://www.binance.com/official-verification" target="_blank" rel="noreferrer">التحقق من نطاق Binance</a></div>
  </div>;
}
