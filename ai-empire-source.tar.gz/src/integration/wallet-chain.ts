import { createPublicClient, createWalletClient, custom, encodeFunctionData, erc20Abi, getAddress, isAddress, parseUnits, zeroAddress, type Address, type EIP1193Provider } from 'viem';
import { bsc } from 'viem/chains';
import {checkWithdrawal} from './wallet-limits.ts';

export const TOKEN = '0x55d398326f99059ff775485246999027b3197955' as const;
export const DECIMALS = 18;
export function transferInput(recipient: string, amount: string) {
  if (!isAddress(recipient.trim(), { strict: true })) throw new Error('عنوان الإيداع غير صالح. انسخه كاملًا من Binance.');
  const to = getAddress(recipient.trim());
  if (to === zeroAddress || to.toLowerCase() === TOKEN.toLowerCase()) throw new Error('لا يمكن الإرسال إلى هذا العنوان.');
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,18})?$/.test(amount.trim())) throw new Error('اكتب مبلغًا صحيحًا؛ الحد الأقصى 18 رقمًا بعد الفاصلة.');
  const value = parseUnits(amount.trim(), DECIMALS);
  if (value <= 0n) throw new Error('المبلغ لازم يكون أكبر من صفر.');
  return { to, value };
}
export function clients(provider: EIP1193Provider) {
  return { reader: createPublicClient({ chain: bsc, transport: custom(provider) }), wallet: createWalletClient({ chain: bsc, transport: custom(provider) }) };
}
export async function checkContext(provider: EIP1193Provider, address: Address) {
  const { wallet } = clients(provider);
  if (await wallet.getChainId() !== bsc.id) throw new Error('اختار شبكة BNB Smart Chain (BEP20) بالمحفظة.');
  const accounts = await wallet.getAddresses();
  if (!accounts[0] || accounts[0].toLowerCase() !== address.toLowerCase()) throw new Error('الحساب تغيّر. اربط المحفظة من جديد.');
}
export async function balances(provider: EIP1193Provider, address: Address) {
  await checkContext(provider, address);
  const { reader } = clients(provider);
  const [usdt, bnb, decimals] = await Promise.all([
    reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'balanceOf', args: [address] }),
    reader.getBalance({ address }),
    reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'decimals' }),
  ]);
  if (decimals !== DECIMALS) throw new Error('تعذر التحقق من عقد العملة. الإرسال مقفول.');
  return { usdt, bnb };
}
export async function prepareTransfer(provider: EIP1193Provider, address: Address, recipient: string, amount: string) {
  const input = transferInput(recipient, amount);
  checkWithdrawal(input.value);
  if (input.to.toLowerCase() === address.toLowerCase()) throw new Error('هذا عنوان المحفظة نفسها؛ استخدم عنوان إيداع Binance.');
  const funds = await balances(provider, address);
  if (input.value > funds.usdt) throw new Error('رصيد USDT غير كافٍ.');
  const { reader } = clients(provider);
  const data = encodeFunctionData({ abi: erc20Abi, functionName: 'transfer', args: [input.to, input.value] });
  const [gas, gasPrice, simulation] = await Promise.all([
    reader.estimateGas({ account: address, to: TOKEN, data }), reader.getGasPrice(),
    reader.simulateContract({ account: address, address: TOKEN, abi: erc20Abi, functionName: 'transfer', args: [input.to, input.value] }),
  ]);
  if (simulation.result !== true) throw new Error('عقد العملة رفض التحويل.');
  const gasLimit = gas * 120n / 100n;
  if (gasLimit * gasPrice > funds.bnb) throw new Error('تحتاج رصيد BNB على نفس الشبكة لتغطية رسوم الإرسال.');
  return { ...input, gas: gasLimit, gasPrice, fee: gasLimit * gasPrice };
}
