export const MIN_DEPOSIT = 10n ** 18n;
export const MIN_WITHDRAWAL = 10n * 10n ** 18n;
export function checkWithdrawal(value: bigint) {
 if(value < MIN_WITHDRAWAL) throw new Error('أقل مبلغ للسحب هو 10 USDT، ورسوم الشبكة تُدفع من BNB.');
}
