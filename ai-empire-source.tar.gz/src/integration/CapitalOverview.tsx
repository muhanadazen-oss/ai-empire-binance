import {useEffect,useState} from 'react';
import {formatUnits} from 'viem';
import {api} from '../storage/cloud';
import './real-wallet.css';
export type WalletSummary={address:string;usdt:string;bnb:string;deposited:string;withdrawn:string;pending:string;checkedAt:string};
export default function CapitalOverview(){
 const [data,setData]=useState<WalletSummary|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false);
 async function refresh(){setBusy(true);try{const r=await api<{summary:WalletSummary|null}>('/api/wallet/summary');setData(r.summary);setError('');}catch(e){setError(e instanceof Error?e.message:'تعذر فحص المحفظة.');}finally{setLoading(false);setBusy(false);}}
 useEffect(()=>{refresh();const t=setInterval(()=>{if(!document.hidden)refresh();},30000);return()=>clearInterval(t);},[]);
 const value=(n:string|undefined)=>n===undefined?'—':formatUnits(BigInt(n),18);
 return <section className="real-wallet wallet-panel" dir="rtl" aria-label="حساب المحفظة الحقيقي"><h2>رأس المال الحقيقي</h2><div className="wallet-summary">{[['المتبقي في المحفظة',data?.usdt],['الإيداعات المتحققة',data?.deposited],['السحوبات المؤكدة',data?.withdrawn],['تحويلات بانتظار التأكيد',data?.pending]].map(([label,n])=><div key={label}><small>{label}</small><b dir="ltr">{value(n)} <span>USDT</span></b></div>)}</div>{loading?<p role="status">جاري فحص حساب المحفظة…</p>:error?<p role="alert">{error} {data?'الأرقام أعلاه من آخر فحص ناجح.':''}</p>:!data?<p>أنشئ محفظتك أو افتح حسابك ليظهر رصيدك الحقيقي هنا.</p>:<><p>آخر فحص: {new Date(data.checkedAt).toLocaleString('ar-PS',{timeZone:'Asia/Hebron'})} · رسوم الشبكة متاحة من {value(data.bnb)} BNB</p><p>الإيداعات تحتاج TxID للتحقق وإضافتها للمجموع. الرصيد الحالي يُقرأ من الشبكة.</p></>}<button disabled={busy} onClick={refresh}>تحديث الحساب</button><a href="#wallet">افتح المحفظة والإيداع والسحب</a><div className="wallet-note"><b>التداول الحقيقي: غير مُفعّل</b><p>لا توجد صفقات حقيقية منفّذة أو أرباح تداول متحققة في هذا الحساب. أي صرف حقيقي يُسجّل بتحويل مؤكد على الشبكة؛ مصاريف العالم الافتراضي لا تخصم USDT.</p><a href="#academy">مدرسة الوكلاء ومراجعة رأس المال</a></div></section>;
}
