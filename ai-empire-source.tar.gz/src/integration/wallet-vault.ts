import { isAddress, type Hex } from 'viem';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
export type Vault = { version: 1; chain: 56; owner: string; address: string; iterations: 310000; salt: string; iv: string; ciphertext: string };
const enc = new TextEncoder();
const b64 = (b: Uint8Array) => btoa(String.fromCharCode(...b));
const bytes = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
export function validVault(p: unknown): p is Vault {
  if (!p || typeof p !== 'object') return false;
  const v = p as Vault;
  return v.version === 1 && v.chain === 56 && v.iterations === 310000 && typeof v.owner === 'string' && v.owner.length <= 80 && typeof v.address === 'string' && isAddress(v.address) && [v.salt,v.iv,v.ciphertext].every(s => typeof s === 'string' && /^[A-Za-z0-9+/]+={0,2}$/.test(s)) && v.salt.length === 24 && v.iv.length === 16 && v.ciphertext.length === 112;
}
function aad(v: Vault) { return enc.encode(JSON.stringify([v.version,v.chain,v.owner,v.address.toLowerCase()])); }
async function key(password: string, salt: string) {
  if (password.length < 12 || password.length > 128) throw new Error('كلمة مرور المحفظة لازم تكون من 12 إلى 128 حرفًا.');
  const material = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name:'PBKDF2', salt:bytes(salt), iterations:310000, hash:'SHA-256' }, material, { name:'AES-GCM', length:256 }, false, ['encrypt','decrypt']);
}
export async function encryptWallet(owner: string, password: string, privateKey = generatePrivateKey()): Promise<Vault> {
  const v: Vault = { version:1, chain:56, owner, address:privateKeyToAccount(privateKey).address, iterations:310000, salt:b64(crypto.getRandomValues(new Uint8Array(16))), iv:b64(crypto.getRandomValues(new Uint8Array(12))), ciphertext:'' };
  v.ciphertext = b64(new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:bytes(v.iv),additionalData:aad(v)},await key(password,v.salt),enc.encode(privateKey))));
  return v;
}
export async function decryptWallet(v: Vault, password: string): Promise<Hex> {
  if (!validVault(v)) throw new Error('نسخة المحفظة غير صالحة.');
  try {
    const raw = new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(v.iv),additionalData:aad(v)},await key(password,v.salt),bytes(v.ciphertext)));
    if (!/^0x[\da-f]{64}$/i.test(raw) || privateKeyToAccount(raw as Hex).address.toLowerCase() !== v.address.toLowerCase()) throw new Error();
    return raw as Hex;
  } catch { throw new Error('كلمة مرور المحفظة غير صحيحة، أو النسخة الاحتياطية تالفة.'); }
}
