import { useEffect, useRef, useState } from 'react';
import { formatUnits, getAddress, type Address, type EIP1193Provider, type Hash } from 'viem';
import { bsc } from 'viem/chains';
import QRCode from 'qrcode';
import { balances, checkContext, clients, prepareTransfer, TOKEN } from './wallet-chain';
import './real-wallet.css';

type Provider = EIP1193Provider & { on?: (event: string, cb: (...args: any[]) => void) => void; removeListener?: (event: string, cb: (...args: any[]) => void) => void };
type Choice = { info: { uuid: string; name: string }; provider: Provider };
type Review = Awaited<ReturnType<typeof prepareTransfer>> & { from: Address };
function friendly(error: unknown) {
  const e = error as { code?: number; cause?: { code?: number }; message?: string };
  let current: any = e;
  for (let i = 0; current && i < 10; i++, current = current.cause) {
    if (current.code === 4001) return 'تم إلغاء الطلب من المحفظة.';
  }
  if (e.message && /^[\u0600-\u06ff]/.test(e.message)) return e.message;
  return 'تعذر إكمال الطلب. تحقق من الشبكة والرصيد واتصال تطبيق المحفظة، ثم حاول مجددًا.';
}
export default function RealWallet() {
  const [choices, setChoices] = useState<Choice[]>([]), [provider, setProvider] = useState<Provider | null>(null);
  const [address, setAddress] = useState<Address | null>(null), [funds, setFunds] = useState<{usdt: bigint; bnb: bigint} | null>(null);
  const [qr, setQr] = useState(''), [recipient, setRecipient] = useState(''), [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [review, setReview] = useState<Review | null>(null);
  const [ack, setAck] = useState(false), [hash, setHash] = useState<Hash | null>(null), [txState, setTxState] = useState<'pending'|'confirmed'|'reverted'|'unknown' | null>(null);
  const generation = useRef(0), operation = useRef(false);
  const reset = () => { generation.current++; setAddress(null); setFunds(null); setQr(''); setReview(null); setAck(false); setError(''); };
  useEffect(() => {
    const announce = (e: Event) => { const d = (e as CustomEvent<Choice>).detail; if (!d?.provider?.request || !d.info?.uuid) return; setChoices(old => old.some(p => p.info.uuid === d.info.uuid) ? old : [...old, d]); };
    window.addEventListener('eip6963:announceProvider', announce);
    window.dispatchEvent(new Event('eip6963:requestProvider'));
    const injected = (window as Window & { ethereum?: Provider }).ethereum;
    if (injected) setChoices(old => old.length ? old : [{ info: { uuid: 'injected', name: 'محفظة المتصفح' }, provider: injected }]);
    return () => { generation.current++; window.removeEventListener('eip6963:announceProvider', announce); };
  }, []);
  useEffect(() => {
    if (!provider) return;
    const changed = () => { reset(); setError('الحساب أو الشبكة تغيّر. اربط المحفظة من جديد.'); };
    provider.on?.('accountsChanged', changed); provider.on?.('chainChanged', changed); provider.on?.('disconnect', changed);
    return () => { provider.removeListener?.('accountsChanged', changed); provider.removeListener?.('chainChanged', changed); provider.removeListener?.('disconnect', changed); };
  }, [provider]);
  async function connect(p: Provider) {
    if (operation.current) return; operation.current = true; setBusy(true); reset(); setProvider(null);
    try {
      const { wallet } = clients(p);
      const accounts = await wallet.requestAddresses();
      if (!accounts[0]) throw new Error('المحفظة لم تعطِ عنوانًا.');
      try { await wallet.switchChain({ id: bsc.id }); } catch (e) {
        if ((e as {code?:number}).code !== 4902 && (e as {cause?:{code?:number}}).cause?.code !== 4902) throw e;
        await wallet.addChain({ chain: bsc }); await wallet.switchChain({ id: bsc.id });
      }
      const a = getAddress(accounts[0]); await checkContext(p, a);
      setProvider(p); setAddress(a);
      const current = generation.current;
      const [f, image] = await Promise.all([balances(p, a), QRCode.toDataURL(a, { margin: 2, width: 220 })]);
      if (current === generation.current) { setFunds(f); setQr(image); }
    } catch(e) { setError(friendly(e)); } finally { operation.current = false; setBusy(false); }
  }
  async function refresh() {
    if (!provider || !address || operation.current) return;
    operation.current = true; setBusy(true); setError(''); const current = generation.current;
    try { const f = await balances(provider, address); if (current === generation.current) setFunds(f); }
    catch(e) { setFunds(null); setError(friendly(e)); } finally { operation.current = false; setBusy(false); }
  }
  async function preview(e: React.FormEvent) {
    e.preventDefault(); if (!provider || !address || operation.current || txState === 'pending' || txState === 'unknown') return;
    operation.current = true; setBusy(true); setError(''); setReview(null); setAck(false); const current = generation.current;
    try { const r = await prepareTransfer(provider, address, recipient, amount); if (current === generation.current) setReview({ ...r, from: address }); }
    catch(e) { setError(friendly(e)); } finally { operation.current = false; setBusy(false); }
  }
  async function send() {
    if (!provider || !review || !address || !ack || operation.current || txState === 'pending' || txState === 'unknown') return;
    operation.current = true; setBusy(true); setError(''); const current = generation.current;
    try {
      const r = await prepareTransfer(provider, review.from, review.to, formatUnits(review.value, 18));
      if (current !== generation.current) throw new Error('الحساب أو الشبكة تغيّر. راجع التحويل من جديد.');
      const { wallet } = clients(provider);
      const h = await wallet.writeContract({ account: review.from, address: TOKEN, abi: [{ type: 'function', name: 'transfer', stateMutability: 'nonpayable', inputs: [{name:'to',type:'address'},{name:'value',type:'uint256'}], outputs:[{type:'bool'}] }], functionName: 'transfer', args: [r.to, r.value], gas: r.gas, gasPrice: r.gasPrice });
      setHash(h); setTxState('pending'); setReview(null); setAmount(''); setAck(false);
      await receipt(provider, h);
    } catch(e) { setError(friendly(e)); } finally { operation.current = false; setBusy(false); }
  }
  async function receipt(p: Provider, h: Hash) {
    try { const r = await clients(p).reader.waitForTransactionReceipt({ hash: h, confirmations: 3, timeout: 90000, pollingInterval: 3000 }); setTxState(r.status === 'success' ? 'confirmed' : 'reverted'); }
    catch { setTxState('unknown'); setError('الإرسال تمّ، لكن تأكيد الشبكة لم يصل بعد. تحقق من رابط العملية قبل أي إرسال جديد.'); }
    setFunds(null);
  }
  const locked = busy || txState === 'pending' || txState === 'unknown';
  return <section className="real-wallet">
    <div className="page-heading"><div><span className="tiny-badge">محفظتك الحقيقية</span><h1>إرسال واستقبال USDT</h1><p>شبكة BNB Smart Chain · BEP20</p></div></div>
    <p className="wallet-note">الأموال في محفظتك الشخصية. رصيد المملكة التجريبي والسكان منفصلان عنها. كل إرسال يحتاج موافقتك من تطبيق المحفظة، ولا يشغّل تداولًا تلقائيًا.</p>
    {!address ? <div className="wallet-panel"><h2>اربط محفظتك</h2><p>الربط يقرأ العنوان والرصيد. اللعبة لا تطلب عبارة الاسترداد أو المفتاح السري.</p>
      {choices.map(c => <button className="button gold" key={c.info.uuid} disabled={busy} onClick={() => connect(c.provider)}>ربط {c.info.name}</button>)}
      {!choices.length && <><p>على التلفون: افتح اللعبة داخل متصفح تطبيق MetaMask، ثم اضغط ربط المحفظة. إذا ما عندك محفظة، أنشئها داخل التطبيق واحفظ نسخة الاسترداد عندك.</p><a className="button gold" href={`https://metamask.app.link/dapp/${location.host}${location.pathname}#wallet`}>فتح اللعبة في MetaMask</a><a href="https://metamask.io/download/" target="_blank" rel="noreferrer">تنزيل MetaMask من الموقع الرسمي</a></>}
    </div> : <>
      <div className="wallet-panel wallet-balance"><div><small>رصيد USDT على الشبكة</small><b dir="ltr">{funds ? formatUnits(funds.usdt,18) : '—'} <span>USDT</span></b><small dir="ltr">{funds ? formatUnits(funds.bnb,18) : '—'} BNB للرسوم</small></div><button className="button" disabled={busy} onClick={refresh}>تحديث الرصيد</button><button className="button" disabled={busy} onClick={() => { reset(); setProvider(null); }}>فصل من اللعبة</button></div>
      <div className="wallet-columns"><div className="wallet-panel"><h2>استقبال من Binance</h2><p>في Binance: سحب ← USDT ← شبكة BNB Smart Chain (BEP20). الصق عنوان محفظتك التالي.</p>
        {qr && <img className="wallet-qr" src={qr} alt="رمز عنوان محفظتك للاستقبال على BNB Smart Chain" />}
        <code className="wallet-address" dir="ltr">{address}</code><button className="button" onClick={async()=>{ try {await navigator.clipboard.writeText(address); setError('تم نسخ عنوان الاستقبال.');} catch {setError('تعذر النسخ؛ انسخ العنوان المعروض يدويًا.');} }}>نسخ عنوان الاستقبال</button>
        <p className="wallet-note">استقبل USDT على BEP20 فقط. لا ترسل عبر TRC20 أو ERC20 لهذا الإعداد. ستحتاج BNB على نفس الشبكة عند الإرسال لاحقًا.</p></div>
      <div className="wallet-panel"><h2>إرسال إلى Binance</h2><p>انسخ عنوان إيداع USDT من Binance بعد اختيار BNB Smart Chain (BEP20). تحقق من الحد الأدنى للإيداع هناك.</p>
        <form onSubmit={preview}><label>عنوان إيداع USDT في Binance<input dir="ltr" autoComplete="off" value={recipient} disabled={locked} onChange={e=>{setRecipient(e.target.value);setReview(null);setAck(false);}} placeholder="0x…" required /></label><label>المبلغ بـUSDT<input dir="ltr" inputMode="decimal" value={amount} disabled={locked} onChange={e=>{setAmount(e.target.value);setReview(null);setAck(false);}} placeholder="0.00" required /></label><button className="button gold" disabled={locked || !funds}>مراجعة المبلغ والرسوم</button></form>
        {review && <div className="wallet-review"><h3>راجع قبل الإرسال</h3><b dir="ltr">{formatUnits(review.value,18)} USDT</b><code dir="ltr">{review.to}</code><p>رسوم الشبكة المقدّرة: <span dir="ltr">{formatUnits(review.fee,18)} BNB</span>. الرسوم النهائية تظهر بالمحفظة.</p><label className="wallet-check"><input type="checkbox" checked={ack} disabled={busy} onChange={e=>setAck(e.target.checked)} />هذا عنوان إيداعي في Binance على BEP20، وتحققت من المبلغ والحد الأدنى.</label><button className="button gold" disabled={!ack || locked} onClick={send}>الموافقة من المحفظة وإرسال</button></div>}
      </div></div>
    </>}
    {busy && <p role="status">جاري تنفيذ الطلب… إذا فتحت المحفظة، راجع الطلب هناك.</p>}
    {error && <p className="wallet-message" role="status">{error}</p>}
    {hash && <div className="wallet-panel"><h2>{txState === 'confirmed' ? 'تم تأكيد التحويل على الشبكة' : txState === 'reverted' ? 'فشل التحويل على الشبكة' : 'التحويل بانتظار التحقق'}</h2><a href={`https://bscscan.com/tx/${hash}`} target="_blank" rel="noreferrer">تتبع العملية على BscScan</a><p>تأكيد الشبكة لا يعني أن Binance أضاف المبلغ فورًا؛ راجع سجل الإيداعات هناك.</p>{txState === 'unknown' && provider && <button className="button" disabled={busy} onClick={async()=>{if(operation.current)return;operation.current=true;setBusy(true);await receipt(provider,hash);operation.current=false;setBusy(false);}}>فحص التأكيد مجددًا</button>}</div>}
    <p className="wallet-sources"><a href="https://www.binance.com/en/support/faq/detail/115003670492" target="_blank" rel="noreferrer">شرح الشبكات والتحويل من Binance</a><a href="https://docs.bnbchain.org/bnb-smart-chain/developers/wallet-configuration/" target="_blank" rel="noreferrer">تفاصيل شبكة BNB Smart Chain</a></p>
  </section>;
}
