// Educational sizing only; never reserves funds or signs transactions.
export function capitalPlan(balance:number,entry:number,stop:number,pending:number=0){
 if(![balance,entry,stop,pending].every(Number.isFinite)||balance<=0||entry<=0||stop<=0||stop>=entry||pending<0)return null;
 const available=Math.max(0,balance-pending),distance=(entry-stop)/entry;
 const riskBudget=available*.01,allocationCap=available*.05;
 const amount=Math.floor(Math.min(allocationCap,riskBudget/distance)*100)/100;
 if(amount<=0)return null;
 return {available,riskBudget,allocationCap,amount,quantity:amount/entry,plannedLoss:amount*distance,reserve:available-amount};
}
