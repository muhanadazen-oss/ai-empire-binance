export type Strategy = 'conservative'|'balanced'|'aggressive';
export type Tone = 'good'|'warn'|'info'|'bad';
export interface Agent {id:string;name:string;role:string;skill:string;color:string;xp:number;decisions:number;wins:number;resolved:number;status:string;history:string[]}
export interface Asset {symbol:string;name:string;price:number;start:number;change:number;history:number[]}
export interface Trade {id:string;symbol:string;amount:number;quantity:number;entry:number;openedAt:number;closedAt?:number;exit?:number;pnl?:number;reason?:string;strategy:Strategy;takeProfit:number;stopLoss:number;openedBy?:string;closedBy?:string;opportunityScore?:number;councilId?:string}
export interface Log {id:string;at:number;text:string;kind:Tone;actor:string;detail?:string}
export interface Message {agent:string;text:string;at:number}
export interface Council {symbol:string;amount:number;confidence:number;step:number;messages:Message[];id:string;approved?:boolean;riskApproved?:boolean;reviewedAtTick?:number}
export interface Task {id:string;title:string;target:number;progress:number;reward:number;claimed:boolean}
export interface Achievement {id:string;title:string;description:string;reward:number;unlocked:boolean}
export interface GameState {academy?:{completed:string[];lastAt:number;tests:number;passed:number};version:1;seed:number;cash:number;capital:number;xp:number;ticks:number;running:boolean;emergency:boolean;strategy:Strategy;day:string;dayStartEquity:number;dailyLosses:number;risk:{dailyLossPct:number;maxTradePct:number;maxExposurePct:number};assets:Asset[];agents:Agent[];open:Trade[];closed:Trade[];logs:Log[];council:Council|null;lastCouncil:Message[];scans:number;decisions:number;rejected:number;tasks:Task[];achievements:Achievement[];visited:string[];equityHistory:number[];notifications:Log[];event:string;eventBias:number;eventUntil:number;reportViews:number}
export interface Broker {readonly mode:'simulation';execute(state:GameState,proposal:Council):GameState;close(state:GameState,id:string,reason:string):GameState}
export interface GameState {
  market?: { source:'Binance'; observedAt:number };
  opportunitySearch?: { runs:number; lastTick:number; candidates:import('./opportunity.ts').OpportunityEvaluation[] };
  executionWatch?: { checks:number; lastTick:number; automaticClosures:number };
}
