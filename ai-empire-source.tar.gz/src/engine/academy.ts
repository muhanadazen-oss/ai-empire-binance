import type {GameState} from './types.ts';
import {capitalPlan} from '../integration/capital-plan.ts';
export const LESSONS=[
 {id:'sources',agent:'advisor',title:'المصدر قبل التوصية',text:'رؤى تتحقق من رابط الخبر ووقته. العنوان وحده لا يثبت فرصة ربح.',cases:['خبر من مصدر غير موثق: رفض','خبر قديم: رفض','خبر حديث موثق: ينتقل لتحليل السوق']},
 {id:'market',agent:'analyst',title:'قراءة السوق',text:'نور يراجع الشموع المغلقة والاتجاه والحجم والتقلب. لا تُقبل بيانات ناقصة أو قديمة.',cases:['سوق قديم أو ناقص: رفض','مؤشرات متعارضة: انتظار','شموع حديثة واتجاه متوافق: مراجعة']},
 {id:'entry',agent:'trader',title:'خطة الدخول والخروج',text:'رائد يكتب الدخول والهدف والوقف بعد التحليل. السعر المرجعي ليس سعر تنفيذ مضمونًا.',cases:['لا تحليل: رفض','لا خطة خروج: رفض','خطة شراء مدروسة: يراجعها مدير المخاطر']},
 {id:'capital',agent:'risk',title:'رأس المال والمخاطرة',text:'سلمى وحدها تحسب الحجم المقترح. نموذج التدريب يخصص 5% كحد أقصى للصفقة ويختبر خسارة مخططة ضمن 1% من الرصيد المتاح.',cases:['رصيد غير متحقق: رفض','حجم يتجاوز السقف: تصغير أو رفض','التكاليف تجعل الحجم غير عملي: انتظار']},
 {id:'monitor',agent:'monitor',title:'المراقبة والتأكيد',text:'ليث يتابع المعاملة على الشبكة. لا يكرر الإرسال بسبب تأخر ظهور النتيجة.',cases:['معلقة: لا إعادة إرسال بمبلغ جديد','مرفوضة: لا تُحسب صفقة رابحة','مؤكدة: تُسجل النتيجة الفعلية']},
 {id:'approval',agent:'director',title:'تنسيق القرار',text:'آدم يجمع الدراسة ومراجعة المخاطرة. اجتياز المدرسة لا يمنح صلاحية توقيع أو سحب أموال.',cases:['دراسة غير مكتملة: إيقاف','لا توقيع مصرح: لا تنفيذ','اعتماد الدراسة: تظل مراجعة وليست صفقة']}
] as const;
export type AcademyState={completed:string[];lastAt:number;tests:number;passed:number};
export function trainAcademy(state:GameState,id:string):GameState{
 const lesson=LESSONS.find(l=>l.id===id);if(!lesson)return state;
 const s=structuredClone(state),previous=s.academy??{completed:[],lastAt:0,tests:0,passed:0};
 // Validate actual sizing invariant in the capital lesson, with no wallet writes.
 if(id==='capital'){const p=capitalPlan(40,100,95);if(!p||p.amount>2||p.plannedLoss>.4)throw new Error('فشل اختبار قاعدة المخاطرة.');}
 const result=checkLesson(id);if(result.tests!==lesson.cases.length||result.passed!==result.tests)throw new Error('لم يجتز الدرس اختبارات القواعد.');
 const first=!previous.completed.includes(id);
 s.academy={completed:first?[...previous.completed,id]:previous.completed,lastAt:Date.now(),tests:previous.tests+result.tests,passed:previous.passed+result.passed};
 const agent=s.agents.find(a=>a.id===lesson.agent);if(agent){agent.history.unshift(`اختبار قواعد المدرسة: ${lesson.title} — ${lesson.cases.join('؛ ')}. دون صرف أموال.`);agent.history=agent.history.slice(0,200);agent.status='اجتاز اختبار قواعد المدرسة';if(first)agent.xp+=3;}
 return s;
}

export function checkLesson(id:string){
 const checks:Record<string,boolean[]>={
  sources:[!sourceAllowed('http://evil.example',Date.now()),!sourceAllowed('https://www.coindesk.com/story',Date.now()-72*3600000),sourceAllowed('https://www.coindesk.com/story',Date.now())],
  market:[!marketAllowed(Date.now()-2*3600000,true,true),!marketAllowed(Date.now(),true,false),marketAllowed(Date.now(),true,true)],
  entry:[!entryAllowed(false,100,95,110),!entryAllowed(true,100,0,110),entryAllowed(true,100,95,110)],
  capital:[capitalPlan(0,100,95)===null,(capitalPlan(40,100,95)?.amount??Infinity)<=2,(capitalPlan(40,100,50)?.plannedLoss??Infinity)<=.4],
  monitor:[!settled('pending'),!settled('reverted'),settled('confirmed')],
  approval:[!approved(false,true),!approved(true,false),approved(true,true)]
 };
 const result=checks[id]??[];return {tests:result.length,passed:result.filter(Boolean).length};
}
function sourceAllowed(link:string,date:number){try{const u=new URL(link);return u.protocol==='https:'&&u.hostname==='www.coindesk.com'&&Date.now()-date<=48*3600000&&date<=Date.now();}catch{return false;}}
function marketAllowed(at:number,complete:boolean,aligned:boolean){return complete&&aligned&&Date.now()-at<=90*60000;}
function entryAllowed(analysed:boolean,entry:number,stop:number,target:number){return analysed&&stop>0&&stop<entry&&target>entry;}
function settled(status:string){return status==='confirmed';}
function approved(study:boolean,risk:boolean){return study&&risk;}
