import type {GameState,Strategy,Log,Council,Tone,Task} from './types.ts';
import {evaluateOpportunity,marketReversed,MIN_OPPORTUNITY_SCORE,OPPORTUNITY_RULE_VERSION} from './opportunity.ts';
export const AGENT_DEFINITIONS = [
 ['director','آدم','المدير العام','تنسيق الفريق واعتماد قرارات المجلس دون تجاوز سلمى','#e6c27a'],
 ['analyst','نور','محلل السوق','قراءة اتجاه السوق ومؤشراته قبل طرح فكرة','#54d7e6'],
 ['trader','رائد','مخطط الصفقات','إعداد خطة دخول بعد استلام تحليل نور؛ التنفيذ ليامن','#9f8af4'],
 ['risk','سلمى','المديرة المالية ومديرة المخاطر','الوحيدة المخولة بمراجعة رأس المال والمخاطر','#65d5a5'],
 ['monitor','ليث','مراقب السوق والصفقات','متابعة الأسعار والمراكز والتنبيه للتغيرات؛ الإغلاق ليامن','#efa372'],
 ['advisor','رؤى','باحثة التوصيات','جمع الأفكار المنشورة والتحقق من المصدر والتاريخ','#d98bc8'],
 ['executor','يامن','منفذ الصفقات ومتابع الإغلاق','يفتح بعد موافقة آدم وسلمى؛ يغلق عند الهدف أو الوقف أو انعكاس الاتجاه','#7eb9ed'],
 ['scout','جود','كشاف الفرص','يفحص جميع الأصول أثناء الدورة؛ يرفع التقييم 75% فأعلى لآدم دون ضمان ربح','#d3a4ed'],
];
export const LEVELS=[{name:'قرية',xp:0},{name:'بلدة',xp:180},{name:'مدينة',xp:480},{name:'عاصمة',xp:950},{name:'إمبراطورية',xp:1600}];
export const STRATEGIES:Record<Strategy,{name:string;description:string;allocation:number;confidence:number;tp:number;sl:number;slots:number}>= {
 conservative:{name:'محافظ',description:'صفقات أقل، احتياطي أكبر ومراجعة صارمة.',allocation:.12,confidence:.75,tp:.025,sl:.014,slots:2},
 balanced:{name:'متوازن',description:'توازن بين الفرص وحماية رأس المال.',allocation:.20,confidence:.75,tp:.035,sl:.022,slots:3},
 aggressive:{name:'هجومي',description:'تقلب أعلى ضمن المخاطر؛ نفس حد التقييم 75%.',allocation:.30,confidence:.75,tp:.050,sl:.032,slots:4}
};
const uid=()=>globalThis.crypto.randomUUID();
export const today=()=>new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Hebron'});
const tasks=():Task[]=>[{id:'scan',title:'اعقد 3 اجتماعات للمجلس',target:3,progress:0,reward:45,claimed:false},{id:'close',title:'أكمل صفقتين تجريبيتين',target:2,progress:0,reward:55,claimed:false},{id:'visit',title:'استكشف 4 مبانٍ في المملكة',target:4,progress:0,reward:35,claimed:false}];
export function initialState(seed=Date.now()>>>0):GameState {
 const definitions=AGENT_DEFINITIONS;
 return {version:1,seed:seed||12345,cash:40,capital:40,xp:0,ticks:0,running:false,emergency:false,strategy:'balanced',day:today(),dayStartEquity:40,dailyLosses:0,risk:{dailyLossPct:8,maxTradePct:25,maxExposurePct:60},assets:[['BTC','بيتكوين',62400],['ETH','إيثريوم',2850],['SOL','سولانا',142]].map(([symbol,name,price])=>({symbol:String(symbol),name:String(name),price:Number(price),start:Number(price),change:0,history:Array(35).fill(Number(price))})),agents:definitions.map(([id,name,role,skill,color])=>({id,name,role,skill,color,xp:0,decisions:0,wins:0,resolved:0,status:'جاهز للعمل',history:[]})),open:[],closed:[],logs:[{id:uid(),at:Date.now(),text:'تأسست مملكتك برأس مال تجريبي 40$ — ابدأ دورة المملكة.',kind:'good',actor:'النظام'}],council:null,lastCouncil:[],scans:0,decisions:0,rejected:0,tasks:tasks(),achievements:[{id:'first',title:'أول قرار',description:'أكمل أول اجتماع لمجلس المملكة',reward:25,unlocked:false},{id:'explorer',title:'مستكشف المملكة',description:'استكشف المباني الثمانية',reward:50,unlocked:false},{id:'guardian',title:'درع المملكة',description:'اختبر زر إيقاف الطوارئ',reward:25,unlocked:false},{id:'trader',title:'اقتصاد حي',description:'أكمل 5 صفقات تجريبية',reward:75,unlocked:false},{id:'city',title:'باني المدينة',description:'وصل إلى المستوى الثالث',reward:100,unlocked:false}],visited:[],equityHistory:[40],notifications:[],event:'هدوء اقتصادي • الأسواق التجريبية جاهزة',eventBias:0,eventUntil:0,reportViews:0};
}
export function assignAgentRoles(state:GameState):GameState {
 const existing=new Map(state.agents.map(a=>[a.id,a]));
 state.agents=AGENT_DEFINITIONS.map(([id,name,role,skill,color])=>{
  const previous=existing.get(id);
  return previous ? {...previous,role,skill} : {id,name,role,skill,color,xp:0,decisions:0,wins:0,resolved:0,status:'جاهز للعمل',history:[]};
 });
 return state;
}
export const levelOf=(s:GameState)=>LEVELS.reduce((n,l,i)=>s.xp>=l.xp?i:n,0);
export function equity(s:GameState){return s.cash+s.open.reduce((v,t)=>v+t.quantity*(s.assets.find(a=>a.symbol===t.symbol)?.price??t.entry),0)}
export const exposure=(s:GameState)=>s.open.reduce((v,t)=>v+t.quantity*(s.assets.find(a=>a.symbol===t.symbol)?.price??t.entry),0);
export const unrealized=(s:GameState)=>s.open.reduce((v,t)=>v+t.quantity*(s.assets.find(a=>a.symbol===t.symbol)?.price??t.entry)-t.amount,0);
export function dailyLoss(s:GameState){return Math.max(s.dailyLosses+Math.max(0,-unrealized(s)),s.dayStartEquity-equity(s),0)}
export function marketFresh(s:GameState){return !!s.market&&Date.now()-s.market.observedAt<=120000&&Date.now()-s.market.observedAt>=-30000;}
export function applyMarketPrices(state:GameState,prices:Record<string,number>,observedAt:number):GameState {
 if(!Number.isFinite(observedAt)||Date.now()-observedAt>120000||observedAt>Date.now()+30000||Object.values(prices).some(p=>!Number.isFinite(p)||p<=0)||state.assets.some(a=>!prices[a.symbol]))return state;
 const s=structuredClone(state),first=!s.market;
 for(const a of s.assets){a.price=prices[a.symbol];if(first){a.start=a.price;a.history=[];}a.change=(a.price/a.start-1)*100;a.history.push(a.price);a.history=a.history.slice(-90);}
 s.market={source:'Binance',observedAt};s.event='أسعار Binance الفعلية • التنفيذ التدريبي بمال افتراضي';s.eventBias=0;
 if(s.running)watchTrades(s);s.equityHistory.push(equity(s));s.equityHistory=s.equityHistory.slice(-500);return s;
}
function log(s:GameState,text:string,kind:Tone='info',actor='النظام',detail?:string){const l:Log={id:uid(),at:Date.now(),text,kind,actor,detail};s.logs.push(l);if(kind!=='info'){s.notifications.unshift(l);s.notifications=s.notifications.slice(0,30)} }
function achievement(s:GameState,id:string){const a=s.achievements.find(a=>a.id===id);if(a&&!a.unlocked){a.unlocked=true;s.xp+=a.reward;log(s,`إنجاز جديد: ${a.title} • +${a.reward} XP`,'good','التقدم')}}
function progress(s:GameState){if(s.closed.length>=5)achievement(s,'trader');if(s.visited.length>=8)achievement(s,'explorer');if(levelOf(s)>=2)achievement(s,'city');unlockTasks(s)}
function unlockTasks(s:GameState){const level=levelOf(s);const additions=[{id:'diversify',title:'نوّع الصفقات على أصلين اليوم',target:2,reward:65,level:2},{id:'protect',title:'راقب رفض صفقتين اليوم',target:2,reward:75,level:3},{id:'master',title:'أكمل 5 اجتماعات في الإمبراطورية',target:5,reward:90,level:4}];for(const t of additions){if(level>=t.level&&!s.tasks.some(x=>x.id===t.id)){s.tasks.push({id:t.id,title:t.title,target:t.target,progress:0,reward:t.reward,claimed:false});log(s,`مهمة جديدة متاحة: ${t.title}`,'good','التقدم')}}}
function agentNote(s:GameState,id:string,text:string){const a=s.agents.find(a=>a.id===id)!;a.xp+=4;a.decisions++;a.history.unshift(text);a.history=a.history.slice(0,200);a.status=text;}
function rollover(s:GameState){if(s.day!==today()){s.day=today();s.dayStartEquity=equity(s);s.dailyLosses=0;s.tasks=tasks();s.visited=[];unlockTasks(s);log(s,'بدأ يوم جديد؛ جُددت المهام وحد الخسارة اليومي','good')}}
export function checkRisk(s:GameState,p:Pick<Council,'symbol'|'amount'|'confidence'>):{ok:boolean;reason:string} {
 const spec=STRATEGIES[s.strategy],eq=equity(s);
 if(s.emergency)return {ok:false,reason:'إيقاف الطوارئ مفعل'};
 if(!marketFresh(s))return {ok:false,reason:'لا توجد أسعار Binance حديثة؛ التداول التدريبي متوقف'};
 if(dailyLoss(s)>=s.dayStartEquity*s.risk.dailyLossPct/100)return {ok:false,reason:'بلوغ حد الخسارة اليومي'};
 if(!Number.isFinite(p.amount)||p.amount<.5)return {ok:false,reason:'قيمة الصفقة غير صالحة أو أقل من 0.50$'};
 if(!s.assets.some(a=>a.symbol===p.symbol))return {ok:false,reason:'أصل تجريبي غير معروف'};
 if(p.amount>eq*s.risk.maxTradePct/100+.000001)return {ok:false,reason:'تجاوز الحد الأقصى للصفقة'};
 if(p.amount*1.001>s.cash)return {ok:false,reason:'الرصيد المتاح غير كافٍ مع رسوم المحاكاة'};
 if(exposure(s)+p.amount>eq*s.risk.maxExposurePct/100)return {ok:false,reason:'تجاوز إجمالي التعرض؛ يجب الاحتفاظ باحتياطي'};
 if(s.open.length>=spec.slots)return {ok:false,reason:'بلوغ عدد الصفقات المسموح للاستراتيجية'};
 if(s.open.some(t=>t.symbol===p.symbol))return {ok:false,reason:'يوجد مركز مفتوح لهذا الأصل بالفعل'};
 if(!Number.isFinite(p.confidence)||p.confidence>1||p.confidence<Math.max(MIN_OPPORTUNITY_SCORE/100,spec.confidence))return {ok:false,reason:'تقييم الفرصة أقل من 75% أو غير صالح؛ ليس ضمان ربح'};
 return {ok:true,reason:'اجتازت الصفقة جميع حدود المخاطر'};
}
function plannedAmount(s:GameState) {
 const spec=STRATEGIES[s.strategy];
 return Math.max(.5,Math.floor(equity(s)*Math.min(spec.allocation,s.risk.maxTradePct/100)*100)/100);
}
export function startCouncil(state:GameState,symbol?:string,amount?:number) {
 const s=assignAgentRoles(structuredClone(state));rollover(s);
 if(s.council||s.emergency){log(s,s.emergency?'لا يمكن بدء اجتماع أثناء إيقاف الطوارئ':'المجلس في اجتماع حاليًا','warn');return s;}
 const ranked=s.assets.map(a=>({asset:a,evaluation:evaluateOpportunity(a)})).sort((a,b)=>b.evaluation.score-a.evaluation.score);
 const chosen=symbol?ranked.find(r=>r.asset.symbol===symbol):ranked[0];
 if(!chosen){log(s,'أصل تجريبي غير معروف؛ لم يبدأ اجتماع','warn');return s;}
 s.council={id:uid(),symbol:chosen.asset.symbol,amount:amount??plannedAmount(s),confidence:chosen.evaluation.score/100,step:0,messages:[]};
 s.scans++;s.tasks.find(t=>t.id==='scan')!.progress++;
 s.agents.forEach(a=>a.status='مجلس المملكة منعقد');
 log(s,`بدأ المجلس دراسة ${chosen.asset.symbol} بقيمة ${s.council.amount.toFixed(2)}$ تجريبية؛ تقييم قواعد ${chosen.evaluation.score}%`,'info','مركز التحليل',`rules=${OPPORTUNITY_RULE_VERSION}; النسبة ليست احتمال نجاح`);
 return s;
}
export function scanOpportunities(state:GameState):GameState {
 const s=assignAgentRoles(structuredClone(state));
 if(s.emergency)return s;
 const candidates=s.assets.map(evaluateOpportunity).sort((a,b)=>b.score-a.score);
 s.opportunitySearch={runs:(s.opportunitySearch?.runs??0)+1,lastTick:s.ticks,candidates};
 const candidate=candidates.find(c=>c.eligible&&checkRisk(s,{symbol:c.symbol,amount:plannedAmount(s),confidence:c.score/100}).ok);
 if(candidate&&!s.council){
  const text=`جود إلى آدم: فرصة ${candidate.symbol} بتقييم ${candidate.score}%؛ اطلب تحليل نور ومراجعة سلمى قبل أي تنفيذ.`;
  agentNote(s,'scout',text);log(s,text,'good','كشاف الفرص');
  agentNote(s,'director',`وصلت فرصة ${candidate.symbol}؛ أحلتها إلى المجلس للتحليل.`);
  return startCouncil(s,candidate.symbol);
 }
 const text=s.council?'جود يفحص بقية الأصول؛ ينتظر انتهاء مراجعة المجلس.':candidates.some(c=>c.eligible)?'جود: التقييم مناسب، لكن حدود رأس المال أو المراكز تمنع الدخول؛ أواصل البحث.':'جود: لا فرصة مؤهلة بتقييم 75% فأعلى؛ أواصل البحث دون فتح صفقة.';
 agentNote(s,'scout',text);log(s,text,'info','كشاف الفرص');return s;
}
function openTrade(s:GameState,c:Council){const a=s.assets.find(a=>a.symbol===c.symbol)!,spec=STRATEGIES[s.strategy];s.cash-=c.amount*1.001;s.dailyLosses+=c.amount*.001;s.open.push({id:uid(),symbol:c.symbol,amount:c.amount,quantity:c.amount/a.price,entry:a.price,openedAt:Date.now(),strategy:s.strategy,takeProfit:a.price*(1+spec.tp),stopLoss:a.price*(1-spec.sl),openedBy:'executor',opportunityScore:c.confidence*100,councilId:c.id});const diversification=s.tasks.find(t=>t.id==='diversify');if(diversification)diversification.progress=new Set([...s.open,...s.closed].filter(t=>new Date(t.openedAt).toLocaleDateString('en-CA',{timeZone:'Asia/Hebron'})===s.day).map(t=>t.symbol)).size;log(s,`تم فتح صفقة ${c.symbol} • ${c.amount.toFixed(2)}$ تجريبية`,'good','يامن • منفذ الصفقات',`مراجعة المجلس ${c.id} | رسوم محاكاة 0.1% | وقف ${spec.sl*100}% | هدف ${spec.tp*100}%`)}
function closeInPlace(s:GameState,id:string,reason:string,automatic=false){const t=s.open.find(t=>t.id===id);if(!t)return;const price=s.assets.find(a=>a.symbol===t.symbol)!.price,proceeds=t.quantity*price*.999,pnl=proceeds-t.amount*1.001;s.cash+=proceeds;s.open=s.open.filter(x=>x.id!==id);s.closed.push({...t,closedAt:Date.now(),exit:price,pnl,reason,closedBy:'executor'});s.dailyLosses+=Math.max(0,t.amount-proceeds);s.xp+=18;s.tasks.find(t=>t.id==='close')!.progress++;s.agents.forEach(a=>{a.resolved++;if(pnl>0)a.wins++;a.xp+=pnl>0?8:3});agentNote(s,'executor',`أغلقت ${t.symbol} • ${reason} • ${pnl.toFixed(3)}$`);if(automatic){s.executionWatch??={checks:0,lastTick:s.ticks,automaticClosures:0};s.executionWatch.automaticClosures++;};log(s,`أُغلقت ${t.symbol}: ${pnl>=0?'+':''}${pnl.toFixed(3)}$ • ${reason}`,pnl>=0?'good':'warn','يامن • منفذ الصفقات');progress(s)}
export function closeTrade(state:GameState,id:string,reason='إغلاق يدوي'){const s=assignAgentRoles(structuredClone(state));rollover(s);closeInPlace(s,id,reason);return s}
function watchTrades(s:GameState) {
 s.executionWatch={checks:(s.executionWatch?.checks??0)+1,lastTick:s.ticks,automaticClosures:s.executionWatch?.automaticClosures??0};
 for(const t of s.open.slice()) {
  const asset=s.assets.find(a=>a.symbol===t.symbol);if(!asset)continue;
  const reason=asset.price<=t.stopLoss?'وقف الخسارة':asset.price>=t.takeProfit?'تحقق هدف الربح':marketReversed(asset,t.entry)?'انعكاس اتجاه السوق':null;
  if(reason){agentNote(s,'monitor',`ليث ينبه يامن: ${t.symbol} • ${reason}`);closeInPlace(s,t.id,reason,true);}
 }
 const executor=s.agents.find(a=>a.id==='executor');
 if(executor)executor.status=s.open.length?`أتابع ${s.open.length} صفقات؛ إغلاق عند الهدف أو الوقف أو انعكاس الاتجاه`:'لا مراكز مفتوحة؛ أنتظر موافقة المجلس';
}
function finishCouncil(s:GameState,c:Council,executed:boolean) {
 s.decisions++;
 if(!executed){s.rejected++;const protection=s.tasks.find(t=>t.id==='protect');if(protection)protection.progress++;}
 const mastery=s.tasks.find(t=>t.id==='master');if(mastery)mastery.progress++;
 s.xp+=12;s.lastCouncil=c.messages;s.council=null;achievement(s,'first');progress(s);
}
export function tick(state:GameState) {
 if(!state.running&&!state.council&&state.day===today())return state;
 let s=assignAgentRoles(structuredClone(state));rollover(s);if(!s.running&&!s.council)return s;
 if(!marketFresh(s)){s.running=false;s.council=null;log(s,'انقطعت أسعار Binance؛ توقف التدريب دون توليد أسعار بديلة','warn');return s;}
 if(s.running&&!s.emergency){
  s.ticks++;
  // Protect existing positions on every cycle, including cycles without a price update.
  watchTrades(s);
  // Prices arrive only through authenticated server reads of Binance market data.
  // A browser animation tick never moves market prices or invents economic shocks.
  if(dailyLoss(s)>=s.dayStartEquity*s.risk.dailyLossPct/100){s.running=false;s.council=null;s.open.slice().forEach(t=>closeInPlace(s,t.id,'حماية الحد اليومي',true));s.agents.forEach(a=>a.status='توقف لحماية الحد اليومي');log(s,'أوقفت سلمى الدورة بعد بلوغ حد الخسارة اليومي','bad','سلمى • إدارة المخاطر');return s;}
  if(s.ticks%6===1)s=scanOpportunities(s);
 }
 if(s.council){
  const c=s.council,asset=s.assets.find(a=>a.symbol===c.symbol);
  const evaluation=asset?evaluateOpportunity(asset):null;
  c.confidence=(evaluation?.score??0)/100;
  const risk=checkRisk(s,c),qualifies=!!evaluation?.eligible;
  const rejection=!qualifies?(evaluation?.reason??'بيانات السوق غير صالحة'):!risk.ok?risk.reason:c.step>=6&&c.riskApproved!==true?'لم توافق سلمى على الخطة؛ يلزم اجتماع جديد':risk.reason;
  const messages=[
   ['scout',`جود يرفع ${c.symbol} لآدم بتقييم قواعد ${Math.floor(c.confidence*100)}%؛ الحد الأدنى 75%، دون ضمان ربح.`],
   ['advisor',`رؤى تراجع فكرة ${c.symbol} داخل المحاكاة؛ الأخبار المنشورة متاحة في مكتب البحث المستقل.`],
   ['analyst',`نور: تقييم ${c.symbol} الحالي ${Math.floor(c.confidence*100)}%. ${evaluation?.rules.map(r=>`${r.passed?'اجتاز':'لم يجتز'} ${r.label}`).join('؛ ')??'بيانات غير صالحة'}.`],
   ['trader',`رائد يعد خطة ${c.amount.toFixed(2)}$ تجريبية؛ هدف ${(STRATEGIES[s.strategy].tp*100).toFixed(1)}% ووقف ${(STRATEGIES[s.strategy].sl*100).toFixed(1)}%. التنفيذ ليامن بعد الموافقة.`],
   ['monitor',`ليث يراجع ${s.open.length} مراكز مفتوحة ويرسل تنبيهات الإغلاق إلى يامن.`],
   ['risk',risk.ok&&qualifies?'سلمى، مسؤولة رأس المال والمخاطر الوحيدة: الخطة اجتازت التقييم والحدود المالية.':`سلمى ترفض استخدام رأس المال: ${rejection}.`],
  ];
  let id:string,text:string,kind:Tone='info';
  if(c.step<messages.length){[id,text]=messages[c.step];if(id==='risk')c.riskApproved=risk.ok&&qualifies;}
  else if(c.step===messages.length){
   c.approved=risk.ok&&qualifies&&c.riskApproved===true;c.reviewedAtTick=s.ticks;id='director';
   text=c.approved?`آدم يعتمد ${c.symbol} بتقييم ${Math.floor(c.confidence*100)}%؛ يامن، أعد فحص الشروط ثم نفّذ تجريبيًا.`:`آدم يرفض ${c.symbol}: ${rejection}. جود، ابحث عن فرصة أخرى.`;
   kind=c.approved?'good':'warn';
  }else{
   id='executor';const executed=!!c.approved&&c.riskApproved===true&&risk.ok&&qualifies&&!s.emergency;
   text=executed?`يامن: أعدت الفحص ونفذت ${c.symbol} تجريبيًا؛ أتابع الهدف والوقف واتجاه السوق.`:`يامن رفض التنفيذ ولم يفتح صفقة؛ ${c.approved?rejection:'لا توجد موافقة صالحة'}. البحث مستمر.`;
   if(executed)openTrade(s,c);
   c.messages.push({agent:id,text,at:Date.now()});agentNote(s,id,text);log(s,text,executed?'good':'warn',s.agents.find(a=>a.id===id)!.role,`جلسة ${c.id} | strategy=${s.strategy} | amount=${c.amount} | score=${c.confidence*100} | rules=${OPPORTUNITY_RULE_VERSION}`);
   finishCouncil(s,c,executed);return s;
  }
  c.messages.push({agent:id,text,at:Date.now()});agentNote(s,id,text);log(s,text,kind,s.agents.find(a=>a.id===id)!.role,`جلسة ${c.id}`);c.step++;
 }
 return s;
}
export function emergencyStop(state:GameState){const s=assignAgentRoles(structuredClone(state));s.emergency=true;s.running=false;if(s.council)log(s,'أُلغي اجتماع المجلس بسبب الطوارئ','warn','النظام',`جلسة ${s.council.id}`);s.council=null;s.open.slice().forEach(t=>closeInPlace(s,t.id,'إيقاف طوارئ'));s.agents.forEach(a=>a.status='متوقف • وضع الحماية');log(s,'إيقاف طوارئ: أُغلقت المراكز التجريبية ومنع فتح صفقات جديدة','bad','مدير المخاطر');achievement(s,'guardian');return s}
export function resume(state:GameState){const s=structuredClone(state);rollover(s);if(!marketFresh(s)){log(s,'انتظر وصول أسعار Binance الحديثة قبل بدء التدريب','warn');return s;}if(dailyLoss(s)>=s.dayStartEquity*s.risk.dailyLossPct/100){log(s,'الحد اليومي يمنع التشغيل. انتظر يومًا جديدًا أو ابدأ مملكة جديدة.','warn');return s}s.emergency=false;s.running=true;s.agents.forEach(a=>a.status='يحلل السوق');log(s,'بدأ تدريب المملكة على أسعار Binance الفعلية بمال افتراضي','good');return s}
export function pause(state:GameState){const s=structuredClone(state);s.running=false;if(s.council)log(s,'أُلغي اجتماع المجلس عند إيقاف الدورة','info','النظام',`جلسة ${s.council.id}`);s.council=null;s.agents.forEach(a=>a.status='استراحة');log(s,'تم إيقاف دورة المملكة مؤقتًا');return s}
export function setStrategy(state:GameState,strategy:Strategy){const s=structuredClone(state);s.strategy=strategy;log(s,`اعتماد استراتيجية ${STRATEGIES[strategy].name} للصفقات الجديدة`,'info','المدير العام');return s}
export function updateRisk(state:GameState,r:GameState['risk']){const s=structuredClone(state);if(![r.dailyLossPct,r.maxTradePct,r.maxExposurePct].every(Number.isFinite)||r.dailyLossPct<1||r.dailyLossPct>20||r.maxTradePct<5||r.maxTradePct>35||r.maxExposurePct<20||r.maxExposurePct>65||r.maxTradePct>r.maxExposurePct){log(s,'إعدادات غير صالحة؛ الحد لكل صفقة 5–35%، التعرض 20–65%، الخسارة 1–20%','warn');return s}s.risk=r;log(s,`تحديث المخاطر: خسارة يومية ${r.dailyLossPct}%، صفقة ${r.maxTradePct}%، تعرض ${r.maxExposurePct}%`,'good','مدير المخاطر');return s}
export function claimTask(state:GameState,id:string){const s=structuredClone(state);rollover(s);const t=s.tasks.find(t=>t.id===id);if(t&&!t.claimed&&t.progress>=t.target){t.claimed=true;s.xp+=t.reward;log(s,`مهمة مكتملة: ${t.title} • +${t.reward} XP`,'good','التقدم');progress(s)}return s}
export function visit(state:GameState,id:string){const s=structuredClone(state);rollover(s);if(!s.visited.includes(id)){s.visited.push(id);s.tasks.find(t=>t.id==='visit')!.progress++;progress(s)}return s}
export function readReport(state:GameState){const s=structuredClone(state);s.reportViews++;return s}
export function clearNotifications(state:GameState){const s=structuredClone(state);s.notifications=[];return s}
