import type { Asset } from './types.ts';

export const MIN_OPPORTUNITY_SCORE = 75;
export const OPPORTUNITY_RULE_VERSION = 'trend-v1';
export type OpportunityEvaluation = {
  symbol: string;
  score: number;
  eligible: boolean;
  rules: { label: string; passed: boolean; weight: number }[];
  reason: string;
};

// This is a rule score on simulated prices, never a calibrated win probability.
export function evaluateOpportunity(asset: Asset): OpportunityEvaluation {
  const empty = { symbol: asset.symbol, score: 0, eligible: false, rules: [], reason: 'بيانات الأسعار غير كافية أو غير صالحة' };
  const prices = asset.history.slice(-35);
  if (prices.length < 20 || prices.some(p => !Number.isFinite(p) || p <= 0) || !Number.isFinite(asset.price) || asset.price <= 0) return empty;
  const values = [...prices, asset.price];
  const mean = (a: number[]) => a.reduce((sum, p) => sum + p, 0) / a.length;
  const short = mean(values.slice(-8)), long = mean(values.slice(-20));
  const returns = values.slice(-12).map((p, i) => (p / values[values.length - 13 + i] - 1));
  const rules = [
    { label: 'اتجاه صاعد: السعر فوق المتوسط القصير، والقصير فوق الطويل', passed: asset.price > short && short > long, weight: 30 },
    { label: 'زخم موجب: السعر أعلى من سعر ست تحديثات سابقة', passed: asset.price / values.at(-7)! - 1 >= .0015, weight: 25 },
    { label: 'تقلب معتدل: متوسط الحركة أقل من 0.6% للتحديث', passed: mean(returns.map(Math.abs)) <= .006, weight: 25 },
    { label: 'دخول غير ممتد: السعر لا يتجاوز المتوسط القصير بأكثر من 1.2%', passed: asset.price / short - 1 <= .012, weight: 20 },
  ];
  const score = rules.reduce((sum, r) => sum + (r.passed ? r.weight : 0), 0);
  const eligible = rules[0].passed && score >= MIN_OPPORTUNITY_SCORE;
  return { symbol: asset.symbol, score, eligible, rules, reason: eligible ? 'مؤهلة لمراجعة المجلس؛ النتيجة غير مضمونة' : !rules[0].passed ? 'اتجاه الشراء غير مؤكد؛ البحث عن أصل آخر' : `تقييم ${score}% أقل من الحد 75%؛ البحث عن أصل آخر` };
}

export function marketReversed(asset: Asset, entry: number): boolean {
  const values = [...asset.history.slice(-20), asset.price];
  if (values.length < 20 || values.some(p => !Number.isFinite(p) || p <= 0)) return false;
  const mean = (a: number[]) => a.reduce((sum, p) => sum + p, 0) / a.length;
  const short = mean(values.slice(-8)), long = mean(values.slice(-20));
  return short < long && asset.price < entry && asset.price < short && values.at(-2)! < short;
}
