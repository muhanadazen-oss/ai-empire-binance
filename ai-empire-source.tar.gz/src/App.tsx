import {trainAcademy} from './engine/academy';
import { lazy, Suspense, useEffect, useRef, useState } from "react";
const RealWallet = lazy(() => import('./integration/EmbeddedWallet'));
const CapitalOverview = lazy(() => import('./integration/CapitalOverview'));
const TradingAcademy = lazy(() => import('./integration/TradingAcademy'));
const ResearchDesk = lazy(() => import('./integration/ResearchDesk'));
const AutomaticTrader = lazy(() => import('./integration/AutomaticTrader'));
import {
  Crown,
  GraduationCap,
  Landmark,
  Activity,
  ShieldCheck,
  Hexagon,
  Wallet,
  TrendingUp,
  Users,
  Target,
  ScrollText,
  Settings2,
  Play,
  Pause,
  ArrowUpLeft,
  ArrowDownLeft,
  ArrowLeft,
  ChevronLeft,
  Check,
  Lock,
  Plus,
  X,
  Bell,
  Radio,
  Layers,
  Power,
  Download,
  RotateCcw,
  Search,
  BarChart3,
  Globe,
  Zap,
  CheckCircle2,
  Clock,
  Coins,
  Flame,
  Building2,
  ExternalLink,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { GameState, Strategy, Agent, Log } from "./engine/types";
import {
  initialState,
  assignAgentRoles,
  applyMarketPrices,
  tick,
  equity,
  levelOf,
  LEVELS,
  STRATEGIES,
  startCouncil,
  closeTrade,
  emergencyStop,
  resume,
  pause,
  setStrategy,
  updateRisk,
  claimTask,
  visit,
  readReport,
  clearNotifications,
  dailyLoss,
  exposure,
} from "./engine/game";
import { loadGame, saveGame, resetDatabase } from "./storage/database";
import { City, BUILDINGS } from "./components/City";
import { Avatar } from "./components/Avatar";
import "./style.css";
import {
  Society,
  SOCIETY_NAV,
  PersonDetails,
  AccountPanel,
  ClockControls,
  CivicSummary,
} from "./civilization/Society";
import { useCivilization } from "./civilization/context";
import { session } from "./storage/cloud";
const money = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
const time = (n: number) =>
  new Date(n).toLocaleTimeString("ar-PS", {
    hour: "2-digit",
    minute: "2-digit",
  });
const signed = (n: number) => `${n >= 0 ? "+" : "−"}${money(Math.abs(n))}`;
const NAV: { id: string; label: string; icon: LucideIcon }[] = [
  { id: "city", label: "المملكة", icon: Crown },
  ...SOCIETY_NAV,
  { id: "agents", label: "مجلس الوكلاء", icon: Users },
  { id: "trades", label: "التداول", icon: TrendingUp },
  { id: "missions", label: "المهام والإنجازات", icon: Target },
  { id: "reports", label: "التقارير", icon: BarChart3 },
  { id: "account", label: "الحساب وتسجيل الدخول", icon: Users },
  { id: "wallet", label: "المحفظة الحقيقية", icon: Wallet },
  { id: "autotrader", label: "التداول الآلي", icon: Activity },
  { id: "academy", label: "مدرسة التداول", icon: GraduationCap },
  { id: "research", label: "بحث التوصيات", icon: Globe },
];
function Spark({
  data,
  color = "#6ad7ba",
  height = 44,
}: {
  data: number[];
  color?: string;
  height?: number;
}) {
  const min = Math.min(...data),
    range = Math.max(...data) - min || 1;
  const points = data
    .map(
      (v, i) =>
        `${(i / (data.length - 1 || 1)) * 250},${height - 5 - ((v - min) / range) * (height - 12)}`,
    )
    .join(" ");
  return (
    <svg
      viewBox={`0 0 250 ${height}`}
      className="spark"
      preserveAspectRatio="none"
      aria-label="رسم بياني للأسعار التجريبية"
    >
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="2"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
function download(name: string, body: string, type = "application/json") {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([body], { type }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function Modal({
  title,
  subtitle,
  onClose,
  children,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement;
    ref.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "Tab") {
        const list = ref.current?.querySelectorAll<HTMLElement>(
          'button:not([disabled]),input,select,a[href],[tabindex="0"]',
        );
        if (!list?.length) {
          e.preventDefault();
          return;
        }
        const first = list[0],
          last = list[list.length - 1];
        if (
          e.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === ref.current)
        ) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", key);
      document.body.style.overflow = "";
      prev?.focus();
    };
  }, []);
  return (
    <div
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={ref}
        tabIndex={-1}
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header className="modal-header">
          <div>
            <span className="eyebrow">AI EMPIRE / SIMULATION</span>
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button className="icon-button" onClick={onClose} aria-label="إغلاق">
            <X size={20} />
          </button>
        </header>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}
function Logs({ logs }: { logs: Log[] }) {
  const [filter, setFilter] = useState("all"),
    [count, setCount] = useState(40);
  const selected = [...logs]
    .reverse()
    .filter((l) => filter === "all" || l.kind === filter);
  return (
    <>
      <div className="toolbar">
        <label>
          نوع النشاط{" "}
          <select
            value={filter}
            onChange={(e) => {
              setFilter(e.target.value);
              setCount(40);
            }}
          >
            <option value="all">كل النشاط</option>
            <option value="good">موافقات وإنجازات</option>
            <option value="warn">مراجعات ورفض</option>
            <option value="bad">تنبيهات حرجة</option>
            <option value="info">تحليل وقرارات</option>
          </select>
        </label>
        <span className="muted">{selected.length} سجل</span>
      </div>
      <div className="logs">
        {selected.slice(0, count).map((l) => (
          <div className={`log-row ${l.kind}`} key={l.id}>
            <span className="log-dot" />
            <div>
              <b>{l.text}</b>
              <p>
                {l.actor} <span>• {time(l.at)}</span>
              </p>
              {l.detail && <small>{l.detail}</small>}
            </div>
          </div>
        ))}
        {selected.length === 0 && (
          <div className="empty">لا يوجد نشاط بهذا النوع بعد.</div>
        )}
      </div>
      {selected.length > count && (
        <button
          className="button subtle"
          onClick={() => setCount((c) => c + 80)}
        >
          تحميل سجلات أقدم
        </button>
      )}
    </>
  );
}
function AgentCard({ agent, onClick }: { agent: Agent; onClick: () => void }) {
  return (
    <button className="agent-card" onClick={onClick}>
      <div className="agent-card-top">
        <Avatar agent={agent} size={58} />
        <span className="tiny-badge">LV {1 + Math.floor(agent.xp / 80)}</span>
      </div>
      <h3>
        {agent.name} <span>{agent.role}</span>
      </h3>
      <p className="agent-skill">{agent.skill}</p>
      <p className="agent-state">
        <span className="live-dot" />
        {agent.status}
      </p>
      <div className="agent-metrics">
        <span>
          القرارات <b>{agent.decisions}</b>
        </span>
        <span>
          نجاح تجريبي{" "}
          <b>
            {agent.resolved
              ? `${Math.round((agent.wins / agent.resolved) * 100)}%`
              : "—"}
          </b>
        </span>
      </div>
      <div className="progress">
        <i
          style={{
            width: `${((agent.xp % 80) / 80) * 100}%`,
            background: agent.color,
          }}
        />
      </div>
      <small>
        {agent.xp} XP <ArrowLeft size={14} />
      </small>
    </button>
  );
}
function Council({
  state,
  onScan,
  compact = false,
}: {
  state: GameState;
  onScan: () => void;
  compact?: boolean;
}) {
  const msgs = state.council?.messages ?? state.lastCouncil;
  return (
    <div className={`council ${compact ? "compact" : ""}`}>
      <div className="panel-heading">
        <div>
          <span className="eyebrow">THE COUNCIL</span>
          <h3>مجلس المملكة</h3>
        </div>
        <span className={`status-badge ${state.council ? "online" : ""}`}>
          {state.council ? "اجتماع جارٍ" : "جاهز"}
        </span>
      </div>
      <p className="muted council-description">
        ثمانية موظفين بمهام محددة. سلمى تراجع المخاطر، وآدم يعتمد القرار.
      </p>
      <div className="council-operators">
        {state.agents.filter(a => a.id === 'executor' || a.id === 'scout').map(a => (
          <div key={a.id}><Avatar agent={a} size={38} /><div><b>{a.name} · {a.role}</b><p>{a.id === 'executor' ? 'فتح بعد الموافقة؛ إغلاق عند الهدف أو الوقف أو انعكاس الاتجاه' : 'فحص جميع الأصول كل 6 دورات؛ إحالة المؤهل إلى آدم'}</p></div></div>
        ))}
      </div>
      <div className="opportunity-policy">
        <b>حد التقييم: 75% فأعلى</b>
        <p>درجة اجتياز قواعد الاتجاه والزخم والتقلب. ليست احتمال نجاح أو ضمان ربح.</p>
        <small>{state.running ? 'البحث ومتابعة الإغلاق يعملان أثناء دورة اللعبة المفتوحة.' : 'شغّل دورة المملكة لبدء البحث ومتابعة الإغلاق.'}</small>
        {state.opportunitySearch && <div className="opportunity-results">{state.opportunitySearch.candidates.map(c => <details key={c.symbol}><summary><b>{c.symbol}</b><span>{c.score}%</span><small>{c.eligible ? 'لمراجعة المجلس' : 'تجاوزها الباحث'}</small></summary><p>{c.reason}</p>{c.rules.map(r => <p key={r.label}>{r.passed ? '✓' : '×'} {r.label} · {r.weight} نقطة</p>)}</details>)}</div>}
      </div>
      <div className="council-messages">
        {msgs.length
          ? msgs.map((m, i) => {
              const a = state.agents.find((a) => a.id === m.agent)!;
              return (
                <div className="council-message" key={`${m.at}-${i}`}>
                  <Avatar agent={a} size={34} />
                  <div>
                    <b>
                      {a.name} <span>{a.role}</span>
                    </b>
                    <p>{m.text}</p>
                  </div>
                </div>
              );
            })
          : state.agents.slice(0, compact ? 4 : 8).map((a) => (
              <div key={a.id} className="council-member">
                <Avatar agent={a} size={39} />
                <div>
                  <b>{a.name}</b>
                  <p>{a.role}</p>
                </div>
                <span className="member-status">جاهز</span>
              </div>
            ))}
      </div>
      {state.council && (
        <div className="thinking">
          <span />
          <span />
          <span /> الوكلاء يناقشون الفرصة
        </div>
      )}
      <button
        className="button outline full"
        disabled={!!state.council || state.emergency}
        onClick={onScan}
      >
        <Radio size={16} />{" "}
        {state.council ? "المجلس يناقش الآن" : "دعوة المجلس لتحليل فرصة"}{" "}
        <ArrowUpLeft size={16} />
      </button>
      <small className="simulation-note">
        وكلاء محاكاة بقواعد مبرمجة • لا يوجد اتصال بنموذج AI خارجي
      </small>
    </div>
  );
}
function RiskForm({
  state,
  onSave,
  onStop,
}: {
  state: GameState;
  onSave: (r: GameState["risk"]) => void;
  onStop: () => void;
}) {
  const [r, setR] = useState(state.risk),
    [saved, setSaved] = useState(false);
  return (
    <>
      <div className="section-note">
        <ShieldCheck />
        يحتفظ النظام دائمًا باحتياطي من رأس المال. تُراجع الحدود مرة أخرى قبل
        التنفيذ.
      </div>
      <div className="risk-grid">
        {(
          [
            {
              key: "dailyLossPct",
              label: "حد الخسارة اليومي",
              min: 1,
              max: 20,
            },
            {
              key: "maxTradePct",
              label: "الحد الأقصى لكل صفقة",
              min: 5,
              max: 35,
            },
            {
              key: "maxExposurePct",
              label: "إجمالي التعرض المسموح",
              min: 20,
              max: 65,
            },
          ] as const
        ).map((f) => (
          <label className="range-field" key={f.key}>
            <span>
              {f.label}
              <b>{r[f.key]}%</b>
            </span>
            <input
              aria-label={f.label}
              type="range"
              min={f.min}
              max={f.max}
              value={r[f.key]}
              onChange={(e) => {
                setR({ ...r, [f.key]: Number(e.target.value) });
                setSaved(false);
              }}
            />
            <small>
              {f.min}% — {f.max}%
            </small>
          </label>
        ))}
      </div>
      <div className="metric-line">
        <span>الخسارة اليومية المحتسبة</span>
        <b className="negative">
          {money(dailyLoss(state))} /{" "}
          {money((state.dayStartEquity * state.risk.dailyLossPct) / 100)}
        </b>
      </div>
      {r.maxTradePct > r.maxExposurePct && (
        <p className="negative">الحد لكل صفقة يجب ألا يتجاوز إجمالي التعرض.</p>
      )}
      <button
        className="button gold"
        disabled={r.maxTradePct > r.maxExposurePct}
        onClick={() => {
          onSave(r);
          setSaved(true);
        }}
      >
        <Check size={17} />
        {saved ? "تم حفظ الحدود" : "حفظ حدود المخاطر"}
      </button>
      <div className="danger-panel">
        <h3>
          <Power size={18} /> إيقاف الطوارئ
        </h3>
        <p>
          يغلق جميع الصفقات التجريبية بالأسعار الحالية، ويلغي الاجتماع ويمنع
          صفقات جديدة حتى إعادة التشغيل.
        </p>
        <button
          className="button danger"
          disabled={state.emergency}
          onClick={onStop}
        >
          {state.emergency ? "وضع الحماية مفعل" : "تفعيل إيقاف الطوارئ"}
        </button>
      </div>
    </>
  );
}
function Trades({
  state,
  onClose,
  onScan,
  onStrategy,
}: {
  state: GameState;
  onClose: (id: string) => void;
  onScan: (symbol: string, amount: number) => void;
  onStrategy: (s: Strategy) => void;
}) {
  const [symbol, setSymbol] = useState("BTC"),
    [amount, setAmount] = useState("5");
  return (
    <>
      <div className="strategies">
        {Object.entries(STRATEGIES).map(([key, v]) => (
          <button
            className={`strategy ${state.strategy === key ? "selected" : ""}`}
            key={key}
            onClick={() => onStrategy(key as Strategy)}
          >
            <span>
              {key === "conservative" ? (
                <ShieldCheck size={19} />
              ) : key === "balanced" ? (
                <Layers size={19} />
              ) : (
                <Flame size={19} />
              )}{" "}
              {v.name}
              {state.strategy === key && <Check size={16} />}
            </span>
            <p>{v.description}</p>
          </button>
        ))}
      </div>
      <div className="proposal">
        <div>
          <h3>اقترح فرصة على المجلس</h3>
          <p>يستطيع مدير المخاطر رفض اقتراحك. التنفيذ بعد موافقة المدير فقط.</p>
        </div>
        <div className="proposal-form">
          <select
            aria-label="الأصل"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
          >
            {state.assets.map((a) => (
              <option key={a.symbol}>{a.symbol}</option>
            ))}
          </select>
          <label>
            <span className="sr-only">قيمة الصفقة</span>
            <input
              type="number"
              min="0.5"
              max="40"
              step="0.5"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="قيمة بالدولار"
            />{" "}
            $
          </label>
          <button
            className="button gold"
            disabled={
              !!state.council ||
              state.emergency ||
              !Number.isFinite(Number(amount)) ||
              Number(amount) < 0.5
            }
            onClick={() => onScan(symbol, Number(amount))}
          >
            <Search size={16} /> دراسة الفرصة
          </button>
        </div>
      </div>
      <div className="panel-heading">
        <h3>
          الصفقات المفتوحة <span className="counter">{state.open.length}</span>
        </h3>
        <span className="muted">محاكاة • شراء فوري تجريبي</span>
      </div>
      {state.open.length ? (
        <div className="trade-list">
          {state.open.map((t) => {
            const current = state.assets.find(
                (a) => a.symbol === t.symbol,
              )!.price,
              pnl = t.quantity * current - t.amount;
            return (
              <div className="trade-row" key={t.id}>
                <div className="coin-icon">{t.symbol[0]}</div>
                <div>
                  <b>{t.symbol}</b>
                  <small>
                    {money(t.amount)} • {STRATEGIES[t.strategy].name}
                  </small>
                </div>
                <div>
                  <b className={pnl >= 0 ? "positive" : "negative"}>
                    {signed(pnl)}
                  </b>
                  <small>غير محقق، قبل الرسوم</small>
                </div>
                <div>
                  <small>هدف {money(t.takeProfit)}</small>
                  <small>وقف {money(t.stopLoss)}</small>
                  <small>متابعة يامن {t.opportunityScore !== undefined && `· تقييم ${Math.floor(t.opportunityScore)}%`}</small>
                </div>
                <button className="button subtle" onClick={() => onClose(t.id)}>
                  إغلاق الصفقة
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="empty">
          <TrendingUp size={26} />
          <p>لا توجد صفقات مفتوحة. ابدأ الدورة أو اقترح فرصة على المجلس.</p>
        </div>
      )}
      <h3>
        الصفقات المغلقة <span className="counter">{state.closed.length}</span>
      </h3>
      <div className="trade-list">
        {[...state.closed].reverse().map((t) => (
          <div className="trade-row closed" key={t.id}>
            <div className="coin-icon">{t.symbol[0]}</div>
            <div>
              <b>{t.symbol}</b>
              <small>{time(t.closedAt!)}</small>
            </div>
            <div>
              <b className={(t.pnl ?? 0) >= 0 ? "positive" : "negative"}>
                {signed(t.pnl ?? 0)}
              </b>
              <small>صافي بعد رسوم المحاكاة</small>
            </div>
            <small>{t.reason}</small>
          </div>
        ))}
      </div>
      {!state.closed.length && <p className="muted">سيظهر سجل الإغلاق هنا.</p>}
    </>
  );
}
function Missions({
  state,
  onClaim,
}: {
  state: GameState;
  onClaim: (id: string) => void;
}) {
  const level = levelOf(state);
  return (
    <>
      <div className="level-track">
        {LEVELS.map((l, i) => (
          <div key={l.name} className={i <= level ? "unlocked" : ""}>
            <span>{i <= level ? <Crown size={19} /> : <Lock size={17} />}</span>
            <b>{l.name}</b>
            <small>{l.xp} XP</small>
          </div>
        ))}
      </div>
      <h3>
        مهام اليوم <span className="muted small">تُجدد بتوقيت فلسطين</span>
      </h3>
      <div className="task-grid">
        {state.tasks.map((t, i) => (
          <div className="task-card" key={t.id}>
            <span className="task-icon">
              {i === 0 ? <Radio /> : i === 1 ? <TrendingUp /> : <Building2 />}
            </span>
            <small className="reward">+{t.reward} XP</small>
            <h3>{t.title}</h3>
            <div className="progress">
              <i
                style={{
                  width: `${Math.min(100, (t.progress / t.target) * 100)}%`,
                }}
              />
            </div>
            <div className="task-bottom">
              <span>
                {Math.min(t.progress, t.target)} / {t.target}
              </span>
              <button
                className="button subtle"
                disabled={t.claimed || t.progress < t.target}
                onClick={() => onClaim(t.id)}
              >
                {t.claimed ? (
                  <>
                    <Check size={15} /> استُلمت
                  </>
                ) : t.progress >= t.target ? (
                  "استلام المكافأة"
                ) : (
                  "قيد الإنجاز"
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
      <h3>إنجازات المملكة</h3>
      <div className="achievements">
        {state.achievements.map((a) => (
          <div
            className={`achievement ${a.unlocked ? "unlocked" : ""}`}
            key={a.id}
          >
            <span>{a.unlocked ? <Hexagon /> : <Lock />}</span>
            <div>
              <b>{a.title}</b>
              <p>{a.description}</p>
            </div>
            <small>
              {a.unlocked ? <CheckCircle2 size={20} /> : <>{a.reward} XP</>}
            </small>
          </div>
        ))}
      </div>
      <div className="residents">
        <h3>شخصيات جديدة في المملكة</h3>
        {[
          {
            name: "سامر • أمين الأرشيف",
            level: 1,
            text: "إدارة سجلات القرارات وتصديرها من مركز العمليات.",
          },
          {
            name: "هالة • مهندسة المدينة",
            level: 2,
            text: "مباني إضافية وقدرة تنويع الاقتصاد ومهام المدينة.",
          },
          {
            name: "يوسف • قائد الحماية",
            level: 3,
            text: "مهام اختبار رفض الصفقات ومراقبة المخاطر.",
          },
        ].map((r) => (
          <div className={level >= r.level ? "unlocked" : ""} key={r.name}>
            <span>
              {level >= r.level ? <Users size={20} /> : <Lock size={20} />}
            </span>
            <div>
              <b>{r.name}</b>
              <p>{r.text}</p>
            </div>
            <small>
              {level >= r.level ? "متاح" : `المستوى ${r.level + 1}`}
            </small>
          </div>
        ))}
      </div>
      <div className="section-note">
        <Zap />
        البلدة تفتح الاستشارة الموسعة؛ المدينة تفتح مهمة التنويع، العاصمة تفتح
        مهمة رفض الصفقات، والإمبراطورية تفتح مهمة المجلس الكامل. كل ترقية تضيف
        أبراجًا وارتفاعًا للمباني.
      </div>
    </>
  );
}
function Reports({ state }: { state: GameState }) {
  const wins = state.closed.filter((t) => (t.pnl ?? 0) > 0).length;
  const exportCsv = () => {
    const rows = [
      ["id", "symbol", "amount_sim_USD", "pnl_sim_USD", "reason", "closed_at"],
      ...state.closed.map((t) => [
        t.id,
        t.symbol,
        t.amount,
        t.pnl,
        t.reason,
        new Date(t.closedAt!).toISOString(),
      ]),
    ];
    download(
      "ai-empire-simulation-report.csv",
      "\uFEFF" +
        rows
          .map((r) =>
            r
              .map((v) => '"' + String(v ?? "").replaceAll('"', '""') + '"')
              .join(","),
          )
          .join("\n"),
      "text/csv;charset=utf-8",
    );
  };
  return (
    <>
      <div className="section-note">
        <BarChart3 />
        تقرير تجريبي فقط. لا يمثل ربحًا حقيقيًا أو توقعًا لأداء الأسواق.
      </div>
      <div className="report-grid">
        <div>
          <span>صافي قيمة المملكة</span>
          <b>{money(equity(state))}</b>
        </div>
        <div>
          <span>الربح / الخسارة</span>
          <b className={equity(state) >= 40 ? "positive" : "negative"}>
            {signed(equity(state) - state.capital)}
          </b>
        </div>
        <div>
          <span>معدل نجاح الصفقات المغلقة</span>
          <b>
            {state.closed.length
              ? `${Math.round((wins / state.closed.length) * 100)}%`
              : "—"}
          </b>
        </div>
        <div>
          <span>قرارات المجلس</span>
          <b>
            {state.decisions} <small>منها {state.rejected} مرفوضة</small>
          </b>
        </div>
      </div>
      <div className="chart-panel">
        <div className="panel-heading">
          <h3>قيمة المملكة مع الزمن</h3>
          <span className="tiny-badge">SIM USD</span>
        </div>
        <Spark data={state.equityHistory} height={180} color="#dbb86d" />
        <div className="chart-labels">
          <span>الآن {money(equity(state))}</span>
          <span>نقطة البداية {money(state.capital)}</span>
        </div>
      </div>
      <h3>أداء الوكلاء</h3>
      <div className="performance-table">
        {state.agents.map((a) => (
          <div key={a.id}>
            <Avatar agent={a} size={35} />
            <b>
              {a.name}
              <small>{a.role}</small>
            </b>
            <span>{a.decisions} قرار</span>
            <span>{a.xp} XP</span>
            <span className="positive">
              {a.resolved
                ? `${Math.round((a.wins / a.resolved) * 100)}% نجاح`
                : "لا صفقات مكتملة"}
            </span>
          </div>
        ))}
      </div>
      <p className="muted small">
        نسبة النجاح محسوبة من نتائج الصفقات التي راقبها الفريق؛ لا تثبت مساهمة
        سببية لكل وكيل. آخر 500 نقطة متاحة في الرسم، وسجل القرارات محفوظ كاملًا.
      </p>
      <div className="toolbar">
        <button className="button gold" onClick={exportCsv}>
          <Download size={17} /> تصدير تقرير CSV
        </button>
        <button
          className="button outline"
          onClick={() =>
            download(
              "ai-empire-audit.json",
              JSON.stringify({ mode: "simulation", logs: state.logs }, null, 2),
            )
          }
        >
          <ScrollText size={17} /> تصدير Audit Log
        </button>
      </div>
    </>
  );
}
export default function App() {
  const { civic } = useCivilization();
  const [selectedPerson, setSelectedPerson] = useState<string | null>(null);
  const openPerson = (id: string) => {
    setSelectedPerson(id);
    setModal("person");
  };
  const [state, setState] = useState<GameState | null>(null),
    [view, setView] = useState(() => location.hash === "#binance" ? "wallet" : NAV.some(n => n.id === location.hash.slice(1)) ? location.hash.slice(1) : "autotrader"),
    [modal, setModal] = useState<string | null>(null),
    [selectedAgent, setSelectedAgent] = useState<string | null>(null),
    [storageStatus, setStorageStatus] = useState("جاري التحميل"),
    [blocked, setBlocked] = useState(false),
    [error, setError] = useState("");
  const releaseLock = useRef<(() => void) | null>(null),
    stateRef = useRef<GameState | null>(null);
  useEffect(() => {
    let alive = true;
    async function init() {
      try {
        const open = async () => {
          const loaded = await loadGame();
          if (alive) {
            setState(assignAgentRoles(loaded ?? initialState()));
            setStorageStatus("محفوظ على السيرفر");
          }
        };
        if (navigator.locks) {
          navigator.locks
            .request(
              "ai-empire-personal-writer",
              { ifAvailable: true },
              async (lock) => {
                if (!lock) {
                  if (alive) setBlocked(true);
                  return;
                }
                await open();
                await new Promise<void>((r) => {
                  releaseLock.current = r;
                  if (!alive) r();
                });
              },
            )
            .catch((e) => setError(String(e)));
        } else await open();
      } catch (e) {
        setError("تعذر الاتصال بحفظ المملكة. أعد المحاولة. " + String(e));
      }
    }
    init();
    return () => {
      alive = false;
      releaseLock.current?.();
    };
  }, []);
  useEffect(() => {
    stateRef.current = state;
    if (!state) return;
    setStorageStatus("جاري الحفظ");
    saveGame(state)
      .then(() => setStorageStatus("محفوظ على السيرفر"))
      .catch(() => {
        setStorageStatus("تعذر الحفظ");
        setError(
          "تعذر حفظ تداول المحاكاة على السيرفر. أعد التحميل لاسترجاع آخر تقدم محفوظ.",
        );
      });
  }, [state]);
  useEffect(() => {
    const id = setInterval(() => setState((s) => (s ? tick(s) : s)), 1000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    let alive=true,pending=false;
    async function prices(){if(pending)return;pending=true;try{const r=await fetch('/api/autotrader/market',{credentials:'same-origin'}),v=await r.json();if(r.ok&&alive)setState(s=>s?applyMarketPrices(s,v.prices,v.observedAt):s);}catch{/* keep the last observed price; stale data stops the engine */}finally{pending=false;}}
    void prices();const id=setInterval(prices,15000);return()=>{alive=false;clearInterval(id);};
  }, []);
  useEffect(() => {
    const hashView = () => { const id = location.hash === '#binance' ? 'wallet' : location.hash.slice(1); if (NAV.some(n => n.id === id)) setView(id); };
    window.addEventListener('hashchange', hashView);
    return () => window.removeEventListener('hashchange', hashView);
  }, []);
  useEffect(() => {
    const handle = () => {
      if (document.hidden) setState((s) => (s?.running ? pause(s) : s));
    };
    document.addEventListener("visibilitychange", handle);
    return () => document.removeEventListener("visibilitychange", handle);
  }, []);
  const change = (fn: (s: GameState) => GameState) =>
    setState((s) => (s ? fn(s) : s));
  const openBuilding = (id: string) => {
    change((s) => visit(s, id));
    setModal(id);
  };
  const navigate = (id: string) => {
    history.replaceState(null, "", ["account", "wallet", "research", "academy", "autotrader"].includes(id) ? "#" + id : location.pathname + location.search);
    setView(id);
    if (id === "reports") change(readReport);
  };
  const restart = async () => {
    if (
      !confirm(
        "هذا يعيد محفظة التداول التجريبية فقط إلى 40$، ويحتفظ بالسكان والعائلات. صدّر نسخة من الخزنة أولًا إذا أردت الاحتفاظ بها. هل تريد المتابعة؟",
      )
    )
      return;
    await resetDatabase();
    setState(initialState());
    setModal(null);
    setView("city");
  };
  if (blocked)
    return (
      <div className="loading">
        <Crown size={45} />
        <h2>المملكة مفتوحة في نافذة أخرى</h2>
        <p>أغلقها هناك وأعد تحميل هذه الصفحة لحماية سجل المحاكاة من التعارض.</p>
        <button className="button gold" onClick={() => location.reload()}>
          إعادة التحميل
        </button>
      </div>
    );
  if (!state)
    return (
      <div className="loading">
        <Crown size={45} />
        <h2>AI EMPIRE</h2>
        <p>{error || "تجهيز مملكتك الاقتصادية…"}</p>
        {error && (
          <button className="button outline" onClick={() => location.reload()}>
            إعادة المحاولة
          </button>
        )}
      </div>
    );
  if (!session?.user.email)
    return (
      <main className="login-entry" dir="rtl">
        <section className="login-card" aria-label="تسجيل الدخول إلى المملكة">
          <div className="login-brand"><Crown size={38} /><span>AI EMPIRE</span></div>
          <h1>أهلًا بك في المملكة</h1>
          <p className="login-intro">سجّل دخولك أو أنشئ حسابًا لحفظ مملكتك ومحفظتك.</p>
          <AccountPanel onLinked={() => navigate("city")} returnTo={location.hash === "#wallet" ? "wallet" : "city"} />
        </section>
      </main>
    );
  const level = levelOf(state),
    next = LEVELS[level + 1],
    xpProgress = next
      ? ((state.xp - LEVELS[level].xp) / (next.xp - LEVELS[level].xp)) * 100
      : 100,
    eq = equity(state),
    pnl = eq - state.capital;
  const onScan = () => change((s) => startCouncil(s));
  const title =
    BUILDINGS.find((b) => b.id === modal)?.name ??
    {
      person:
        civic?.people.find((p) => p.id === selectedPerson)?.name ??
        "حياة الشخصية",
      account: "حساب المؤسس والحفظ",
      notifications: "إشعارات المملكة",
      settings: "إعدادات المملكة",
      help: "دليل البداية",
      council: "مجلس المملكة",
    }[modal ?? ""] ??
    "تفاصيل الوكيل";
  const subtitle = BUILDINGS.find((b) => b.id === modal)?.sub;
  const metrics = (
    <div className="metrics">
      <div className="metric primary">
        <span>
          <Wallet size={16} /> محفظة التداول التجريبية
        </span>
        <b dir="ltr">
          {money(eq)} <small>USD</small>
        </b>
        <div className="metric-footer">
          <span>من رأس مال {money(state.capital)}</span>
          <span className="sim-pill">SIM</span>
        </div>
      </div>
      <div className="metric">
        <span>
          <TrendingUp size={16} /> الربح والخسارة
        </span>
        <b dir="ltr" className={pnl >= 0 ? "positive" : "negative"}>
          {signed(pnl)}
        </b>
        <div className="metric-footer">
          <span>يشمل المراكز المفتوحة والرسوم</span>
          <span className={pnl >= 0 ? "positive" : "negative"}>
            {((pnl / state.capital) * 100).toFixed(2)}%
          </span>
        </div>
      </div>
      <div className="metric">
        <span>
          <Activity size={16} /> الصفقات النشطة
        </span>
        <b>
          {String(state.open.length).padStart(2, "0")} <small>صفقات</small>
        </b>
        <div className="metric-footer">
          <span>{state.closed.length} صفقات مغلقة</span>
          <button className="text-button" onClick={() => navigate("trades")}>
            إدارة <ArrowLeft size={12} />
          </button>
        </div>
      </div>
      <div className="metric">
        <span>
          <ShieldCheck size={16} /> حالة الحماية
        </span>
        <b className={state.emergency ? "negative" : "positive"}>
          {state.emergency ? "إيقاف طوارئ" : "المخاطر مراقَبة"}
        </b>
        <div className="metric-footer">
          <span>حد يومي {state.risk.dailyLossPct}%</span>
          <button className="text-button" onClick={() => setModal("risk")}>
            الحدود <ArrowLeft size={12} />
          </button>
        </div>
      </div>
    </div>
  );
  let body: React.ReactNode;
  if (view === "city")
    body = (
      <>
        <div className="welcome">
          <div>
            <span className="eyebrow">YOUR EMPIRE STARTS HERE</span>
            <h1>
              هنا تُبنى <em>الإمبراطوريات.</em>
            </h1>
            <p>أنت المؤسس. هنا يعيش السكان، تتكوّن الأسر، ويصنع كل جيل إرثه.</p>
          </div>
          <button
            className="button gold"
            onClick={() => change(state.running ? pause : resume)}
          >
            <span>
              {state.running ? <Pause size={17} /> : <Play size={17} />}
            </span>
            {state.running
              ? "إيقاف تداول المحاكاة"
              : state.emergency
                ? "استئناف بعد الطوارئ"
                : "تشغيل تداول المحاكاة"}
            <ArrowUpLeft size={16} />
          </button>
        </div>
        <ClockControls />
        <CivicSummary onNavigate={navigate} />
<Suspense fallback={<p>جاري فحص رأس المال…</p>}><CapitalOverview /></Suspense>
        <details className="content-panel"><summary>حسابات التدريب الافتراضية · لا تخصم من المحفظة</summary>{metrics}</details>
        <div className="game-layout">
          <section className="world-panel">
            <header className="world-heading">
              <div>
                <span className="eyebrow">LIVE ECONOMIC WORLD</span>
                <h3>
                  مملكتك الاقتصادية{" "}
                  <span className="tiny-badge">
                    {LEVELS[level].name} • LV {level + 1}
                  </span>
                </h3>
              </div>
              <div className="world-tools">
                <span
                  className={`world-status ${civic?.clock.running ? "active" : ""}`}
                >
                  <span className="live-dot" />
                  {civic?.clock.running ? "المجتمع يعمل" : "المجتمع متوقف"}
                </span>
                <button
                  className="icon-button"
                  aria-label="دليل المدينة"
                  onClick={() => setModal("help")}
                >
                  <Layers size={17} />
                </button>
              </div>
            </header>
            <City
              state={state}
              civic={civic}
              onPerson={openPerson}
              onService={navigate}
              onBuilding={openBuilding}
            />
            <div className="mobile-buildings">
              {BUILDINGS.map((b) => (
                <button
                  key={b.id}
                  aria-label={`فتح ${b.name}`}
                  onClick={() => openBuilding(b.id)}
                >
                  <span style={{ background: b.color }} />
                  {b.name}
                  <ArrowUpLeft size={12} />
                </button>
              ))}
            </div>
            <footer className="world-footer">
              <span>
                <Globe size={15} />
                {state.event}
              </span>
              <span>
                <Clock size={14} /> {state.ticks} دورة زمنية
              </span>
            </footer>
          </section>
          <aside className="council-panel">
            <Council state={state} onScan={onScan} compact />
          </aside>
        </div>
        <div className="bottom-layout">
          <section className="missions-preview">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">DAILY QUESTS</span>
                <h3>خطوات صغيرة. إمبراطورية كبيرة.</h3>
              </div>
              <button
                className="text-button"
                onClick={() => navigate("missions")}
              >
                كل المهام <ArrowLeft size={15} />
              </button>
            </div>
            <div className="mini-tasks">
              {state.tasks.map((t) => (
                <button
                  key={t.id}
                  className={t.claimed ? "done" : ""}
                  onClick={() => navigate("missions")}
                >
                  <span className="mini-task-icon">
                    {t.claimed ? <Check size={18} /> : <Target size={18} />}
                  </span>
                  <div>
                    <b>{t.title}</b>
                    <div className="progress">
                      <i
                        style={{
                          width: `${Math.min(100, (t.progress / t.target) * 100)}%`,
                        }}
                      />
                    </div>
                    <small>
                      {Math.min(t.progress, t.target)} / {t.target}
                    </small>
                  </div>
                  <span className="reward">+{t.reward} XP</span>
                </button>
              ))}
            </div>
          </section>
          <section className="activity-preview">
            <div className="panel-heading">
              <h3>
                <Activity size={17} /> نبض المملكة
              </h3>
              <button
                className="text-button"
                onClick={() => setModal("operations")}
              >
                السجل <ArrowLeft size={13} />
              </button>
            </div>
            {state.logs
              .slice(-3)
              .reverse()
              .map((l) => (
                <div className={`mini-log ${l.kind}`} key={l.id}>
                  <span className="log-dot" />
                  <p>{l.text}</p>
                  <small>{time(l.at)}</small>
                </div>
              ))}
          </section>
        </div>
      </>
    );
  else if (view === "wallet")
    body = <Suspense fallback={<p role="status">جاري فتح المحفظة…</p>}><RealWallet game={state} /></Suspense>;
  else if (view === "academy")
    body = <Suspense fallback={<p>جاري فتح المدرسة…</p>}><TradingAcademy game={state} onTrain={(id) => change(s => trainAcademy(s,id))} /></Suspense>;
  else if (view === "research")
    body = <Suspense fallback={<p role="status">جاري فتح مكتب البحث…</p>}><ResearchDesk /></Suspense>;
  else if (view === "autotrader")
    body = <Suspense fallback={<p role="status">جاري فتح التداول الآلي…</p>}><AutomaticTrader /></Suspense>;
  else if (view === "account")
    body = <section className="founder-account"><span className="tiny-badge">حساب المملكة</span><h1>{session?.user.email ? "حساب المؤسس" : "تسجيل الدخول إلى مملكتك"}</h1><AccountPanel onLinked={() => navigate("wallet")} /></section>;
  else if (SOCIETY_NAV.some((n) => n.id === view))
    body = <Society view={view} onPerson={openPerson} />;
  else
    body = (
      <>
        <div className="page-heading">
          <span className="eyebrow">AI EMPIRE / {view.toUpperCase()}</span>
          <h1>{NAV.find((n) => n.id === view)?.label}</h1>
          <p>
            {view === "agents"
              ? "فريقك الاقتصادي، لكل وكيل تخصص وسجل قرارات قابل للمراجعة."
              : view === "trades"
                ? "فرص تجريبية يراجعها المجلس قبل التنفيذ."
                : view === "missions"
                  ? "طوّر المدينة بالخبرة والقرارات والاستكشاف."
                  : view === "reports"
                    ? "كل قرار مسجل. كل نتيجة قابلة للمراجعة."
                    : "تابع حسابك ومحفظتك من الشريط."}
          </p>
        </div>
        {view === "agents" ? (
          <>
            <section className="agent-workflow" aria-label="مهام الموظفين"><b>مسار العمل ومسؤولية كل موظف</b><p>جود يكشف الفرص ويرسلها لآدم. رؤى تجمع التوصيات، ونور يحلل، ورائد يعد خطة. سلمى وحدها تعتمد رأس المال والمخاطر، وآدم يوافق، ثم يامن يفتح ويتابع الإغلاق. ليث يراقب وينبه يامن.</p><small>حد التقييم 75% فأعلى لجميع الاستراتيجيات. هذه صفقات محاكاة؛ لا تُنفذ صفقات حقيقية من المحفظة.</small></section>
            <div className="agent-grid">
              {state.agents.map((a) => (
                <AgentCard
                  agent={a}
                  key={a.id}
                  onClick={() => {
                    setSelectedAgent(a.id);
                    setModal("agent");
                  }}
                />
              ))}
            </div>
            <div className="wide-council">
              <Council state={state} onScan={onScan} />
            </div>
          </>
        ) : view === "trades" ? (
          <section className="content-panel">
            <Trades
              state={state}
              onClose={(id) => change((s) => closeTrade(s, id))}
              onScan={(symbol, amount) =>
                change((s) => startCouncil(s, symbol, amount))
              }
              onStrategy={(v) => change((s) => setStrategy(s, v))}
            />
            <Council state={state} onScan={onScan} />
          </section>
        ) : view === "missions" ? (
          <section className="content-panel">
            <Missions
              state={state}
              onClaim={(id) => change((s) => claimTask(s, id))}
            />
          </section>
        ) : view === "reports" ? (
          <section className="content-panel">
            <Reports state={state} />
          </section>
        ) : (
          <section className="content-panel">
            <button onClick={() => navigate("wallet")}>افتح المحفظة</button>
          </section>
        )}
      </>
    );
  const modalContent = () => {
    if (modal === "person" && selectedPerson)
      return <PersonDetails personId={selectedPerson} onPerson={openPerson} />;
    if (modal === "account") return <AccountPanel />;
    if (modal === "palace" || modal === "council")
      return (
        <>
          <div className="palace-summary">
            <Crown />
            <div>
              <h3>مملكة مهند • {LEVELS[level].name}</h3>
              <p>
                المستوى {level + 1} • {state.xp} XP • {state.decisions} قرار
                مجلس
              </p>
            </div>
          </div>
          <Council state={state} onScan={onScan} />
        </>
      );
    if (modal === "bank")
      return (
        <>
          <div className="section-note">
            <Landmark />
            كل الأرصدة دولارات تجريبية. لا إيداع أو سحب حقيقي في هذه النسخة.
          </div>
          <div className="report-grid">
            <div>
              <span>رأس المال</span>
              <b>{money(state.capital)}</b>
            </div>
            <div>
              <span>الرصيد النقدي المتاح</span>
              <b>{money(state.cash)}</b>
            </div>
            <div>
              <span>قيمة المراكز المفتوحة</span>
              <b>{money(exposure(state))}</b>
            </div>
            <div>
              <span>القيمة الكلية</span>
              <b>{money(eq)}</b>
            </div>
          </div>
          <Spark data={state.equityHistory} color="#dbb86d" height={140} />
          <div className="metric-line">
            <span>صافي الربح والخسارة</span>
            <b className={pnl >= 0 ? "positive" : "negative"}>{signed(pnl)}</b>
          </div>
        </>
      );
    if (modal === "trading")
      return (
        <Trades
          state={state}
          onClose={(id) => change((s) => closeTrade(s, id))}
          onScan={(symbol, amount) =>
            change((s) => startCouncil(s, symbol, amount))
          }
          onStrategy={(v) => change((s) => setStrategy(s, v))}
        />
      );
    if (modal === "analysis")
      return (
        <>
          <div className="section-note">
            <Search />
            الأسعار والثقة والفرص مولدة بمحرك محاكاة محلي. تحدث الأسعار كل ثلاث
            دورات عند التشغيل.
          </div>
          <Market />
          <Council state={state} onScan={onScan} />
        </>
      );
    if (modal === "risk")
      return (
        <RiskForm
          state={state}
          onSave={(r) => change((s) => updateRisk(s, r))}
          onStop={() => change(emergencyStop)}
        />
      );
    if (modal === "vault")
      return (
        <>
          <div className="section-note">
            <Lock />
            يُحفظ تقدم المملكة تلقائيًا في هذا المتصفح. الانتقال إلى جهاز آخر
            يحتاج ميزة مزامنة مستقبلية.
          </div>
          <div className="report-grid">
            <div>
              <span>رصيد نقدي تجريبي</span>
              <b>{money(state.cash)}</b>
            </div>
            <div>
              <span>الخبرة المكتسبة</span>
              <b>{state.xp} XP</b>
            </div>
          </div>
          <h3>نسخة أرشيفية من مملكتك</h3>
          <p className="muted">
            تشمل البيانات التجريبية والقرارات والتقارير. التصدير للأرشفة،
            والاستيراد غير متاح في هذه المرحلة.
          </p>
          <button
            className="button gold"
            onClick={() =>
              download(
                "ai-empire-kingdom.json",
                JSON.stringify(
                  {
                    ...state,
                    mode: "simulation",
                    running: false,
                    council: null,
                  },
                  null,
                  2,
                ),
              )
            }
          >
            <Download size={17} /> تصدير المملكة JSON
          </button>
          <div className="danger-panel">
            <h3>مملكة جديدة</h3>
            <p>يمسح سجل هذه المملكة ويبدأ بمحفظة تجريبية جديدة بقيمة 40$.</p>
            <button className="button danger" onClick={restart}>
              <RotateCcw size={16} /> بدء مملكة جديدة
            </button>
          </div>
        </>
      );
    if (modal === "market")
      return (
        <>
          <Market />
          <div className="section-note">
            <Activity />
            الأسعار من Binance عبر الخادم. تتوقف أوامر التدريب عند انقطاع البيانات. {state.event}
          </div>
        </>
      );
    if (modal === "operations")
      return (
        <>
          <div className="toolbar">
            <button
              className="button outline"
              onClick={() => {
                setModal(null);
                navigate("reports");
              }}
            >
              <BarChart3 size={17} /> شاشة التقارير
            </button>
            <button
              className="button outline"
              onClick={() =>
                download(
                  "ai-empire-audit.json",
                  JSON.stringify(state.logs, null, 2),
                )
              }
            >
              <Download size={17} /> تصدير السجل الكامل
            </button>
          </div>
          <Logs logs={state.logs} />
        </>
      );
    if (modal === "agent") {
      const a = state.agents.find((a) => a.id === selectedAgent)!;
      return (
        <>
          <div className="agent-profile">
            <Avatar agent={a} size={96} />
            <div>
              <h2>
                {a.name} • {a.role}
              </h2>
              <p>{a.skill}</p>
              <span className="tiny-badge">
                المستوى {1 + Math.floor(a.xp / 80)} • {a.xp} XP
              </span>
            </div>
          </div>
          <div className="report-grid">
            <div>
              <span>القرارات</span>
              <b>{a.decisions}</b>
            </div>
            <div>
              <span>نسبة النجاح التجريبية</span>
              <b>
                {a.resolved
                  ? `${Math.round((a.wins / a.resolved) * 100)}%`
                  : "—"}
              </b>
            </div>
          </div>
          <p className="muted">{a.status}</p>
          <h3>سجل قرارات {a.name}</h3>
          {a.history.length ? (
            a.history.map((h, i) => (
              <div className="decision-history" key={i}>
                {h}
              </div>
            ))
          ) : (
            <p className="empty">لم يصدر قرارات بعد. ابدأ اجتماعًا للمجلس.</p>
          )}
          <p className="muted small">
            آخر 200 قرار لهذا الوكيل؛ سجل المملكة الكامل متاح في مركز العمليات.
          </p>
        </>
      );
    }
    if (modal === "notifications")
      return (
        <>
          <div className="toolbar">
            <span>{state.notifications.length} إشعار</span>
            <button
              className="button subtle"
              disabled={!state.notifications.length}
              onClick={() => change(clearNotifications)}
            >
              <Check size={16} /> تعيين الكل كمقروء
            </button>
          </div>
          <Logs logs={state.notifications} />
        </>
      );
    if (modal === "settings")
      return (
        <>
          <h3>حالة النسخة</h3>
          <div className="metric-line">
            <span>الوضع</span>
            <b>محاكاة شخصية • v1.0</b>
          </div>
          <div className="metric-line">
            <span>الحفظ</span>
            <b>{storageStatus}</b>
          </div>
          <div className="metric-line">
            <span>المحاكاة</span>
            <b>{state.running ? "تعمل" : "متوقفة"}</b>
          </div>
          <p className="muted">
            تتوقف الدورة عند مغادرة التبويب، وتستأنف يدويًا عند العودة. قاعدة
            البيانات محفوظة خادميًا لكل حساب. اربط جلسة الضيف ببريد من زر
            الحساب. لا يوجد أي مفتاح API في اللعبة.
          </p>
          <RiskForm
            state={state}
            onSave={(r) => change((s) => updateRisk(s, r))}
            onStop={() => change(emergencyStop)}
          />
        </>
      );
    return (
      <div className="help-steps">
        <div>
          <span>01</span>
          <h3>استكشف مملكتك</h3>
          <p>
            اضغط على المباني الثمانية لتفتح أقسام المملكة وتنجز مهمة الاستكشاف.
          </p>
        </div>
        <div>
          <span>02</span>
          <h3>ابدأ الدورة أو ادعُ المجلس</h3>
          <p>
            التدريب يستخدم أسعار Binance المرصودة، ويتوقف إذا أصبحت قديمة. يبحث المجلس عن فرص كل 20 دورة تدريبية؛ محرك الإثبات الخادمي منفصل عنه.
            يمكنك دراسة فرصة يدويًا أيضًا.
          </p>
        </div>
        <div>
          <span>03</span>
          <h3>راقب، أنجز، وتطور</h3>
          <p>
            كل قرار وصفقة يمنحان خبرة. استلم مكافآت المهام لرفع مستوى المدينة.
            القرارات قد ترفض والصفقات قد تخسر.
          </p>
        </div>
        <button
          className="button gold"
          onClick={() => {
            setModal(null);
            change(resume);
          }}
        >
          <Play size={17} /> ابدأ مملكتي
        </button>
      </div>
    );
  };
  function Market() {
    return (
      <div className="market-list">
        {state!.assets.map((a) => (
          <div className="market-card" key={a.symbol}>
            <div className="panel-heading">
              <div className="coin-name">
                <span className="coin-icon">{a.symbol[0]}</span>
                <div>
                  <b>{a.symbol}</b>
                  <small>{a.name}</small>
                </div>
              </div>
              <span className="sim-pill">{state!.market ? 'Binance · USDT' : 'بانتظار Binance'}</span>
            </div>
            <b className="market-price" dir="ltr">
              {state!.market ? money(a.price) : '—'}
            </b>
            <Spark
              data={a.history}
              color={a.change >= 0 ? "#68cfaa" : "#e48b94"}
            />
            <span className={a.change >= 0 ? "positive" : "negative"} dir="ltr">
              {a.change >= 0 ? "+" : ""}
              {a.change.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            navigate("city");
          }}
        >
          <span className="brand-symbol">
            <Crown size={29} />
          </span>
          <div>
            AI EMPIRE<small>BUILD YOUR LEGACY</small>
          </div>
        </a>
        <div className="owner">
          <span className="owner-avatar">م</span>
          <div>
            <b>{session?.user.name ?? "مهند صلاح"}</b>
            <span>
              مالك المملكة <Crown size={11} />
            </span>
          </div>
          <span className="online-dot" />
        </div>
        <span className="nav-label">غرفة القيادة</span>
        <nav>
          {NAV.map((n) => (
            <button
              title={n.label}
              className={`${view === n.id ? "active" : ""} ${n.id === "wallet" ? "mobile-wallet-button" : ""}`}
              key={n.id}
              onClick={() => navigate(n.id)}
            >
              <n.icon size={19} />
              <span>{n.id === "wallet" ? "المحفظة" : n.label}</span>
              {view === n.id ? (
                <span className="nav-dot" />
              ) : null}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="level-box">
            <div>
              <Crown size={17} />
              <b>{LEVELS[level].name}</b>
              <span>LV {level + 1}</span>
            </div>
            <div className="progress">
              <i style={{ width: `${xpProgress}%` }} />
            </div>
            <small>
              {state.xp} / {next?.xp ?? 1600} XP
            </small>
            <p>
              {next
                ? `${next.xp - state.xp} XP للوصول إلى ${next.name}`
                : "إمبراطورية مكتملة • استمر بالإنجاز"}
            </p>
          </div>
          <button
            className="sidebar-setting"
            onClick={() => setModal("settings")}
          >
            <Settings2 size={18} /> إعدادات المملكة
          </button>
          <div className="save-status">
            <span className="live-dot" />
            {storageStatus}
          </div>
        </div>
      </aside>
      <main>
        <header className="topbar">
          <div className="breadcrumb">
            <Crown size={16} />
            <span>المملكة</span>
            <ChevronLeft size={13} />
            <b>{NAV.find((n) => n.id === view)?.label}</b>
          </div>
          <div className="top-actions">
            <button
              className="account-access"
              aria-label={session?.user.email ? "حساب المؤسس" : "تسجيل الدخول أو إنشاء حساب"}
              onClick={() => navigate("account")}
            >
              <Users size={18} /><span>{session?.user.email ? "حسابي" : "تسجيل الدخول"}</span>
            </button>
            <span className="simulation-label">
              <span /> {view === "wallet" || view === "city" ? "حساب مال حقيقي" : "عالم وتدريب افتراضي"}
            </span>
            <button
              className="icon-button notification-button"
              aria-label="الإشعارات"
              onClick={() => setModal("notifications")}
            >
              <Bell size={19} />
              {!!state.notifications.length && <i />}
            </button>
            {view !== 'autotrader' && <button
              className="emergency-top"
              onClick={() => change(emergencyStop)}
              disabled={state.emergency}
            >
              <Power size={15} />
              <span>إيقاف تدريب التداول</span>
            </button>}
          </div>
        </header>
        {error && <div className="error-banner">{error}</div>}
        <div className="simulation-banner">
          <ShieldCheck size={14} /> {view === 'autotrader' ? 'أسعار فعلية • التداول الحقيقي مشروط بإثبات خادمي وتفعيلك اليدوي' : view === "city" ? "حساب المحفظة حقيقي • المدينة والصفقات التجريبية افتراضية" : view === "wallet" ? "محفظة USDT حقيقية • كل إرسال بموافقتك • منفصلة عن حساب البوت في Binance" : view === "academy" ? "اختبارات قواعد الفريق • لا صرف أموال أو تدريب نموذج" : view === "research" ? "مصادر منشورة وبيانات سوق • فحص بالقواعد • لا تنفيذ تلقائي" : "تدريب بمال افتراضي على أسعار Binance • لا أرباح قابلة للسحب"}{" "}
          <button onClick={() => setModal("help")}>
            كيف ألعب؟ <ArrowUpLeft size={12} />
          </button>
        </div>
        <div className="main-content">{body}</div>
        <footer className="app-footer">
          <span>
            AI EMPIRE <small>© 2026</small>
          </span>
          <p>ابنِ مملكتك. اختبر قراراتك. تعلّم من كل دورة.</p>
          <span className="footer-status">
            <span className="live-dot" /> CIVILIZATION ENGINE V2.0
          </span>
        </footer>
      </main>
      {modal && (
        <Modal title={title} subtitle={subtitle} onClose={() => setModal(null)}>
          {modalContent()}
        </Modal>
      )}
    </div>
  );
}
