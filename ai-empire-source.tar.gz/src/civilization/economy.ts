import type { Civilization, Person } from "./types.ts";
import {
  account,
  age,
  balance,
  clamp,
  event,
  nextId,
  SKILL_NAMES,
} from "./shared.ts";
export function transfer(
  s: Civilization,
  from: string,
  to: string,
  amount: number,
  reason: string,
  id?: string,
) {
  amount = Math.round(amount);
  if (
    !Number.isSafeInteger(amount) ||
    amount <= 0 ||
    from === to ||
    balance(s, from) < amount
  )
    return false;
  if (id && s.ledger.some((t) => t.id === id)) return false;
  s.balances[from] -= amount;
  s.balances[to] = (s.balances[to] ?? 0) + amount;
  s.ledger.push({
    id: id ?? nextId(s, "transfer"),
    day: s.clock.day,
    from,
    to,
    amount,
    reason,
  });
  return true;
}
export const totalBalances = (s: Civilization) =>
  Object.values(s.balances).reduce((a, b) => a + b, 0);
export function acceptJob(s: Civilization, p: Person) {
  if (age(s, p) < 18 || p.retired || p.job || !p.alive) return;
  const suitable = s.jobs
    .filter((j) => !j.worker && p.skills[j.skill] >= j.required)
    .sort((a, b) => b.salary - a.salary);
  const job = suitable.find(
    (j) => balance(s, `company:${j.company}`) > j.salary * 15,
  );
  if (job) {
    job.worker = p.id;
    p.job = job.id;
    p.goal = `إتقان ${SKILL_NAMES[job.skill]}`;
    event(
      s,
      "job",
      `${p.name} قُبل في وظيفة ${job.title} بعد تحقيق شرط المهارة`,
      [p.id],
    );
  }
}
export function workDay(s: Civilization, p: Person) {
  if (!p.job || p.retired || age(s, p) < 18) return;
  const j = s.jobs.find((j) => j.id === p.job);
  if (!j || j.worker !== p.id) return;
  const c = s.companies.find((c) => c.id === j.company)!;
  const productivity = Math.max(
    0.15,
    (0.35 + p.skills[j.skill] / 150) *
      (p.needs.health / 100) *
      (0.45 + p.needs.rest / 160),
  );
  const qty = Math.max(1, Math.floor(productivity * 4));
  if (
    transfer(
      s,
      `company:${c.id}`,
      account(p),
      j.salary,
      `راتب ${j.title}`,
      `salary:${s.clock.day}:${j.id}`,
    )
  ) {
    transfer(
      s,
      account(p),
      "treasury",
      Math.floor((j.salary * s.policy.taxPct) / 100),
      "ضريبة راتب",
      `tax:${s.clock.day}:${j.id}`,
    );
    p.skills[j.skill] = clamp(p.skills[j.skill] + 0.075 * p.traits.diligence);
    p.skills.management = clamp(
      p.skills.management + 0.015 * p.traits.diligence,
    );
    c.inventory += qty;
    c.produced += qty;
    p.needs.rest = clamp(p.needs.rest - 9);
    p.needs.hunger = clamp(p.needs.hunger + 8);
  } else {
    p.activity = "تأخر الراتب • الشركة تفتقر للسيولة";
    if (s.clock.day % 30 === 0)
      event(s, "economy", `تعذر دفع راتب ${p.name} من ${c.name}`, [p.id]);
  }
}
export function economyDay(s: Civilization) {
  let welfareLeft = s.policy.welfareBudget;
  for (const p of s.people.filter((p) => p.alive)) {
    const wallet = account(p),
      a = age(s, p);
    if (a >= 18) acceptJob(s, p);
    if (p.job && !p.retired) workDay(s, p);
    const family = p.family
      ? s.families.find((f) => f.id === p.family)
      : undefined;
    const guardian = p.parents
      .map((id) => s.people.find((x) => x.id === id))
      .find((x) => x?.alive);
    const payer = a < 18 && guardian ? account(guardian) : wallet;
    const foodCost = Math.round(
      s.market.price * (a < 6 ? 0.45 : a < 18 ? 0.75 : 1),
    );
    if (
      s.market.stock > 0 &&
      transfer(
        s,
        payer,
        "market",
        foodCost,
        "طعام ومصاريف معيشة",
        `food:${s.clock.day}:${p.id}`,
      )
    ) {
      s.market.stock--;
      p.needs.hunger = clamp(p.needs.hunger - 55);
      p.needs.health = clamp(p.needs.health + 0.7);
    } else {
      p.needs.hunger = clamp(p.needs.hunger + 13);
      p.needs.health = clamp(p.needs.health - 0.15);
    }
    if (a >= 18 && s.clock.day % 5 === 0) {
      const house = s.homes.find((h) => h.id === p.home);
      const occupants =
        house?.residents.filter((id) => {
          const q = s.people.find((x) => x.id === id);
          return q && age(s, q) >= 18;
        }).length ?? 1;
      transfer(
        s,
        wallet,
        "housing",
        Math.floor(((house?.rent ?? 150) * 5) / Math.max(1, occupants)),
        "إيجار المسكن",
        `rent:${s.clock.day}:${p.id}`,
      );
    }
    if (a >= 18 && balance(s, wallet) < 5000 && welfareLeft > 0) {
      const grant = Math.min(250, welfareLeft, balance(s, "treasury"));
      if (
        transfer(
          s,
          "treasury",
          wallet,
          grant,
          p.retired ? "معونة تقاعد" : "دعم معيشة",
          `welfare:${s.clock.day}:${p.id}`,
        )
      )
        welfareLeft -= grant;
    }
    p.needs.rest = clamp(p.needs.rest + 14);
    p.needs.social = clamp(p.needs.social - 1);
    if (p.needs.hunger > 80) p.goal = "الحصول على طعام ودعم";
    if (family && family.children.length) p.longGoal = "دعم تعليم الجيل التالي";
  }
  const population = s.people.filter((p) => p.alive).length;
  for (const c of s.companies) {
    const wallet = `company:${c.id}`;
    if (c.type === "studio") {
      const qty = Math.min(c.inventory, 2);
      if (
        qty &&
        transfer(
          s,
          "treasury",
          wallet,
          qty * c.price,
          "خدمات برمجية لصيانة مرافق المملكة",
        )
      )
        c.inventory -= qty;
    } else {
      const quantity = Math.min(
        c.inventory,
        Math.max(1, Math.ceil((population * 2 - s.market.stock) / 2)),
      );
      if (
        quantity > 0 &&
        transfer(
          s,
          "market",
          wallet,
          quantity * c.price,
          "شراء إنتاج محلي للسوق",
        )
      ) {
        c.inventory -= quantity;
        s.market.stock += quantity * 2;
      }
    }
  }
  s.market.demand = population;
  s.market.price = Math.round(
    clamp(
      110 * (1 + (population * 3 - s.market.stock) / (population * 10)),
      65,
      210,
    ),
  );
  if (s.clock.day % 30 === 0) {
    if (totalBalances(s) !== s.totalMoney)
      throw new Error("اختلال حسابي: مجموع الأرصدة لا يساوي رأس مال المجتمع");
    event(
      s,
      "economy",
      `إقفال اليوم ${s.clock.day}: ${population} سكان • جميع التحويلات متوازنة`,
    );
  }
}
