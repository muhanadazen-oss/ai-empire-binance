import type {
  Civilization,
  Person,
  Place,
  Skill,
  CivicEvent,
} from "./types.ts";
export const YEAR_DAYS = 120;
export const SKILL_NAMES: Record<Skill, string> = {
  analysis: "التحليل",
  trade: "التجارة",
  management: "الإدارة",
  programming: "البرمجة",
  industry: "الصناعة",
  agriculture: "الزراعة",
};
export const PLACE_NAMES: Record<Place, string> = {
  home: "المنزل",
  school: "المدرسة",
  library: "المكتبة",
  training: "مركز التدريب",
  university: "الجامعة",
  market: "السوق",
  park: "الحديقة",
  farm: "المزرعة",
  factory: "المصنع",
  studio: "شركة التقنية",
};
export const account = (p: Person | string) =>
  `person:${typeof p === "string" ? p : p.id}`;
export const age = (s: Civilization, p: Person) =>
  Math.max(0, Math.floor((s.clock.day - p.bornDay) / YEAR_DAYS));
export const stage = (s: Civilization, p: Person) =>
  !p.alive
    ? "متوفى"
    : age(s, p) < 6
      ? "طفولة مبكرة"
      : age(s, p) < 16
        ? "طالب مدرسة"
        : age(s, p) < 18
          ? "تدريب وشباب"
          : p.retired
            ? "متقاعد"
            : "بالغ";
export function random(s: Civilization) {
  s.seed = (Math.imul(s.seed, 1664525) + 1013904223) >>> 0;
  return s.seed / 4294967296;
}
export const clamp = (n: number, min = 0, max = 100) =>
  Math.max(min, Math.min(max, n));
export const nextId = (s: Civilization, prefix: string) =>
  `${prefix}-${s.nextId++}`;
export function event(
  s: Civilization,
  kind: CivicEvent["kind"],
  text: string,
  people: string[] = [],
) {
  const e = { id: nextId(s, "event"), day: s.clock.day, kind, text, people };
  s.events.push(e);
  for (const id of people) {
    const p = s.people.find((p) => p.id === id);
    if (p) {
      p.memory.unshift({ day: s.clock.day, text });
      p.memory = p.memory.slice(0, 45);
      p.events.push(e.id);
      p.events = p.events.slice(-80);
    }
  }
  return e;
}
export const skillSet = (): Person["skills"] => ({
  analysis: 0,
  trade: 0,
  management: 0,
  programming: 0,
  industry: 0,
  agriculture: 0,
});
export function remember(p: Person, day: number, text: string) {
  p.memory.unshift({ day, text });
  p.memory = p.memory.slice(0, 45);
}
export function balance(s: Civilization, p: Person | string) {
  return s.balances[typeof p === "string" ? p : account(p)] ?? 0;
}
