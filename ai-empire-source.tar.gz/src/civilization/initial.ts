import type { Civilization, Person, Skill } from "./types.ts";
import { account, event, skillSet, YEAR_DAYS } from "./shared.ts";
export function initialCivilization(seed = 7294): Civilization {
  const s: Civilization = {
    version: 1,
    seed,
    nextId: 100,
    revision: 0,
    clock: { day: 0, hour: 8, running: false, speed: 1 },
    people: [],
    relationships: [],
    families: [],
    homes: [],
    facilities: [
      {
        id: "school",
        name: "مدرسة الأجيال",
        built: true,
        cost: 300000,
        capacity: 20,
        location: [-5.2, -5.2],
      },
      {
        id: "training",
        name: "مركز المهارات",
        built: true,
        cost: 400000,
        capacity: 12,
        location: [-4.4, 2.6],
      },
      {
        id: "library",
        name: "مكتبة المعرفة",
        built: false,
        cost: 160000,
        capacity: 20,
        location: [-1.6, -5.1],
      },
      {
        id: "university",
        name: "جامعة المملكة",
        built: false,
        cost: 700000,
        capacity: 15,
        location: [3.8, 3.8],
      },
      {
        id: "market",
        name: "سوق المجتمع",
        built: true,
        cost: 100000,
        capacity: 80,
        location: [-6, -3],
      },
      {
        id: "park",
        name: "حديقة العائلات",
        built: true,
        cost: 100000,
        capacity: 80,
        location: [-2, 0],
      },
      {
        id: "farm",
        name: "مزرعة الأمل",
        built: true,
        cost: 300000,
        capacity: 10,
        location: [5.2, -1.8],
      },
      {
        id: "factory",
        name: "ورشة الصناعة",
        built: true,
        cost: 400000,
        capacity: 10,
        location: [4.8, 5.2],
      },
      {
        id: "studio",
        name: "شركة الجيل الرقمي",
        built: true,
        cost: 300000,
        capacity: 10,
        location: [-0.8, -3.8],
      },
      {
        id: "home",
        name: "حي السكان",
        built: true,
        cost: 90000,
        capacity: 80,
        location: [-5.5, 5.4],
      },
    ],
    jobs: [],
    companies: [
      {
        id: "farm",
        name: "مزرعة الأمل",
        type: "farm",
        inventory: 120,
        price: 65,
        produced: 0,
        owner: "p1",
      },
      {
        id: "factory",
        name: "ورشة النخبة",
        type: "factory",
        inventory: 100,
        price: 80,
        produced: 0,
        owner: "p3",
      },
      {
        id: "studio",
        name: "الجيل الرقمي",
        type: "studio",
        inventory: 20,
        price: 180,
        produced: 0,
        owner: "p5",
      },
    ],
    balances: {
      treasury: 20000000,
      market: 1000000,
      housing: 1000000,
      education: 500000,
      construction: 0,
      "company:farm": 3000000,
      "company:factory": 3000000,
      "company:studio": 3000000,
    },
    totalMoney: 0,
    ledger: [],
    events: [],
    policy: {
      populationCap: 30,
      educationBudget: 3000,
      welfareBudget: 2000,
      birthsAllowed: true,
      taxPct: 10,
      retirementAge: 60,
    },
    market: { stock: 100, price: 110, demand: 10 },
  };
  const defs: [string, string, "m" | "f", number, Skill, number][] = [
    ["p1", "آدم سالم", "m", 25, "agriculture", 22],
    ["p2", "نور حسن", "f", 24, "analysis", 18],
    ["p3", "رائد منصور", "m", 28, "industry", 20],
    ["p4", "سلمى ناصر", "f", 26, "management", 21],
    ["p5", "ليث عادل", "m", 32, "programming", 25],
    ["p6", "رؤى فادي", "f", 30, "trade", 20],
    ["p7", "سامر زيد", "m", 22, "industry", 4],
    ["p8", "هالة عمر", "f", 23, "agriculture", 4],
    ["p9", "يوسف أمين", "m", 56, "management", 35],
    ["p10", "مريم جابر", "f", 52, "analysis", 35],
  ];
  defs.forEach(([id, name, gender, a, skill, xp], i) => {
    const skills = skillSet();
    skills[skill] = xp;
    skills.management = Math.max(skills.management, i >= 8 ? 35 : 8);
    const p: Person = {
      id,
      name,
      gender,
      bornDay: -a * YEAR_DAYS,
      generation: 1,
      parents: [],
      home: `home-${i + 1}`,
      traits: {
        sociability: 0.55 + (i % 3) * 0.08,
        diligence: 0.75 + (i % 2) * 0.1,
        creativity: 0.4 + (i % 4) * 0.11,
        kindness: 0.75 + (i % 3) * 0.07,
        familyWish: i !== 4 && i !== 9,
      },
      skills,
      literacy: 65,
      needs: { health: 95, rest: 85, hunger: 15, social: 70 },
      goal: "تأسيس حياة في المملكة",
      longGoal: i < 8 ? "تكوين أسرة ومهنة مستقرة" : "إرشاد الأجيال",
      memory: [],
      events: [],
      place: "home",
      previousPlace: "home",
      activity: "ينتقل إلى الحي",
      retired: false,
      alive: true,
      schoolDays: 800,
      trainingDays: 0,
      lastMentorDay: -1,
    };
    s.people.push(p);
    s.balances[account(p)] = 300000;
  });
  for (let i = 1; i <= 14; i++)
    s.homes.push({
      id: `home-${i}`,
      name: `بيت ${i}`,
      capacity: 4,
      residents: i <= 10 ? [`p${i}`] : [],
      rent: 100,
    });
  const jobDefs: [string, Skill, number, string][] = [
    ["farm", "agriculture", 8, "مزارع"],
    ["farm", "agriculture", 8, "مزارع مساعد"],
    ["factory", "industry", 8, "فني إنتاج"],
    ["factory", "industry", 8, "فني مساعد"],
    ["studio", "programming", 8, "مبرمج"],
    ["studio", "analysis", 8, "محلل"],
    ["studio", "management", 8, "منسق مشاريع"],
    ["factory", "trade", 8, "مسؤول مبيعات"],
  ];
  jobDefs.forEach(([company, skill, required, title], i) =>
    s.jobs.push({
      id: `job-${i + 1}`,
      company,
      skill,
      required,
      title,
      salary: 320 + (i % 3) * 80,
    }),
  );
  s.totalMoney = Object.values(s.balances).reduce((a, b) => a + b, 0);
  s.ledger.push({
    id: "genesis",
    day: 0,
    from: "initial-allocation",
    to: "all-accounts",
    amount: s.totalMoney,
    reason: "رأس مال افتراضي أولي موزع مرة واحدة؛ لا إيداع حقيقي",
  });
  event(
    s,
    "policy",
    "تأسس المجتمع بعشرة بالغين وبعملة حضارية منفصلة تمامًا عن تداول المحاكاة",
  );
  return s;
}
