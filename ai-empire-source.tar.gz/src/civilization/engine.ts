import type { Civilization, CivAction, Skill } from "./types.ts";
import { clockTick } from "./clock.ts";
import { account, age, balance, event, nextId, SKILL_NAMES } from "./shared.ts";
import { enroll } from "./education.ts";
import { totalBalances, transfer } from "./economy.ts";
export function applyCivicAction(state: Civilization, action: CivAction) {
  const s = structuredClone(state);
  switch (action.type) {
    case "step":
      return clockTick(s);
    case "clock":
      if (action.speed !== undefined) {
        if (![1, 5, 10].includes(action.speed))
          throw new Error("سرعة غير صالحة");
        s.clock.speed = action.speed;
      }
      if (action.running !== undefined) s.clock.running = !!action.running;
      break;
    case "build": {
      const f = s.facilities.find((f) => f.id === action.facility);
      if (!f || f.built) throw new Error("الخدمة موجودة أو غير معروفة");
      if (!transfer(s, "treasury", "construction", f.cost, `بناء ${f.name}`))
        throw new Error("ميزانية المملكة غير كافية");
      f.built = true;
      event(s, "policy", `اكتمل بناء ${f.name} وفتحت خدماتها`);
      break;
    }
    case "home": {
      if (s.homes.length >= 30) throw new Error("بلغ الحي الحد الأولي للمساكن");
      if (!transfer(s, "treasury", "construction", 90000, "بناء مسكن عائلي"))
        throw new Error("الميزانية غير كافية");
      const id = nextId(s, "home");
      s.homes.push({
        id,
        name: `بيت العائلة ${s.homes.length + 1}`,
        capacity: 4,
        residents: [],
        rent: 100,
      });
      event(s, "policy", "بناء مسكن جديد متاح لتأسيس أسرة");
      break;
    }
    case "support": {
      const p = s.people.find((p) => p.id === action.person && p.alive);
      if (
        !p ||
        !Number.isSafeInteger(action.amount) ||
        action.amount < 100 ||
        action.amount > 100000
      )
        throw new Error("قيمة الدعم أو الشخصية غير صالحة");
      if (
        !transfer(
          s,
          "treasury",
          account(p),
          action.amount,
          "دعم أسرة بقرار المؤسس",
        )
      )
        throw new Error("الميزانية غير كافية");
      event(s, "economy", `حصل ${p.name} على دعم من الخزينة`, [p.id]);
      break;
    }
    case "policy": {
      const r = { ...s.policy, ...action.values };
      if (
        ![
          r.populationCap,
          r.educationBudget,
          r.welfareBudget,
          r.taxPct,
          r.retirementAge,
        ].every(Number.isSafeInteger) ||
        r.populationCap <
          Math.max(10, s.people.filter((p) => p.alive).length) ||
        r.populationCap > 80 ||
        r.educationBudget < 0 ||
        r.educationBudget > 20000 ||
        r.welfareBudget < 0 ||
        r.welfareBudget > 20000 ||
        r.taxPct < 0 ||
        r.taxPct > 30 ||
        r.retirementAge < 55 ||
        r.retirementAge > 75 ||
        typeof r.birthsAllowed !== "boolean"
      )
        throw new Error("سياسة خارج الحدود المسموح بها");
      s.policy = r;
      event(s, "policy", "تم تغيير سياسات المملكة بقرار المؤسس");
      break;
    }
    case "job": {
      const c = s.companies.find((c) => c.id === action.company);
      if (
        !c ||
        !Object.keys(SKILL_NAMES).includes(action.skill) ||
        !Number.isSafeInteger(action.salary) ||
        action.salary < 100 ||
        action.salary > 3000 ||
        !Number.isFinite(action.required) ||
        action.required < 1 ||
        action.required > 80 ||
        s.jobs.length >= 80
      )
        throw new Error("شروط وظيفة غير صالحة");
      s.jobs.push({
        id: nextId(s, "job"),
        company: c.id,
        title: `مختص ${SKILL_NAMES[action.skill]}`,
        skill: action.skill,
        required: action.required,
        salary: action.salary,
      });
      event(
        s,
        "job",
        `أُنشئت وظيفة ${SKILL_NAMES[action.skill]} في ${c.name} بشروط قبول واضحة`,
      );
      break;
    }
    case "enroll": {
      const p = s.people.find((p) => p.id === action.person);
      if (
        !p ||
        !Object.keys(SKILL_NAMES).includes(action.skill) ||
        !["training", "university"].includes(action.kind) ||
        !enroll(s, p, action.skill, action.kind)
      )
        throw new Error(
          "لم تتحقق شروط العمر أو التعليم أو توفر الخدمة والمقعد",
        );
      break;
    }
    case "planning": {
      const f = s.families.find((f) => f.id === action.family);
      if (!f) throw new Error("أسرة غير معروفة");
      if (
        action.enabled &&
        f.parents.some(
          (id) => !s.people.find((p) => p.id === id)!.traits.familyWish,
        )
      )
        throw new Error("الرغبة ليست متبادلة بين الوالدين");
      f.planning = !!action.enabled;
      event(
        s,
        "policy",
        f.planning
          ? "اختارت الأسرة التخطيط لطفل ضمن شروط المملكة"
          : "أوقفت الأسرة التخطيط للإنجاب",
        f.parents,
      );
      break;
    }
    case "company": {
      const p = s.people.find((p) => p.id === action.person && p.alive);
      if (
        !p ||
        age(s, p) < 18 ||
        p.retired ||
        p.skills.management < 8 ||
        !["farm", "factory", "studio"].includes(action.kind) ||
        action.name.trim().length < 2 ||
        action.name.length > 50 ||
        s.companies.length >= 15
      )
        throw new Error(
          "مؤسس الشركة يجب أن يكون بالغًا وبمهارة إدارة 8 على الأقل",
        );
      const id = nextId(s, "company"),
        wallet = `company:${id}`;
      s.balances[wallet] = 0;
      if (!transfer(s, account(p), wallet, 50000, "تمويل تأسيس شركة عائلية")) {
        delete s.balances[wallet];
        throw new Error("يحتاج المؤسس 500 وحدة حضارية لتمويل الشركة");
      }
      s.companies.push({
        id,
        name: action.name.trim(),
        type: action.kind,
        owner: p.id,
        inventory: 0,
        price: action.kind === "studio" ? 180 : 70,
        produced: 0,
      });
      event(s, "job", `أسس ${p.name} شركة ${action.name} بأموال من حسابه`, [
        p.id,
      ]);
      break;
    }
    default:
      throw new Error("أمر مجتمع غير مدعوم");
  }
  if (totalBalances(s) !== s.totalMoney) throw new Error("اختلال محاسبي");
  return s;
}
