import { createContext, useContext, useEffect, useRef, useState } from "react";
import type { Civilization, CivAction } from "./types";
import { civicAction, getSession } from "../storage/cloud";
interface Context {
  civic: Civilization | null;
  error: string;
  busy: boolean;
  send: (action: CivAction) => Promise<void>;
  refresh: () => Promise<void>;
}
const CivContext = createContext<Context>(null!);
export function CivilizationProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [civic, setCivic] = useState<Civilization | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const civicRef = useRef(civic),
    pending = useRef(false);
  civicRef.current = civic;
  async function refresh() {
    try {
      const r = await getSession();
      setCivic(r.civic);
      setError("");
    } catch (e) {
      setError(String(e));
    }
  }
  async function send(action: CivAction) {
    if (pending.current || !civicRef.current) return;
    pending.current = true;
    setBusy(true);
    const id = crypto.randomUUID();
    try {
      let r;
      try {
        r = await civicAction(action, civicRef.current.revision, id);
      } catch (e) {
        if (String(e).includes("CONFLICT")) {
          const fresh = await getSession();
          r = await civicAction(action, fresh.civic.revision, id);
        } else throw e;
      }
      setCivic(r.civic);
      setError("");
    } catch (e) {
      if (action.type === "step") {
        await refresh();
      }
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      pending.current = false;
      setBusy(false);
    }
  }
  useEffect(() => {
    refresh();
    const interval = setInterval(() => {
      if (!document.hidden && civicRef.current?.clock.running)
        send({ type: "step" });
    }, 1100);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    const hidden = () => {
      if (document.hidden && civicRef.current?.clock.running)
        send({ type: "clock", running: false });
    };
    document.addEventListener("visibilitychange", hidden);
    return () => document.removeEventListener("visibilitychange", hidden);
  }, []);
  return (
    <CivContext.Provider value={{ civic, error, busy, send, refresh }}>
      {children}
    </CivContext.Provider>
  );
}
export const useCivilization = () => useContext(CivContext);
