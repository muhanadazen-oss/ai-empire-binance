import type { Civilization, Person } from "./types.ts";
import {
  account,
  age,
  balance,
  clamp,
  event,
  nextId,
  random,
  skillSet,
  YEAR_DAYS,
} from "./shared.ts";
import { transfer } from "./economy.ts";
export function child(s: Civilization, familyId: string) {
  const f = s.families.find((f) => f.id === familyId);
  if (
    !f ||
    !f.planning ||
    !s.policy.birthsAllowed ||
    f.children.length >= 2 ||
    s.people.filter((p) => p.alive).length >= s.policy.populationCap
  )
    return false;
  const parents = f.parents.map((id) => s.people.find((p) => p.id === id)!);
  if (
    parents.some(
      (p) =>
        !p.alive || age(s, p) < 18 || age(s, p) > 46 || !p.traits.familyWish,
    ) ||
    s.clock.day < f.nextBirthDay ||
    s.clock.day - f.marriedDay < 60 ||
    parents.reduce((v, p) => v + balance(s, p), 0) < 30000
  )
    return false;
  const house = s.homes.find((h) => h.id === f.home)!;
  if (house.residents.length >= house.capacity) return false;
  const gender = random(s) > 0.5 ? "m" : "f";
  const names =
    gender === "m"
      ? ["آسر", "مالك", "يزن", "كريم", "رامي", "سليم"]
      : ["ليان", "سارة", "ميرا", "جنى", "رنا", "لمى"];
  const name =
    names[Math.floor(random(s) * names.length)] +
    " " +
    parents[0].name.split(" ")[0];
  const id = nextId(s, "citizen");
  const traits = {
    sociability: clamp(
      (parents[0].traits.sociability + parents[1].traits.sociability) / 2 +
        (random(s) - 0.5) * 0.4,
      0.1,
      1,
    ),
    diligence: clamp(
      (parents[0].traits.diligence + parents[1].traits.diligence) / 2 +
        (random(s) - 0.5) * 0.4,
      0.1,
      1,
    ),
    creativity: clamp(
      (parents[0].traits.creativity + parents[1].traits.creativity) / 2 +
        (random(s) - 0.5) * 0.5,
      0.1,
      1,
    ),
    kindness: clamp(
      (parents[0].traits.kindness + parents[1].traits.kindness) / 2 +
        (random(s) - 0.5) * 0.4,
      0.1,
      1,
    ),
    familyWish: random(s) > 0.3,
  };
  const p: Person = {
    id,
    name,
    gender,
    bornDay: s.clock.day,
    generation: Math.max(...parents.map((p) => p.generation)) + 1,
    parents: f.parents,
    partner: undefined,
    family: f.id,
    home: f.home,
    traits,
    skills: skillSet(),
    literacy: 0,
    needs: { health: 100, rest: 100, hunger: 0, social: 85 },
    goal: "النمو برعاية الأسرة",
    longGoal: "اكتشاف اهتماماتي",
    memory: [],
    events: [],
    place: "home",
    previousPlace: "home",
    activity: "طفولة • رعاية أسرية",
    retired: false,
    alive: true,
    schoolDays: 0,
    trainingDays: 0,
    lastMentorDay: -1,
  };
  s.people.push(p);
  s.balances[account(p)] = 0;
  f.children.push(id);
  house.residents.push(id);
  f.nextBirthDay = s.clock.day + 360;
  const firstShare = Math.min(5000, balance(s, parents[0]));
  if (firstShare > 0)
    transfer(
      s,
      account(parents[0]),
      "market",
      firstShare,
      "مستلزمات مولود",
      `birth-cost:${f.id}:${f.children.length}:a`,
    );
  if (firstShare < 5000)
    transfer(
      s,
      account(parents[1]),
      "market",
      5000 - firstShare,
      "مستلزمات مولود",
      `birth-cost:${f.id}:${f.children.length}:b`,
    );
  event(
    s,
    "birth",
    `وُلد ${name} لعائلة ${parents.map((p) => p.name).join(" و ")} • يبدأ بلا مهارات مهنية`,
    [...f.parents, id],
  );
  return true;
}
export function populationDay(s: Civilization) {
  for (const p of s.people.filter((p) => p.alive)) {
    const a = age(s, p);
    if (a >= s.policy.retirementAge && !p.retired) {
      p.retired = true;
      const job = s.jobs.find((j) => j.id === p.job);
      if (job) job.worker = undefined;
      p.job = undefined;
      event(
        s,
        "retirement",
        `${p.name} انتقل إلى التقاعد ويتيح الخبرة للجيل التالي`,
        [p.id],
      );
    }
    if (p.retired)
      for (const c of s.companies.filter((c) => c.owner === p.id)) {
        const heir = s.people
          .filter(
            (h) =>
              h.parents.includes(p.id) &&
              h.alive &&
              age(s, h) >= 18 &&
              h.skills.management >= 8,
          )
          .sort((a, b) => b.skills.management - a.skills.management)[0];
        if (heir) {
          c.owner = heir.id;
          c.successor = heir.id;
          event(
            s,
            "job",
            `انتقلت إدارة ${c.name} من ${p.name} إلى ${heir.name}`,
            [p.id, heir.id],
          );
        }
      }
    if (a >= 85 && s.clock.day % 120 === 0 && random(s) < 0.2) {
      p.alive = false;
      const j = s.jobs.find((j) => j.id === p.job);
      if (j) j.worker = undefined;
      const home = s.homes.find((h) => h.id === p.home);
      if (home) home.residents = home.residents.filter((id) => id !== p.id);
      const heirs = s.people.filter((h) => h.parents.includes(p.id) && h.alive);
      const target = heirs[0] ? account(heirs[0]) : "treasury";
      const amount = balance(s, p);
      if (amount > 0)
        transfer(s, account(p), target, amount, "انتقال تركة افتراضية");
      event(
        s,
        "retirement",
        `انتهت حياة ${p.name} الافتراضية وانتقلت التركة المسجلة`,
        [p.id, ...heirs.map((h) => h.id)],
      );
    }
    if (a === 6 && p.schoolDays === 0) p.goal = "تعلم القراءة في المدرسة";
    if (a === 18 && p.job === undefined && p.longGoal === "اكتشاف اهتماماتي")
      p.longGoal = "بدء مهنة مستقلة";
  }
}
