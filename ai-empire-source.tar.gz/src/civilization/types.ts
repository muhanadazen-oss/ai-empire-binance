export const SKILLS = [
  "analysis",
  "trade",
  "management",
  "programming",
  "industry",
  "agriculture",
] as const;
export type Skill = (typeof SKILLS)[number];
export type Place =
  | "home"
  | "school"
  | "library"
  | "training"
  | "university"
  | "market"
  | "park"
  | "farm"
  | "factory"
  | "studio";
export interface Person {
  id: string;
  name: string;
  gender: "m" | "f";
  bornDay: number;
  generation: number;
  parents: string[];
  partner?: string;
  family?: string;
  home: string;
  traits: {
    sociability: number;
    diligence: number;
    creativity: number;
    kindness: number;
    familyWish: boolean;
  };
  skills: Record<Skill, number>;
  literacy: number;
  needs: { health: number; rest: number; hunger: number; social: number };
  goal: string;
  longGoal: string;
  memory: { day: number; text: string }[];
  events: string[];
  place: Place;
  previousPlace: Place;
  activity: string;
  job?: string;
  retired: boolean;
  alive: boolean;
  schoolDays: number;
  trainingDays: number;
  course?: {
    skill: Skill;
    progress: number;
    required: number;
    kind: "training" | "university";
  };
  lastMentorDay: number;
}
export interface Relationship {
  a: string;
  b: string;
  affinityA: number;
  affinityB: number;
  interactions: number;
  lastDay: number;
  friend: boolean;
}
export interface Family {
  id: string;
  parents: string[];
  children: string[];
  marriedDay: number;
  home: string;
  planning: boolean;
  nextBirthDay: number;
}
export interface Home {
  id: string;
  name: string;
  capacity: number;
  residents: string[];
  family?: string;
  rent: number;
}
export interface Facility {
  id: Place;
  name: string;
  built: boolean;
  cost: number;
  capacity: number;
  location: [number, number];
}
export interface Job {
  id: string;
  company: string;
  title: string;
  skill: Skill;
  required: number;
  salary: number;
  worker?: string;
}
export interface Company {
  id: string;
  name: string;
  type: "farm" | "factory" | "studio";
  owner?: string;
  inventory: number;
  price: number;
  produced: number;
  successor?: string;
}
export interface Entry {
  id: string;
  day: number;
  from: string;
  to: string;
  amount: number;
  reason: string;
}
export interface CivicEvent {
  id: string;
  day: number;
  kind:
    | "birth"
    | "marriage"
    | "education"
    | "job"
    | "retirement"
    | "social"
    | "policy"
    | "economy";
  text: string;
  people: string[];
}
export interface Civilization {
  version: 1;
  seed: number;
  nextId: number;
  clock: { day: number; hour: number; running: boolean; speed: 1 | 5 | 10 };
  people: Person[];
  relationships: Relationship[];
  families: Family[];
  homes: Home[];
  facilities: Facility[];
  jobs: Job[];
  companies: Company[];
  balances: Record<string, number>;
  totalMoney: number;
  ledger: Entry[];
  events: CivicEvent[];
  policy: {
    populationCap: number;
    educationBudget: number;
    welfareBudget: number;
    birthsAllowed: boolean;
    taxPct: number;
    retirementAge: number;
  };
  market: { stock: number; price: number; demand: number };
  revision: number;
}
export type CivAction =
  | { type: "clock"; running?: boolean; speed?: 1 | 5 | 10 }
  | { type: "step" }
  | { type: "build"; facility: Place }
  | { type: "home" }
  | { type: "support"; person: string; amount: number }
  | { type: "policy"; values: Partial<Civilization["policy"]> }
  | {
      type: "job";
      company: string;
      skill: Skill;
      salary: number;
      required: number;
    }
  | {
      type: "enroll";
      person: string;
      skill: Skill;
      kind: "training" | "university";
    }
  | { type: "planning"; family: string; enabled: boolean }
  | { type: "company"; name: string; person: string; kind: Company["type"] };
