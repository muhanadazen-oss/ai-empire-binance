import type { Civilization, Person, Skill } from "./types.ts";
import {
  account,
  age,
  balance,
  clamp,
  event,
  random,
  SKILL_NAMES,
} from "./shared.ts";
import { transfer } from "./economy.ts";
export function enroll(
  s: Civilization,
  p: Person,
  skill: Skill,
  kind: "training" | "university" = "training",
) {
  const a = age(s, p),
    facility = kind === "university" ? "university" : "training";
  if (
    !p.alive ||
    p.retired ||
    p.course ||
    a < 16 ||
    !s.facilities.find((f) => f.id === facility)?.built ||
    p.literacy < 25 ||
    (kind === "university" &&
      (a < 18 || p.literacy < 40 || p.skills[skill] < 12))
  )
    return false;
  if (
    s.people.filter((q) => q.course?.kind === kind).length >=
    s.facilities.find((f) => f.id === facility)!.capacity
  )
    return false;
  if (balance(s, p) < 1000 && balance(s, "treasury") < 1000) return false;
  p.course = {
    skill,
    progress: 0,
    required: kind === "university" ? 120 : 60,
    kind,
  };
  event(
    s,
    "education",
    `${p.name} بدأ ${kind === "university" ? "دراسة جامعية" : "تدريبًا"} في ${SKILL_NAMES[skill]} بشروط الوقت والمعرفة والتكلفة`,
    [p.id],
  );
  return true;
}
export function educationDay(s: Civilization) {
  let budget = s.policy.educationBudget;
  let schoolPlaces =
    s.facilities.find((f) => f.id === "school" && f.built)?.capacity ?? 0;
  for (const p of s.people.filter((p) => p.alive)) {
    const a = age(s, p);
    if (a >= 6 && a < 16 && schoolPlaces > 0) {
      const cost = 80;
      if (
        budget >= cost &&
        transfer(
          s,
          "treasury",
          "education",
          cost,
          "تعليم أساسي",
          `school:${s.clock.day}:${p.id}`,
        )
      ) {
        budget -= cost;
        schoolPlaces--;
        p.schoolDays++;
        p.literacy = clamp(p.literacy + 0.055 * p.traits.diligence);
        if (p.schoolDays === 1)
          event(
            s,
            "education",
            `${p.name} بدأ المدرسة؛ يتعلم القراءة قبل المهنة`,
            [p.id],
          );
        if (p.schoolDays === 200)
          event(s, "education", `${p.name} أتم أول مرحلة من التعليم الأساسي`, [
            p.id,
          ]);
      }
    }
    if (
      a >= 16 &&
      !p.course &&
      !p.retired &&
      p.literacy >= 25 &&
      (!p.job || p.skills[s.jobs.find((j) => j.id === p.job)!.skill] < 12)
    ) {
      const skills = Object.keys(p.skills) as Skill[];
      const target = p.goal.includes("زراع")
        ? "agriculture"
        : p.traits.creativity > 0.7
          ? "programming"
          : p.traits.diligence > 0.7
            ? "industry"
            : skills[Math.floor(random(s) * skills.length)];
      enroll(s, p, target);
    }
    if (p.course) {
      const c = p.course,
        fee = c.kind === "university" ? 200 : 120;
      let paid = false;
      if (budget >= fee) {
        paid = transfer(
          s,
          "treasury",
          "education",
          fee,
          "منحة تعليم أو تدريب",
          `course:${s.clock.day}:${p.id}`,
        );
        if (paid) budget -= fee;
      }
      if (!paid)
        paid = transfer(
          s,
          account(p),
          "education",
          fee,
          "رسوم تدريب شخصية",
          `course:${s.clock.day}:${p.id}`,
        );
      if (paid) {
        c.progress++;
        p.trainingDays++;
        p.skills[c.skill] = clamp(
          p.skills[c.skill] +
            (c.kind === "university" ? 0.28 : 0.22) * p.traits.diligence,
        );
        if (c.progress >= c.required) {
          event(
            s,
            "education",
            `${p.name} أنهى ${SKILL_NAMES[c.skill]} بعد ${c.required} يوم تعلم وممارسة`,
            [p.id],
          );
          p.course = undefined;
        }
      }
    }
    if (s.facilities.find((f) => f.id === "library")?.built && a >= 10) {
      p.literacy = clamp(p.literacy + 0.009 * p.traits.diligence);
      if (a >= 18 && !p.course && !p.job) {
        const skill = (Object.keys(p.skills) as Skill[])[
          Math.floor(random(s) * 6)
        ];
        p.skills[skill] = clamp(p.skills[skill] + 0.012);
      }
    }
    if (a >= 16 && s.clock.day % 14 === 0 && p.lastMentorDay !== s.clock.day) {
      const skill =
        p.course?.skill ??
        (p.job ? s.jobs.find((j) => j.id === p.job)?.skill : undefined);
      if (skill) {
        const mentor = s.people.find(
          (m) =>
            m.id !== p.id &&
            m.alive &&
            age(s, m) > age(s, p) + 10 &&
            m.skills[skill] > p.skills[skill] + 8,
        );
        if (mentor) {
          p.skills[skill] = clamp(
            p.skills[skill] + 0.3 * mentor.traits.kindness,
          );
          p.lastMentorDay = s.clock.day;
          if (s.clock.day % 120 === 0)
            event(
              s,
              "education",
              `${p.name} تلقى إرشادًا في ${SKILL_NAMES[skill]} من ${mentor.name}`,
              [p.id, mentor.id],
            );
        }
      }
    }
  }
}
