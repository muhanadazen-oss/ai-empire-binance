import type { Civilization, Person, Relationship } from "./types.ts";
import {
  account,
  age,
  balance,
  clamp,
  event,
  nextId,
  random,
} from "./shared.ts";
import { transfer } from "./economy.ts";
import { child } from "./population.ts";
function related(s: Civilization, a: Person, b: Person) {
  function ancestors(p: Person) {
    const ids = new Set([p.id]);
    let todo = [...p.parents];
    while (todo.length) {
      const id = todo.pop()!;
      if (ids.has(id)) continue;
      ids.add(id);
      todo.push(...(s.people.find((p) => p.id === id)?.parents ?? []));
    }
    return ids;
  }
  const aa = ancestors(a),
    bb = ancestors(b);
  return [...aa].some((id) => bb.has(id));
}
function compatible(a: Person, b: Person) {
  return (
    1 -
    (Math.abs(a.traits.kindness - b.traits.kindness) +
      Math.abs(a.traits.sociability - b.traits.sociability) +
      Math.abs(a.traits.diligence - b.traits.diligence)) /
      3
  );
}
function marry(s: Civilization, r: Relationship, a: Person, b: Person) {
  if (
    a.partner ||
    b.partner ||
    a.gender === b.gender ||
    related(s, a, b) ||
    age(s, a) < 18 ||
    age(s, b) < 18 ||
    age(s, a) > 65 ||
    age(s, b) > 65 ||
    r.interactions < 12 ||
    r.affinityA < 78 ||
    r.affinityB < 78 ||
    !a.traits.familyWish ||
    !b.traits.familyWish ||
    balance(s, a) + balance(s, b) < 30000 ||
    balance(s, a) < 2500 ||
    balance(s, b) < 2500
  )
    return;
  const home = s.homes.find(
    (h) => h.capacity >= 4 && h.residents.length === 0 && !h.family,
  );
  if (!home) return;
  const id = nextId(s, "family");
  for (const p of [a, b]) {
    const old = s.homes.find((h) => h.id === p.home);
    if (old) old.residents = old.residents.filter((x) => x !== p.id);
    p.home = home.id;
    p.family = id;
    transfer(s, account(p), "housing", 2000, "تأمين سكن أسرة");
    transfer(s, account(p), "treasury", 500, "تسجيل أسرة");
  }
  a.partner = b.id;
  b.partner = a.id;
  home.residents = [a.id, b.id];
  home.family = id;
  s.families.push({
    id,
    parents: [a.id, b.id],
    children: [],
    marriedDay: s.clock.day,
    home: home.id,
    planning: a.traits.familyWish && b.traits.familyWish,
    nextBirthDay: s.clock.day + 90,
  });
  event(
    s,
    "marriage",
    `زواج ${a.name} و${b.name} بتوافق متبادل وبعد توفر المسكن والميزانية`,
    [a.id, b.id],
  );
}
export function relationshipsDay(s: Civilization) {
  if (s.clock.day % 7 !== 0) return;
  const people = s.people.filter((p) => p.alive);
  for (let i = 0; i < people.length; i++) {
    const a = people[i];
    const candidates = people.filter(
      (b) =>
        b.id !== a.id &&
        Math.abs(age(s, a) - age(s, b)) < 20 &&
        !related(s, a, b),
    );
    if (!candidates.length) continue;
    const b = candidates[Math.floor(random(s) * candidates.length)];
    const ids = [a.id, b.id].sort();
    let r = s.relationships.find((r) => r.a === ids[0] && r.b === ids[1]);
    if (!r) {
      r = {
        a: ids[0],
        b: ids[1],
        affinityA: 10,
        affinityB: 10,
        interactions: 0,
        lastDay: -1,
        friend: false,
      };
      s.relationships.push(r);
      event(s, "social", `${a.name} تعرّف إلى ${b.name} في لقاء مجتمعي`, [
        a.id,
        b.id,
      ]);
    }
    if (r.lastDay === s.clock.day) continue;
    r.lastDay = s.clock.day;
    r.interactions++;
    const match = compatible(a, b);
    r.affinityA = clamp(
      r.affinityA + (match > 0.6 ? 5 + 2 * a.traits.kindness : -1),
    );
    r.affinityB = clamp(
      r.affinityB + (match > 0.6 ? 5 + 2 * b.traits.kindness : -1),
    );
    a.needs.social = clamp(a.needs.social + 9);
    b.needs.social = clamp(b.needs.social + 9);
    if (r.affinityA > 48 && r.affinityB > 48 && !r.friend) {
      r.friend = true;
      event(s, "social", `صداقة جديدة بين ${a.name} و${b.name}`, [a.id, b.id]);
    }
    marry(s, r, a, b);
  }
  for (const f of s.families) {
    if (f.planning && s.clock.day >= f.nextBirthDay && random(s) < 0.24)
      child(s, f.id);
  }
}
