import type { Civilization, Person, Place } from "./types.ts";
import { age } from "./shared.ts";
export interface BehaviorAdapter {
  choose(
    s: Civilization,
    p: Person,
  ): { place: Place; activity: string; goal: string };
}
export class RuleBasedBehavior implements BehaviorAdapter {
  choose(s: Civilization, p: Person) {
    const a = age(s, p),
      hour = s.clock.hour;
    if (!p.alive)
      return {
        place: "home" as Place,
        activity: "ذكرى في شجرة العائلة",
        goal: "سجل حياة محفوظ",
      };
    if (hour < 6 || hour >= 20)
      return {
        place: "home" as Place,
        activity: a < 6 ? "نوم ورعاية أسرية" : "راحة في المنزل",
        goal: "استعادة الراحة",
      };
    if (p.needs.hunger > 65)
      return {
        place: "market" as Place,
        activity: "يبحث عن الطعام",
        goal: "تلبية الاحتياجات",
      };
    if (p.needs.rest < 25)
      return {
        place: "home" as Place,
        activity: "يستريح",
        goal: "العناية بالصحة",
      };
    if (a < 6)
      return {
        place: "home" as Place,
        activity: "يلعب برعاية الأسرة",
        goal: "النمو بأمان",
      };
    if (a < 16)
      return {
        place: s.facilities.find((f) => f.id === "school")?.built
          ? "school"
          : ("home" as Place),
        activity: "يتعلم القراءة والحساب",
        goal: "إكمال التعليم الأساسي",
      };
    if (p.course)
      return {
        place:
          p.course.kind === "university" ? "university" : ("training" as Place),
        activity: "يتعلم ويمارس مع مدرّب",
        goal: "إكمال متطلبات الدورة",
      };
    if (p.retired)
      return {
        place: "park" as Place,
        activity: "يتنزه ويشارك الخبرة",
        goal: "إرشاد الجيل التالي",
      };
    const job = s.jobs.find((j) => j.id === p.job),
      company = s.companies.find((c) => c.id === job?.company);
    if (company && hour < 17)
      return {
        place: company.type as Place,
        activity: `يعمل في ${company.name}`,
        goal: p.goal,
      };
    if (p.needs.social < 65)
      return {
        place: "park" as Place,
        activity: "يتواصل مع الجيران",
        goal: "تكوين صداقات",
      };
    return {
      place: s.facilities.find((f) => f.id === "library")?.built
        ? "library"
        : ("market" as Place),
      activity: p.job ? "يتسوق بعد العمل" : "يبحث عن فرصة ويتعلم",
      goal: p.job ? "تأمين مستقبل الأسرة" : "تحقيق شروط مهنة",
    };
  }
}
export const behavior = new RuleBasedBehavior();
export function behaviorStep(s: Civilization) {
  for (const p of s.people) {
    p.previousPlace = p.place;
    const result = behavior.choose(s, p);
    p.place = result.place;
    p.activity = result.activity;
    p.goal = result.goal;
  }
}
/** A future model adapter must produce a proposal only; engine gates retain authority.
 * No model/API is connected, and skills are numerical simulation progress, not ML training.
 */
export interface FutureModelAdapter extends BehaviorAdapter {
  mode: "proposal-only";
  noExternalMoney: true;
}
