import { useState } from "react";
import {
  Users,
  Heart,
  GraduationCap,
  Briefcase,
  Home,
  Building2,
  ShieldCheck,
  Play,
  Pause,
  Clock,
  ArrowLeft,
  Plus,
  Check,
  Download,
  Lock,
  BookOpen,
  Coins,
  TreePine,
  Activity,
} from "lucide-react";
import type { Civilization, Person, Skill } from "./types";
import { SKILLS } from "./types";
import {
  age,
  stage,
  SKILL_NAMES,
  PLACE_NAMES,
  account,
  balance,
  YEAR_DAYS,
} from "./shared";
import { totalBalances } from "./economy";
import { useCivilization } from "./context";
import {
  api,
  flushSaves,
  session,
  getSession,
  type Session,
} from "../storage/cloud";
import "./society.css";
export const SOCIETY_NAV = [
  { id: "population", label: "السكان", icon: Users },
  { id: "families", label: "العائلات", icon: Heart },
  { id: "familytree", label: "شجرة العائلة", icon: TreePine },
  { id: "education", label: "التعليم", icon: GraduationCap },
  { id: "jobs", label: "الوظائف", icon: Briefcase },
  { id: "companies", label: "الشركات", icon: Building2 },
  { id: "housing", label: "السكن", icon: Home },
  { id: "policies", label: "سياسات المملكة", icon: ShieldCheck },
];
export const civicMoney = (n: number) =>
  (n / 100).toLocaleString("en-US", { maximumFractionDigits: 2 }) + " CC";
export function PersonAvatar({
  person,
  size = 44,
}: {
  person: Person;
  size?: number;
}) {
  const colors = ["#d5b878", "#83c7c5", "#a497d4", "#8ebe9e", "#dba085"];
  const color = colors[person.name.length % 5];
  return (
    <span
      className={`person-avatar ${person.gender === "f" ? "female" : ""}`}
      style={{
        width: size,
        height: size,
        background: `${color}18`,
        borderColor: `${color}60`,
        color,
        fontSize: size * 0.38,
      }}
      aria-label={`Avatar ${person.name}`}
    >
      <svg viewBox="0 0 60 60" aria-hidden="true">
        <path d="M 7 60 Q 9 40 30 42 Q 51 40 53 60" fill={color} />
        {person.gender === "f" && (
          <path d="M 14 42 V 22 Q 14 5 30 5 Q 46 5 46 22 V 42" fill="#30333e" />
        )}
        <ellipse cx="30" cy="25" rx="11" ry="15" fill="#d6b295" />
        <path
          d="M 18 20 Q 13 6 30 6 Q 47 6 42 22 L 35 14 Q 25 21 18 20"
          fill="#333744"
        />
        <path
          d="M 22 25 h 4 M 34 25 h 4 M 26 34 q 4 3 8 0"
          fill="none"
          stroke="#755746"
          strokeWidth="1.5"
        />
        <path
          d="M 25 39 L 30 45 L 35 39 L 41 47 L 30 54 L 19 47 Z"
          fill="#283947"
        />
      </svg>
      <i className={!person.alive ? "past" : person.retired ? "retired" : ""} />
    </span>
  );
}
export function ClockControls() {
  const { civic: s, send, busy, error } = useCivilization();
  if (!s) return <div className="civic-clock">تحميل المجتمع من الخادم…</div>;
  const night = s.clock.hour < 6 || s.clock.hour >= 20;
  return (
    <>
      <div className="civic-clock">
        <div className="civic-time">
          <Clock size={20} />
          <div>
            <b>
              السنة {Math.floor(s.clock.day / YEAR_DAYS) + 1} • اليوم{" "}
              {(s.clock.day % YEAR_DAYS) + 1}
              <small>
                {String(s.clock.hour).padStart(2, "0")}:00 •{" "}
                {night ? "ليل وراحة" : "نهار ونشاط"}
              </small>
            </b>
            <span>
              سنة اللعبة = 120 يومًا افتراضيًا • يوم اللعبة عند 1× ≈ 4 ثوانٍ،
              وليس يومًا حقيقيًا
            </span>
          </div>
        </div>
        <div className="civic-clock-actions">
          <button
            className={`button ${s.clock.running ? "outline" : "gold"}`}
            disabled={busy}
            onClick={() => send({ type: "clock", running: !s.clock.running })}
          >
            {s.clock.running ? <Pause size={15} /> : <Play size={15} />}{" "}
            {s.clock.running ? "إيقاف المجتمع" : "تشغيل المجتمع"}
          </button>
          <div
            className="speed-control"
            role="group"
            aria-label="سرعة زمن المجتمع"
          >
            {([1, 5, 10] as const).map((v) => (
              <button
                key={v}
                disabled={busy}
                aria-pressed={s.clock.speed === v}
                className={s.clock.speed === v ? "active" : ""}
                onClick={() => send({ type: "clock", speed: v })}
              >
                {v}×
              </button>
            ))}
          </div>
        </div>
      </div>
      {error && (
        <div className="civic-error" role="status">
          {error}
        </div>
      )}
    </>
  );
}
export function CivicSummary({
  onNavigate,
}: {
  onNavigate: (id: string) => void;
}) {
  const { civic: s } = useCivilization();
  if (!s) return null;
  return (
    <section className="civic-summary">
      <div className="panel-heading">
        <div>
          <span className="eyebrow">A LIVING CIVILIZATION</span>
          <h3>مملكتك تنبض بالحياة</h3>
        </div>
        <button
          className="text-button"
          onClick={() => onNavigate("population")}
        >
          استكشف السكان <ArrowLeft size={15} />
        </button>
      </div>
      <div className="civic-overview">
        <button onClick={() => onNavigate("population")}>
          <Users />
          <b>
            {s.people.filter((p) => p.alive).length}
            <small>سكان / حد {s.policy.populationCap}</small>
          </b>
        </button>
        <button onClick={() => onNavigate("families")}>
          <Heart />
          <b>
            {s.families.length}
            <small>
              عائلات • {s.people.filter((p) => p.parents.length).length} أطفال
              عبر الأجيال
            </small>
          </b>
        </button>
        <button onClick={() => onNavigate("education")}>
          <GraduationCap />
          <b>
            {
              s.people.filter(
                (p) => p.course || (age(s, p) >= 6 && age(s, p) < 16),
              ).length
            }
            <small>يتعلمون ويتدربون</small>
          </b>
        </button>
        <button onClick={() => onNavigate("policies")}>
          <Coins />
          <b>
            {civicMoney(balance(s, "treasury"))}
            <small>خزينة حضارية افتراضية مستقلة</small>
          </b>
        </button>
      </div>
      <div className="civic-news">
        {s.events
          .slice(-2)
          .reverse()
          .map((e) => (
            <p key={e.id}>
              <span className="live-dot" />
              {e.text}
              <small>اليوم {e.day}</small>
            </p>
          ))}
      </div>
    </section>
  );
}
export function PersonDetails({
  personId,
  onPerson,
}: {
  personId: string;
  onPerson: (id: string) => void;
}) {
  const { civic: s } = useCivilization();
  if (!s) return null;
  const p = s.people.find((p) => p.id === personId);
  if (!p) return <p>الشخصية غير متاحة</p>;
  const family = s.families.find((f) => f.id === p.family),
    job = s.jobs.find((j) => j.id === p.job);
  return (
    <>
      <div className="person-profile">
        <PersonAvatar person={p} size={88} />
        <div>
          <h2>{p.name}</h2>
          <p>
            {age(s, p)} سنة افتراضية • {stage(s, p)} • الجيل {p.generation}
          </p>
          <span className="tiny-badge">
            {PLACE_NAMES[p.place]} • {p.activity}
          </span>
        </div>
      </div>
      <div className="person-facts">
        <div>
          <small>هدف قصير</small>
          <b>{p.goal}</b>
        </div>
        <div>
          <small>هدف طويل</small>
          <b>{p.longGoal}</b>
        </div>
        <div>
          <small>الرصيد الافتراضي</small>
          <b>{civicMoney(balance(s, p))}</b>
        </div>
        <div>
          <small>المهنة</small>
          <b>{job?.title ?? (p.retired ? "متقاعد" : "لا وظيفة")}</b>
        </div>
      </div>
      <h3>الاحتياجات</h3>
      <div className="needs-grid">
        {(
          [
            { key: "health", name: "الصحة" },
            { key: "rest", name: "الراحة" },
            { key: "hunger", name: "الشبع" },
            { key: "social", name: "التواصل" },
          ] as const
        ).map((n) => (
          <div key={n.key}>
            <span>
              {n.name}{" "}
              {Math.round(
                n.key === "hunger" ? 100 - p.needs.hunger : p.needs[n.key],
              )}
              %
            </span>
            <div className="progress">
              <i
                style={{
                  width: `${n.key === "hunger" ? 100 - p.needs.hunger : p.needs[n.key]}%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
      <h3>الصفات والمهارات</h3>
      <div className="traits">
        <span>اجتماعي {Math.round(p.traits.sociability * 100)}%</span>
        <span>مجتهد {Math.round(p.traits.diligence * 100)}%</span>
        <span>مبدع {Math.round(p.traits.creativity * 100)}%</span>
        <span>لطيف {Math.round(p.traits.kindness * 100)}%</span>
      </div>
      <p className="muted small">
        القراءة {p.literacy.toFixed(1)}/100 • {p.schoolDays} يوم مدرسة •{" "}
        {p.trainingDays} يوم تدريب. المهارات نقاط محاكاة وليست تعلم نموذج AI.
      </p>
      <div className="skill-list">
        {SKILLS.map((k) => (
          <div key={k}>
            <span>{SKILL_NAMES[k]}</span>
            <div className="progress">
              <i style={{ width: `${p.skills[k]}%` }} />
            </div>
            <b>{p.skills[k].toFixed(1)}</b>
          </div>
        ))}
      </div>
      {p.course && (
        <p className="section-note">
          <GraduationCap />
          دورة {SKILL_NAMES[p.course.skill]}: {p.course.progress}/
          {p.course.required} أيام دراسية فعلية
        </p>
      )}
      <h3>العائلة والعلاقات</h3>
      <div className="person-relations">
        {[
          ...p.parents,
          ...(p.partner ? [p.partner] : []),
          ...(family?.parents.includes(p.id) ? family.children : []),
        ].map((id) => {
          const q = s.people.find((q) => q.id === id)!;
          return (
            <button
              className="button outline"
              key={id}
              onClick={() => onPerson(id)}
            >
              <PersonAvatar person={q} size={25} />
              {p.parents.includes(id)
                ? "والد/والدة"
                : id === p.partner
                  ? "شريك/شريكة"
                  : "ابن/ابنة"}
              : {q.name}
            </button>
          );
        })}
        {!p.parents.length && !p.partner && (
          <p className="muted">
            لا عائلة مسجلة بعد؛ تنمو العلاقات من التفاعل والتوافق.
          </p>
        )}
      </div>
      <div className="friend-list">
        {s.relationships
          .filter((r) => r.friend && (r.a === p.id || r.b === p.id))
          .map((r) => {
            const q = s.people.find(
              (q) => q.id === (r.a === p.id ? r.b : r.a),
            )!;
            return (
              <button
                key={q.id}
                className="text-button"
                onClick={() => onPerson(q.id)}
              >
                صديق: {q.name} • توافق{" "}
                {Math.round((r.affinityA + r.affinityB) / 2)}%
              </button>
            );
          })}
      </div>
      <h3>ذاكرة الحياة</h3>
      <div className="person-memory">
        {p.memory.map((m, i) => (
          <div key={`${m.day}-${i}`}>
            <small>اليوم {m.day}</small>
            <p>{m.text}</p>
          </div>
        ))}
        {!p.memory.length && <p className="muted">لا أحداث مهمة بعد.</p>}
      </div>
    </>
  );
}
function FamilyTree({
  s,
  family,
  onPerson,
}: {
  s: Civilization;
  family: string;
  onPerson: (id: string) => void;
}) {
  const f = s.families.find((f) => f.id === family);
  if (!f)
    return <div className="empty">تظهر شجرة الأجيال عند تأسيس أول أسرة.</div>;
  return (
    <div className="family-tree">
      <div className="tree-parents">
        {f.parents.map((id) => {
          const p = s.people.find((p) => p.id === id)!;
          return (
            <button key={id} onClick={() => onPerson(id)}>
              <PersonAvatar person={p} size={55} />
              <b>{p.name}</b>
              <small>
                {age(s, p)} سنة • الجيل {p.generation}
              </small>
            </button>
          );
        })}
      </div>
      <div className="tree-union">
        <Heart size={17} />
        <span>تأسست الأسرة يوم {f.marriedDay}</span>
      </div>
      <div className="tree-children">
        {f.children.map((id) => {
          const p = s.people.find((p) => p.id === id)!;
          const family = s.families.find((g) => g.parents.includes(id));
          return (
            <div key={id}>
              <button onClick={() => onPerson(id)}>
                <PersonAvatar person={p} size={45} />
                <b>{p.name}</b>
                <small>
                  {age(s, p)} سنة • {stage(s, p)}
                </small>
                <small>الجيل {p.generation}</small>
              </button>
              {family &&
                family.children.map((child) => {
                  const q = s.people.find((p) => p.id === child)!;
                  return (
                    <button
                      key={child}
                      className="tree-grandchild"
                      onClick={() => onPerson(child)}
                    >
                      <PersonAvatar person={q} size={32} />
                      {q.name}
                      <small>الجيل {q.generation}</small>
                    </button>
                  );
                })}
            </div>
          );
        })}
        {!f.children.length && (
          <p className="muted">
            لا أطفال بعد. الإنجاب اختياري ويتطلب موافقة ومسكنًا وميزانية.
          </p>
        )}
      </div>
    </div>
  );
}
function PolicyForm({ s }: { s: Civilization }) {
  const { send, busy } = useCivilization();
  const [draft, setDraft] = useState(s.policy);
  return (
    <>
      <div className="policy-grid">
        {(
          [
            {
              key: "populationCap",
              name: "الحد الأولي للسكان",
              min: Math.max(10, s.people.filter((p) => p.alive).length),
              max: 80,
              scale: 1,
            },
            {
              key: "educationBudget",
              name: "ميزانية التعليم لكل يوم لعبة (CC)",
              min: 0,
              max: 200,
              scale: 100,
            },
            {
              key: "welfareBudget",
              name: "دعم المعيشة لكل يوم لعبة (CC)",
              min: 0,
              max: 200,
              scale: 100,
            },
            {
              key: "taxPct",
              name: "ضريبة الرواتب %",
              min: 0,
              max: 30,
              scale: 1,
            },
            {
              key: "retirementAge",
              name: "سن التقاعد الافتراضي",
              min: 55,
              max: 75,
              scale: 1,
            },
          ] as const
        ).map((f) => (
          <label key={f.key}>
            <span>{f.name}</span>
            <input
              type="number"
              aria-label={f.name}
              min={f.min}
              max={f.max}
              value={draft[f.key] / f.scale}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  [f.key]: Math.round(Number(e.target.value) * f.scale),
                })
              }
            />
          </label>
        ))}
      </div>
      <label className="checkbox-line">
        <input
          type="checkbox"
          checked={draft.birthsAllowed}
          onChange={(e) =>
            setDraft({ ...draft, birthsAllowed: e.target.checked })
          }
        />{" "}
        السماح بتخطيط الأسر للإنجاب • يظل اختياريًا وتحت شروط السكن والموافقة
      </label>
      <button
        className="button gold"
        disabled={busy}
        onClick={() => send({ type: "policy", values: draft })}
      >
        <Check size={16} />
        حفظ سياسات المملكة
      </button>
    </>
  );
}
export function AccountPanel({ onLinked, returnTo = "wallet" }: { onLinked?: () => void; returnTo?: "wallet" | "city" } = {}) {
  const [mode, setMode] = useState<"register" | "login">("login"),
    [email, setEmail] = useState(""),
    [name, setName] = useState(""),
    [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const user = session?.user;
  async function auth() {
    setBusy(true);
    setError("");
    try {
      await flushSaves();
      await api(`/api/auth/${mode}`, { email, name, password });
      if (onLinked) history.replaceState(null, "", "#" + returnTo);
      location.reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setBusy(false);
    }
  }
  return (
    <div className="account-panel">
      <div className="section-note">
        <ShieldCheck />
        حساب خاص لمملكتك ومحفظتك.{" "}
        {user?.email
          ? "تستطيع تسجيل الدخول إليه من أجهزتك."
          : "استخدم بريدك وكلمة مرور حساب اللعبة."}
      </div>
      {user?.email ? (
        <>
          <h3>{user.name}</h3>
          <p className="muted">{user.email}</p>
          {onLinked && <button className="button gold" onClick={onLinked}>متابعة إلى المحفظة</button>}
          <button
            className="button outline"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await flushSaves();
                await api("/api/auth/logout", {});
                location.reload();
              } catch (e) {
                setError(String(e));
                setBusy(false);
              }
            }}
          >
            تسجيل الخروج
          </button>
        </>
      ) : (
        <>
          <div className="toolbar">
            <button
              className={`button ${mode === "register" ? "gold" : "outline"}`}
              onClick={() => { setMode("register"); setError(""); }}
            >
              إنشاء حساب جديد
            </button>
            <button
              className={`button ${mode === "login" ? "gold" : "outline"}`}
              onClick={() => { setMode("login"); setError(""); }}
            >
              تسجيل الدخول
            </button>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              auth();
            }}
          >
            {mode === "register" && (
              <label>
                اسم المؤسس
                <input
                  required
                  minLength={2}
                  maxLength={40}
                  placeholder="اسمك"
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </label>
            )}
            <label>
              البريد الإلكتروني
              <input
                required
                type="email"
                dir="ltr"
                placeholder="name@example.com"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <label>
              كلمة المرور
              <input
                required
                type="password"
                placeholder="10 أحرف على الأقل"
                minLength={10}
                maxLength={128}
                autoComplete={
                  mode === "register" ? "new-password" : "current-password"
                }
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </label>
            <button className="button gold" disabled={busy}>
              {busy
                ? "جاري التحقق…"
                : mode === "register"
                  ? "إنشاء حساب"
                  : "تسجيل الدخول"}
            </button>
          </form>
        </>
      )}
      {error && <p className="civic-error" role="alert">{error}</p>}
      <p className="muted small">
        استعادة كلمة المرور بالبريد ليست مفعّلة في النسخة الأولى. احتفظ بكلمة
        مرور الحساب.
      </p>
    </div>
  );
}
export function Society({
  view,
  onPerson,
}: {
  view: string;
  onPerson: (id: string) => void;
}) {
  const { civic: s, send, busy } = useCivilization();
  const [filter, setFilter] = useState(""),
    [familyId, setFamilyId] = useState(""),
    [coursePerson, setCoursePerson] = useState(""),
    [skill, setSkill] = useState<Skill>("industry"),
    [kind, setKind] = useState<"training" | "university">("training"),
    [company, setCompany] = useState("farm"),
    [salary, setSalary] = useState(4),
    [required, setRequired] = useState(8),
    [founder, setFounder] = useState("p1"),
    [companyName, setCompanyName] = useState(""),
    [companyType, setCompanyType] = useState<"farm" | "factory" | "studio">(
      "farm",
    ),
    [support, setSupport] = useState("p1"),
    [grant, setGrant] = useState(50),
    [exportError, setExportError] = useState("");
  if (!s) return <div className="empty">تحميل المجتمع…</div>;
  const currentFamily = familyId || s.families[0]?.id;
  const personClick = (id: string) => onPerson(id);
  const accountName = (key: string) =>
    key.startsWith("person:")
      ? (s.people.find((p) => account(p) === key)?.name ?? key)
      : key.startsWith("company:")
        ? (s.companies.find((c) => `company:${c.id}` === key)?.name ?? key)
        : ({
            treasury: "خزينة المملكة",
            market: "السوق",
            housing: "إدارة السكن",
            education: "التعليم",
            construction: "البناء",
          }[key] ?? key);
  return (
    <>
      <div className="page-heading">
        <span className="eyebrow">AI EMPIRE / GENERATIONS</span>
        <h1>{SOCIETY_NAV.find((n) => n.id === view)?.label}</h1>
        <p>
          شخصيات افتراضية بقواعد محاكاة وذاكرة محفوظة • الأموال افتراضية والعمل
          يحتاج عمرًا ومهارة.
        </p>
      </div>
      <ClockControls />
      <section className="content-panel society-panel">
        {view === "population" && (
          <>
            <div className="toolbar">
              <input
                aria-label="بحث عن ساكن"
                placeholder="ابحث عن شخصية أو نشاط…"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              />
              <span className="tiny-badge">
                {s.people.filter((p) => p.alive).length} /{" "}
                {s.policy.populationCap} سكان
              </span>
            </div>
            <div className="citizen-grid">
              {s.people
                .filter((p) => `${p.name} ${p.activity}`.includes(filter))
                .map((p) => (
                  <button
                    className="citizen-card"
                    key={p.id}
                    onClick={() => onPerson(p.id)}
                  >
                    <div>
                      <PersonAvatar person={p} size={54} />
                      <span className="tiny-badge">الجيل {p.generation}</span>
                    </div>
                    <h3>{p.name}</h3>
                    <p>
                      {age(s, p)} سنة • {stage(s, p)}
                    </p>
                    <div className="citizen-activity">
                      <span className="live-dot" />
                      {p.activity}
                    </div>
                    <footer>
                      <span>{PLACE_NAMES[p.place]}</span>
                      <b>{civicMoney(balance(s, p))}</b>
                    </footer>
                  </button>
                ))}
            </div>
          </>
        )}
        {(view === "families" || view === "familytree") && (
          <>
            {s.families.length > 0 ? (
              <>
                <div className="toolbar">
                  <select
                    aria-label="اختيار الأسرة"
                    value={currentFamily}
                    onChange={(e) => setFamilyId(e.target.value)}
                  >
                    {s.families.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.parents
                          .map(
                            (id) =>
                              s.people
                                .find((p) => p.id === id)!
                                .name.split(" ")[0],
                          )
                          .join(" و ")}
                      </option>
                    ))}
                  </select>
                  <span className="tiny-badge">{s.families.length} أسرة</span>
                </div>
                <FamilyTree
                  s={s}
                  family={currentFamily}
                  onPerson={personClick}
                />
                {view === "families" &&
                  s.families
                    .filter((f) => f.id === currentFamily)
                    .map((f) => (
                      <div className="family-planning" key={f.id}>
                        <p>
                          المسكن: {s.homes.find((h) => h.id === f.home)?.name} •{" "}
                          {f.children.length} أطفال • الأبوان يرغبان وفق
                          صفاتهما.
                        </p>
                        <label className="checkbox-line">
                          <input
                            type="checkbox"
                            disabled={busy}
                            checked={f.planning}
                            onChange={(e) =>
                              send({
                                type: "planning",
                                family: f.id,
                                enabled: e.target.checked,
                              })
                            }
                          />{" "}
                          تخطيط الأسرة لطفل عند توفر الشروط
                        </label>
                        <small>
                          آخر حد للتعداد {s.policy.populationCap} • لا يزيد
                          الإنجاب على طفلين للأسرة في النسخة الأولى • الأطفال
                          يبدأون دون مهنة.
                        </small>
                      </div>
                    ))}
              </>
            ) : (
              <div className="empty">
                <Heart size={32} />
                <p>
                  لم تتأسس أسر بعد. شغّل المجتمع ليتعارف البالغون؛ الزواج يحتاج
                  توافقًا متبادلًا ومسكنًا وميزانية، ويستغرق عدة أشهر افتراضية.
                </p>
              </div>
            )}
            <h3>العلاقات التي تنمو الآن</h3>
            <div className="relationship-list">
              {[...s.relationships]
                .sort((a, b) => b.interactions - a.interactions)
                .slice(0, 30)
                .map((r) => (
                  <div key={`${r.a}-${r.b}`}>
                    <span>
                      {s.people.find((p) => p.id === r.a)!.name} ↔{" "}
                      {s.people.find((p) => p.id === r.b)!.name}
                    </span>
                    <div className="progress">
                      <i
                        style={{ width: `${(r.affinityA + r.affinityB) / 2}%` }}
                      />
                    </div>
                    <small>
                      {r.interactions} لقاء • {r.friend ? "صداقة" : "تعارف"} •
                      توافق متبادل {Math.round(r.affinityA)}% /{" "}
                      {Math.round(r.affinityB)}%
                    </small>
                  </div>
                ))}
            </div>
          </>
        )}
        {view === "education" && (
          <>
            <div className="service-grid">
              {s.facilities
                .filter((f) =>
                  ["school", "library", "training", "university"].includes(
                    f.id,
                  ),
                )
                .map((f) => (
                  <div className="service-card" key={f.id}>
                    <GraduationCap />
                    <h3>{f.name}</h3>
                    <p>
                      {f.built
                        ? `${f.capacity} مقعدًا • خدمة فعّالة`
                        : `تكلفة الإنشاء ${civicMoney(f.cost)}`}
                    </p>
                    {f.built ? (
                      <span className="status-badge online">مبني</span>
                    ) : (
                      <button
                        className="button gold"
                        disabled={busy || balance(s, "treasury") < f.cost}
                        onClick={() => send({ type: "build", facility: f.id })}
                      >
                        <Plus size={15} />
                        بناء الخدمة
                      </button>
                    )}
                  </div>
                ))}
            </div>
            <div className="section-note">
              <BookOpen />
              المدرسة من عمر 6–15. التدريب من 16 وبعد قراءة 25. الجامعة من 18
              وبعد قراءة 40 ومهارة 12. التدريب 60 يومًا، والجامعة 120 يومًا،
              وتُدفع الرسوم يومًا بيوم من المنحة أو رصيد الشخصية.
            </div>
            <div className="proposal-form">
              <select
                aria-label="شخصية للتعليم"
                value={coursePerson}
                onChange={(e) => setCoursePerson(e.target.value)}
              >
                <option value="">اختر شخصية</option>
                {s.people
                  .filter((p) => p.alive)
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} • {age(s, p)} سنة
                    </option>
                  ))}
              </select>
              <select
                aria-label="مهارة التعليم"
                value={skill}
                onChange={(e) => setSkill(e.target.value as Skill)}
              >
                {SKILLS.map((k) => (
                  <option key={k} value={k}>
                    {SKILL_NAMES[k]}
                  </option>
                ))}
              </select>
              <select
                aria-label="نوع التعليم"
                value={kind}
                onChange={(e) => setKind(e.target.value as typeof kind)}
              >
                <option value="training">تدريب مهني</option>
                <option value="university">جامعة</option>
              </select>
              <button
                className="button gold"
                disabled={!coursePerson || busy}
                onClick={() =>
                  send({ type: "enroll", person: coursePerson, skill, kind })
                }
              >
                طلب قبول
              </button>
            </div>
            <h3>الطلاب والمتدربون</h3>
            {s.people
              .filter((p) => p.course || (age(s, p) >= 6 && age(s, p) < 16))
              .map((p) => (
                <button
                  key={p.id}
                  className="education-student"
                  onClick={() => onPerson(p.id)}
                >
                  <PersonAvatar person={p} />
                  <b>
                    {p.name}
                    <small>
                      {p.course ? SKILL_NAMES[p.course.skill] : "تعليم أساسي"}
                    </small>
                  </b>
                  <span>
                    {p.course
                      ? `${p.course.progress}/${p.course.required} يوم`
                      : `${p.schoolDays} يوم مدرسة`}
                  </span>
                  <span>قراءة {p.literacy.toFixed(1)}</span>
                </button>
              ))}
          </>
        )}
        {view === "jobs" && (
          <>
            <div className="section-note">
              <Briefcase />
              القبول تلقائي للبالغين بعد تحقق المهارة. الوظيفة تدفع من حساب
              الشركة وقد يتأخر الراتب عند نفاد السيولة؛ لا يعمل الأطفال.
            </div>
            <div className="civic-form">
              <h3>إنشاء وظيفة حقيقية داخل المحاكاة</h3>
              <label>
                الشركة
                <select
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                >
                  {s.companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                المهارة
                <select
                  value={skill}
                  onChange={(e) => setSkill(e.target.value as Skill)}
                >
                  {SKILLS.map((k) => (
                    <option key={k} value={k}>
                      {SKILL_NAMES[k]}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                الحد المطلوب
                <input
                  aria-label="مهارة الوظيفة المطلوبة"
                  type="number"
                  min={1}
                  max={80}
                  value={required}
                  onChange={(e) => setRequired(Number(e.target.value))}
                />
              </label>
              <label>
                راتب يومي CC
                <input
                  aria-label="راتب الوظيفة"
                  type="number"
                  min={1}
                  max={30}
                  step={0.5}
                  value={salary}
                  onChange={(e) => setSalary(Number(e.target.value))}
                />
              </label>
              <button
                className="button gold"
                disabled={busy}
                onClick={() =>
                  send({
                    type: "job",
                    company,
                    skill,
                    salary: Math.round(salary * 100),
                    required,
                  })
                }
              >
                <Plus size={15} /> إنشاء الوظيفة
              </button>
            </div>
            <div className="job-list">
              {s.jobs.map((j) => (
                <div key={j.id}>
                  <Briefcase size={18} />
                  <div>
                    <b>{j.title}</b>
                    <p>
                      {s.companies.find((c) => c.id === j.company)?.name} • شرط{" "}
                      {SKILL_NAMES[j.skill]} ≥ {j.required}
                    </p>
                  </div>
                  <span>{civicMoney(j.salary)} / يوم</span>
                  {j.worker ? (
                    <button
                      className="text-button"
                      onClick={() => onPerson(j.worker!)}
                    >
                      {s.people.find((p) => p.id === j.worker)?.name}
                    </button>
                  ) : (
                    <span className="tiny-badge">شاغرة</span>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
        {view === "companies" && (
          <>
            <div className="service-grid">
              {s.companies.map((c) => (
                <div className="service-card" key={c.id}>
                  <Building2 />
                  <h3>{c.name}</h3>
                  <p>رصيد {civicMoney(balance(s, `company:${c.id}`))}</p>
                  <p>
                    إنتاج {c.produced} • مخزون {c.inventory} • سعر بيع{" "}
                    {civicMoney(c.price)}
                  </p>
                  {c.owner && (
                    <button
                      className="text-button"
                      onClick={() => onPerson(c.owner!)}
                    >
                      المدير {s.people.find((p) => p.id === c.owner)?.name}
                    </button>
                  )}
                  {c.successor && (
                    <span className="tiny-badge">انتقلت للجيل التالي</span>
                  )}
                </div>
              ))}
            </div>
            <div className="civic-form">
              <h3>شركة عائلية جديدة</h3>
              <label>
                الاسم
                <input
                  aria-label="اسم الشركة"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  maxLength={50}
                />
              </label>
              <label>
                المؤسس
                <select
                  value={founder}
                  onChange={(e) => setFounder(e.target.value)}
                >
                  {s.people
                    .filter((p) => p.alive && age(s, p) >= 18)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                </select>
              </label>
              <label>
                النشاط
                <select
                  value={companyType}
                  onChange={(e) =>
                    setCompanyType(e.target.value as typeof companyType)
                  }
                >
                  <option value="farm">زراعة</option>
                  <option value="factory">صناعة</option>
                  <option value="studio">برمجة وخدمات</option>
                </select>
              </label>
              <p>
                تحتاج إدارة 8 وتمويل 500 CC من حساب المؤسس، ثم إنشاء وظائف لتبدأ
                الإنتاج.
              </p>
              <button
                className="button gold"
                disabled={busy || companyName.trim().length < 2}
                onClick={() =>
                  send({
                    type: "company",
                    name: companyName,
                    person: founder,
                    kind: companyType,
                  })
                }
              >
                تأسيس الشركة
              </button>
            </div>
          </>
        )}
        {view === "housing" && (
          <>
            <div className="toolbar">
              <span className="muted">
                {s.homes.length} مساكن •{" "}
                {s.homes.filter((h) => !h.residents.length).length} متاحة
              </span>
              <button
                className="button gold"
                disabled={busy || balance(s, "treasury") < 90000}
                onClick={() => send({ type: "home" })}
              >
                <Plus size={15} />
                بناء مسكن • 900 CC
              </button>
            </div>
            <div className="housing-grid">
              {s.homes.map((h) => (
                <div key={h.id}>
                  <Home />
                  <h3>{h.name}</h3>
                  <span>
                    {h.residents.length} / {h.capacity} سكان • إيجار{" "}
                    {civicMoney(h.rent)} / يوم
                  </span>
                  <div>
                    {h.residents.map((id) => (
                      <button
                        className="text-button"
                        key={id}
                        onClick={() => onPerson(id)}
                      >
                        {s.people.find((p) => p.id === id)!.name}
                      </button>
                    ))}
                  </div>
                  {!h.residents.length && (
                    <p className="positive">متاح لأسرة جديدة</p>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
        {view === "policies" && (
          <>
            <div className="section-note">
              <Coins />
              عملة المجتمع CC افتراضية، مستقلة عن دولارات التداول التجريبية.
              التحويل بين الاقتصادين مقفول. كل مبلغ له مصدر ووجهة، ولا تُضاف
              أموال أثناء التشغيل.
            </div>
            <div className="report-grid">
              <div>
                <span>خزينة المجتمع</span>
                <b>{civicMoney(balance(s, "treasury"))}</b>
              </div>
              <div>
                <span>مجموع الأرصدة • يطابق رأس المال</span>
                <b
                  className={
                    totalBalances(s) === s.totalMoney ? "positive" : "negative"
                  }
                >
                  {civicMoney(totalBalances(s))}
                </b>
              </div>
              <div>
                <span>سعر الغذاء • عرض وطلب</span>
                <b>{civicMoney(s.market.price)}</b>
              </div>
              <div>
                <span>مخزون السوق</span>
                <b>{s.market.stock} وحدة</b>
              </div>
            </div>
            <PolicyForm s={s} />
            <div className="civic-form">
              <h3>دعم شخصية أو أسرة من الخزينة</h3>
              <label>
                المستفيد
                <select
                  value={support}
                  onChange={(e) => setSupport(e.target.value)}
                >
                  {s.people
                    .filter((p) => p.alive)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                </select>
              </label>
              <label>
                المبلغ CC
                <input
                  type="number"
                  aria-label="مبلغ الدعم"
                  min={1}
                  max={1000}
                  value={grant}
                  onChange={(e) => setGrant(Number(e.target.value))}
                />
              </label>
              <button
                className="button outline"
                disabled={busy}
                onClick={() =>
                  send({
                    type: "support",
                    person: support,
                    amount: Math.round(grant * 100),
                  })
                }
              >
                صرف الدعم وتسجيل مصدره
              </button>
            </div>
            <h3>دفتر التحويلات</h3>
            <div className="ledger-list">
              {s.ledger
                .slice(-60)
                .reverse()
                .map((t) => (
                  <div key={t.id}>
                    <small>يوم {t.day}</small>
                    <div>
                      <b>
                        من {accountName(t.from)} إلى {accountName(t.to)}
                      </b>
                      <p>{t.reason}</p>
                    </div>
                    <span>{civicMoney(t.amount)}</span>
                  </div>
                ))}
            </div>
            <button
              className="button outline"
              onClick={async () => {
                try {
                  setExportError("");
                  const data = await api("/api/civilization/export");
                  const a = document.createElement("a");
                  a.href = URL.createObjectURL(
                    new Blob([JSON.stringify(data, null, 2)], {
                      type: "application/json",
                    }),
                  );
                  a.download = "ai-empire-civilization.json";
                  a.click();
                  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
                } catch (e) {
                  setExportError(String(e));
                }
              }}
            >
              <Download size={16} />
              تصدير السجل الخادمي الكامل
            </button>
            {exportError && <p className="civic-error">{exportError}</p>}
          </>
        )}
      </section>
    </>
  );
}
