import type { Civilization } from "./types.ts";
import { populationDay } from "./population.ts";
import { educationDay } from "./education.ts";
import { relationshipsDay } from "./relationships.ts";
import { economyDay } from "./economy.ts";
import { behaviorStep } from "./behavior.ts";
export function oneDay(s: Civilization) {
  s.clock.day++;
  populationDay(s);
  educationDay(s);
  relationshipsDay(s);
  economyDay(s);
  behaviorStep(s);
}
export function advanceDays(state: Civilization, days: number) {
  const s = structuredClone(state);
  for (let i = 0; i < days; i++) {
    oneDay(s);
    s.ledger = s.ledger.slice(-350);
    s.events = s.events.slice(-400);
  }
  return s;
}
export function clockTick(state: Civilization) {
  const s = structuredClone(state);
  if (!s.clock.running) return s;
  const hours = s.clock.hour + 6 * s.clock.speed,
    days = Math.floor(hours / 24);
  s.clock.hour = hours % 24;
  for (let i = 0; i < days; i++) oneDay(s);
  behaviorStep(s);
  return s;
}
