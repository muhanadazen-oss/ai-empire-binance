import { useState } from "react";
import { Sun, Moon } from "lucide-react";
import type { Civilization, Place } from "../civilization/types";
import { age } from "../civilization/shared";
import type { GameState } from "../engine/types";
import { levelOf } from "../engine/game";
export const BUILDINGS = [
  {
    id: "palace",
    name: "القصر الرئيسي",
    sub: "مجلس المملكة",
    u: 0,
    v: 0,
    h: 100,
    color: "#e2c28b",
  },
  {
    id: "bank",
    name: "البنك",
    sub: "رأس المال والأرصدة",
    u: -5,
    v: 0,
    h: 60,
    color: "#dfc189",
  },
  {
    id: "trading",
    name: "مركز التداول",
    sub: "الصفقات والاستراتيجيات",
    u: -3,
    v: 5,
    h: 111,
    color: "#99b9ce",
  },
  {
    id: "analysis",
    name: "مركز التحليل",
    sub: "رصد الفرص",
    u: 4,
    v: -5,
    h: 126,
    color: "#89c5d5",
  },
  {
    id: "risk",
    name: "إدارة المخاطر",
    sub: "درع المملكة",
    u: 5,
    v: 0,
    h: 62,
    color: "#9bc4aa",
  },
  {
    id: "vault",
    name: "الخزنة",
    sub: "الحفظ والتقدم",
    u: 0,
    v: 5,
    h: 47,
    color: "#d1baa0",
  },
  {
    id: "market",
    name: "السوق",
    sub: "الأسعار التجريبية",
    u: -6,
    v: -3,
    h: 40,
    color: "#d9aa82",
  },
  {
    id: "operations",
    name: "مركز العمليات",
    sub: "سجل النشاط والتقارير",
    u: 0,
    v: -6,
    h: 96,
    color: "#abb8cc",
  },
];
const p = (u: number, v: number, z = 0) => [
  520 + (u - v) * 31,
  326 + (u + v) * 16 - z,
];
const points = (v: number[][]) => v.map((a) => a.join(",")).join(" ");
function Quad({
  u,
  v,
  w = 1,
  d = w,
  z = 0,
  fill,
  stroke,
  opacity = 1,
}: {
  u: number;
  v: number;
  w?: number;
  d?: number;
  z?: number;
  fill: string;
  stroke?: string;
  opacity?: number;
}) {
  return (
    <polygon
      points={points([
        p(u - w / 2, v - d / 2, z),
        p(u + w / 2, v - d / 2, z),
        p(u + w / 2, v + d / 2, z),
        p(u - w / 2, v + d / 2, z),
      ])}
      fill={fill}
      stroke={stroke}
      strokeWidth=".6"
      opacity={opacity}
    />
  );
}
function Structure({
  u,
  v,
  w = 1.5,
  d = w,
  h = 50,
  z = 0,
  material = "glass",
  windows = true,
  columns = 5,
}: {
  u: number;
  v: number;
  w?: number;
  d?: number;
  h?: number;
  z?: number;
  material?: string;
  windows?: boolean;
  columns?: number;
}) {
  const a = p(u - w / 2, v - d / 2, z),
    b = p(u + w / 2, v - d / 2, z),
    c = p(u + w / 2, v + d / 2, z),
    e = p(u - w / 2, v + d / 2, z),
    top = [a, b, c, e].map(([x, y]) => [x, y - h]);
  const glass = material === "glass";
  return (
    <g>
      <polygon
        points={points([top[3], top[2], c, e])}
        fill={`url(#${material}-front)`}
        stroke={glass ? "#7394a6" : "#80746b"}
        strokeOpacity=".28"
        strokeWidth=".5"
      />
      <polygon
        points={points([top[2], top[1], b, c])}
        fill={`url(#${material}-side)`}
        stroke="#5c7080"
        strokeOpacity=".3"
        strokeWidth=".5"
      />
      <polygon
        points={points(top)}
        fill={`url(#${material}-roof)`}
        stroke="#b9c6c5"
        strokeOpacity=".28"
        strokeWidth=".65"
      />
      {windows &&
        Array.from(
          { length: Math.max(1, Math.floor((h - 7) / 11)) },
          (_, row) =>
            Array.from({ length: columns }, (_, col) => {
              const t = (col + 0.5) / columns,
                slot = glass ? 5 : 3.8,
                cy = h - 8 - row * 11,
                lit = (row * 3 + col * 7 + Math.floor(u * 2)) % 5 !== 0;
              return (
                <g key={`${row}-${col}`} opacity={lit ? 0.95 : 0.55}>
                  <line
                    x1={e[0] + (c[0] - e[0]) * t}
                    y1={e[1] + (c[1] - e[1]) * t - cy}
                    x2={e[0] + (c[0] - e[0]) * t + slot}
                    y2={e[1] + (c[1] - e[1]) * t - cy + slot * 0.516}
                    stroke={lit ? "url(#window-light)" : "#334658"}
                    strokeWidth={glass ? "4.5" : "5.5"}
                  />
                  <line
                    x1={c[0] + (b[0] - c[0]) * t}
                    y1={c[1] + (b[1] - c[1]) * t - cy}
                    x2={c[0] + (b[0] - c[0]) * t + slot}
                    y2={c[1] + (b[1] - c[1]) * t - cy - slot * 0.516}
                    stroke={lit ? "url(#window-light)" : "#294153"}
                    strokeWidth={glass ? "4" : "5"}
                  />
                </g>
              );
            }),
        )}
      {glass &&
        Array.from({ length: Math.floor(h / 11) }, (_, i) => (
          <polyline
            key={i}
            points={points([
              [e[0], e[1] - h + 3 + i * 11],
              [c[0], c[1] - h + 3 + i * 11],
              [b[0], b[1] - h + 3 + i * 11],
            ])}
            fill="none"
            stroke="#c0d2d7"
            strokeOpacity=".22"
            strokeWidth=".7"
          />
        ))}
      {glass &&
        [0.25, 0.5, 0.75].map((f) => (
          <g key={f}>
            <line
              x1={e[0] + (c[0] - e[0]) * f}
              x2={e[0] + (c[0] - e[0]) * f}
              y1={e[1] + (c[1] - e[1]) * f - h}
              y2={e[1] + (c[1] - e[1]) * f}
              stroke="#b0c5d1"
              strokeOpacity=".28"
              strokeWidth=".7"
            />
            <line
              x1={c[0] + (b[0] - c[0]) * f}
              x2={c[0] + (b[0] - c[0]) * f}
              y1={c[1] + (b[1] - c[1]) * f - h}
              y2={c[1] + (b[1] - c[1]) * f}
              stroke="#9caebc"
              strokeOpacity=".25"
              strokeWidth=".7"
            />
          </g>
        ))}
      <polyline
        points={points([top[3], top[2], top[1]])}
        fill="none"
        stroke="#ead1a1"
        strokeOpacity=".45"
        strokeWidth=".9"
      />
    </g>
  );
}
function Tree({ u, v, scale = 1 }: { u: number; v: number; scale?: number }) {
  const [x, y] = p(u, v);
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`} className="city-tree">
      <ellipse cx="7" cy="0" rx="13" ry="4" fill="#040b0a" opacity=".35" />
      <path
        d="M 0 0 V -19 M 0 -11 L -5 -18"
        stroke="#705d48"
        strokeWidth="2.3"
      />
      <ellipse cx="0" cy="-23" rx="9" ry="14" fill="url(#foliage)" />
      <ellipse cx="-4" cy="-24" rx="4" ry="10" fill="#608c62" opacity=".6" />
      <ellipse cx="2" cy="-13" rx="6" ry="5" fill="#284d38" />
    </g>
  );
}
function Lamp({ u, v }: { u: number; v: number }) {
  const [x, y] = p(u, v);
  return (
    <g>
      <ellipse cx={x} cy={y + 1} rx="16" ry="7" fill="url(#lamp-pool)" />
      <path
        d={`M ${x} ${y} V ${y - 22} l 6 -3`}
        fill="none"
        stroke="#b4afa1"
        strokeWidth="1.1"
      />
      <circle
        cx={x + 6}
        cy={y - 25}
        r="2"
        fill="#ffe4ae"
        filter="url(#city-glow)"
      />
    </g>
  );
}
function RoofDetails({ u, v, h }: { u: number; v: number; h: number }) {
  return (
    <>
      <Structure
        u={u - 0.16}
        v={v - 0.1}
        w={0.28}
        d={0.22}
        h={5}
        z={h}
        material="concrete"
        windows={false}
      />
      <Quad
        u={u + 0.26}
        v={v + 0.07}
        z={h + 1}
        w={0.28}
        d={0.5}
        fill="#304e65"
        stroke="#a3b2b9"
      />
      <Quad
        u={u + 0.26}
        v={v + 0.07}
        z={h + 1}
        w={0.04}
        d={0.5}
        fill="#98a7b5"
      />
      <Quad
        u={u + 0.26}
        v={v + 0.07}
        z={h + 1}
        w={0.28}
        d={0.04}
        fill="#98a7b5"
      />
    </>
  );
}
function Civic({
  u,
  v,
  h,
  palace = false,
}: {
  u: number;
  v: number;
  h: number;
  palace?: boolean;
}) {
  const width = palace ? 2.45 : 2.05;
  return (
    <g>
      {[0, 1, 2].map((i) => (
        <Structure
          key={i}
          u={u + 0.17 * i}
          v={v + 0.17 * i}
          w={width + 0.35 - i * 0.1}
          d={width + 0.35 - i * 0.1}
          h={3}
          z={i * 3}
          material="stone"
          windows={false}
        />
      ))}
      <Structure
        u={u}
        v={v}
        w={width}
        d={palace ? 1.65 : 1.45}
        h={h * 0.56}
        z={9}
        material="stone"
        columns={6}
      />
      {[0, 1, 2, 3, 4].map((i) => (
        <Structure
          key={i}
          u={u - 0.8 + i * 0.4}
          v={v + 0.82}
          w={0.11}
          d={0.12}
          h={h * 0.44}
          z={9}
          material="stone"
          windows={false}
        />
      ))}
      <Structure
        u={u}
        v={v + 0.86}
        w={2.2}
        d={0.23}
        h={5}
        z={h * 0.44 + 9}
        material="stone"
        windows={false}
      />
      {palace ? (
        <>
          <Structure
            u={u - 0.3}
            v={v - 0.3}
            w={0.85}
            d={0.85}
            h={h * 0.9}
            z={9}
            material="stone"
            columns={3}
          />
          <Dome u={u - 0.3} v={v - 0.3} h={h * 0.9 + 9} />
          {[-0.88, 0.8].map((i) => (
            <Structure
              key={i}
              u={u + i}
              v={v - 0.37}
              w={0.43}
              d={0.43}
              h={h * 0.72}
              z={9}
              material="stone"
              columns={2}
            />
          ))}
          <g>
            <path
              d={`M ${p(u - 0.3, v - 0.3, h * 0.9 + 43).join(" ")} v -21`}
              stroke="#d7cbaa"
              strokeWidth="1.4"
            />
            <path
              d={`M ${p(u - 0.3, v - 0.3, h * 0.9 + 58).join(" ")} l 14 4 l -14 4 Z`}
              fill="#d8b36b"
            />
          </g>
        </>
      ) : (
        <>
          <RoofDetails u={u} v={v} h={h * 0.56 + 9} />
          <Quad
            u={u - 0.3}
            v={v}
            z={h * 0.56 + 10}
            w={0.3}
            d={0.7}
            fill="#a9b1b2"
          />
        </>
      )}
    </g>
  );
}
function Dome({ u, v, h }: { u: number; v: number; h: number }) {
  const [x, y] = p(u, v, h);
  return (
    <g>
      <ellipse cx={x} cy={y} rx="23" ry="11" fill="#786b53" />
      <path
        d={`M ${x - 23} ${y} Q ${x - 23} ${y - 29} ${x} ${y - 36} Q ${x + 23} ${y - 29} ${x + 23} ${y} Q ${x} ${y + 10} ${x - 23} ${y}`}
        fill="url(#dome)"
        stroke="#e2c78e"
        strokeWidth=".8"
      />
      <path
        d={`M ${x} ${y - 36} Q ${x - 14} ${y - 12} ${x - 10} ${y + 4} M ${x} ${y - 36} Q ${x + 10} ${y - 12} ${x + 10} ${y + 4}`}
        fill="none"
        stroke="#f0d9a8"
        strokeOpacity=".35"
        strokeWidth=".7"
      />
    </g>
  );
}
function Landmark({
  id,
  u,
  v,
  h,
}: {
  id: string;
  u: number;
  v: number;
  h: number;
}) {
  if (id === "palace" || id === "bank")
    return <Civic u={u} v={v} h={h} palace={id === "palace"} />;
  if (id === "trading")
    return (
      <>
        <Structure u={u} v={v} w={2.05} d={1.85} h={18} material="concrete" />
        <Structure
          u={u - 0.48}
          v={v - 0.3}
          w={0.88}
          d={1.05}
          h={h}
          material="glass"
          columns={4}
        />
        <Structure
          u={u + 0.54}
          v={v + 0.13}
          w={0.77}
          d={0.94}
          h={h * 0.84}
          material="glass"
          columns={3}
        />
        <Structure
          u={u}
          v={v}
          w={1.1}
          d={0.23}
          h={7}
          z={h * 0.46}
          material="glass"
          windows={false}
        />
        <RoofDetails u={u - 0.48} v={v - 0.3} h={h} />
        <RoofDetails u={u + 0.54} v={v + 0.13} h={h * 0.84} />
      </>
    );
  if (id === "analysis")
    return (
      <>
        <Structure u={u} v={v} w={1.7} d={1.6} h={16} material="concrete" />
        {[0, 1, 2].map((i) => (
          <Structure
            key={i}
            u={u - 0.17 * i}
            v={v - 0.17 * i}
            w={1.55 - i * 0.25}
            d={1.4 - i * 0.22}
            h={h - i * 24}
            material="glass"
            columns={5 - i}
          />
        ))}
        <RoofDetails u={u - 0.34} v={v - 0.34} h={h - 48} />
        <g>
          {(() => {
            const [x, y] = p(u, v, h);
            return (
              <>
                <path
                  d={`M ${x} ${y} v -24 M ${x - 7} ${y - 22} l 14 0`}
                  stroke="#b4c8cd"
                  strokeWidth="1.4"
                />
                <circle cx={x} cy={y - 25} r="2" fill="#e48779" />
              </>
            );
          })()}
        </g>
      </>
    );
  if (id === "operations")
    return (
      <>
        <Structure
          u={u}
          v={v}
          w={1.85}
          d={1.5}
          h={h * 0.78}
          material="concrete"
          columns={6}
        />
        <Structure
          u={u - 0.23}
          v={v - 0.21}
          w={1.12}
          d={0.92}
          h={h}
          material="glass"
          columns={4}
        />
        <RoofDetails u={u - 0.23} v={v - 0.21} h={h} />
        <Quad
          u={u + 0.32}
          v={v + 0.17}
          z={h * 0.78 + 1}
          w={0.65}
          d={0.65}
          fill="#2b4344"
          stroke="#c8c9ae"
        />
        {(() => {
          const [x, y] = p(u + 0.32, v + 0.17, h * 0.78 + 3);
          return (
            <text
              x={x}
              y={y + 3}
              fill="#c7d7c4"
              fontSize="9"
              textAnchor="middle"
              transform={`rotate(27 ${x} ${y})`}
            >
              H
            </text>
          );
        })()}
      </>
    );
  if (id === "risk")
    return (
      <>
        <Structure
          u={u}
          v={v}
          w={2.1}
          d={1.45}
          h={h}
          material="brick"
          columns={6}
        />
        <Structure
          u={u + 0.65}
          v={v + 0.43}
          w={0.9}
          d={0.7}
          h={h * 0.7}
          material="glass"
          columns={3}
        />
        <RoofDetails u={u} v={v} h={h} />
        <Quad
          u={u - 0.38}
          v={v - 0.12}
          z={h + 1}
          w={0.7}
          d={0.66}
          fill="#456149"
        />
        {[0, 1].map((i) => (
          <Tree
            key={i}
            u={u + 0.95 + i * 0.2}
            v={v + 0.93 - i * 0.45}
            scale={0.7}
          />
        ))}
      </>
    );
  if (id === "vault")
    return (
      <>
        <Structure
          u={u}
          v={v}
          w={2.0}
          d={1.65}
          h={h}
          material="concrete"
          columns={5}
        />
        <Structure
          u={u - 0.15}
          v={v - 0.12}
          w={1.2}
          d={0.95}
          h={7}
          z={h}
          material="concrete"
          windows={false}
        />
        <Quad
          u={u + 0.1}
          v={v + 0.95}
          w={1.8}
          d={0.6}
          fill="#5b6263"
          stroke="#858e8d"
        />
        {[0, 1, 2, 3, 4].map((i) => {
          const [x, y] = p(u - 0.8 + i * 0.38, v + 1.24);
          return (
            <path
              key={i}
              d={`M ${x} ${y} v -9`}
              stroke="#bec3b8"
              strokeWidth="1"
            />
          );
        })}
        <path
          d={`M ${p(u - 0.8, v + 1.24, 8).join(" ")} L ${p(u + 0.72, v + 1.24, 8).join(" ")}`}
          stroke="#919ca0"
          strokeWidth="1.2"
        />
        <RoofDetails u={u} v={v} h={h + 7} />
      </>
    );
  return (
    <>
      <Structure
        u={u}
        v={v}
        w={2.3}
        d={1.5}
        h={h}
        material="brick"
        columns={7}
      />
      <Structure
        u={u}
        v={v}
        w={2.4}
        d={1.6}
        h={4}
        z={h}
        material="stone"
        windows={false}
      />
      {Array.from({ length: 6 }, (_, i) => {
        const offset = -0.98 + i * 0.39;
        return (
          <g key={i}>
            <Quad
              u={u + offset}
              v={v + 0.9}
              z={17}
              w={0.38}
              d={0.45}
              fill={i % 2 ? "#ddc5a0" : "#9b6453"}
            />
            <Structure
              u={u + offset}
              v={v + 1.04}
              w={0.37}
              d={0.05}
              h={4}
              z={13}
              material={i % 2 ? "stone" : "brick"}
              windows={false}
            />
          </g>
        );
      })}
      <Quad u={u - 0.35} v={v - 0.1} w={0.8} d={0.8} z={h + 5} fill="#5d6c51" />
      {[-1, 1].map((i) => (
        <Tree key={i} u={u + i * 1.35} v={v + 0.3} scale={0.7} />
      ))}
    </>
  );
}
function Car({
  axis,
  road,
  duration,
  delay,
  color,
}: {
  axis: "u" | "v";
  road: number;
  duration: number;
  delay: number;
  color: string;
}) {
  const start = axis === "u" ? p(-7.6, road) : p(road, -7.6),
    end = axis === "u" ? p(7.6, road) : p(road, 7.6);
  return (
    <g className="city-car">
      <animateMotion
        path={`M ${start.join(" ")} L ${end.join(" ")}`}
        dur={`${duration}s`}
        begin={`-${delay}s`}
        repeatCount="indefinite"
      />
      <g transform={axis === "u" ? "" : "scale(-1 1)"}>
        <ellipse cx="3" cy="4" rx="11" ry="3" fill="#000" opacity=".4" />
        <path
          d="M -10 -1 L -1 -5 L 10 1 L 1 5 Z"
          fill={color}
          stroke="#c7c8bd"
          strokeWidth=".45"
        />
        <path d="M -5 -2 L -1 -4 L 5 0 L 1 2 Z" fill="#81a4b4" />
        <path d="M -10 -1 L -10 2 L 1 8 L 1 5 Z" fill="#394b56" />
        <path d="M 1 5 L 10 1 L 10 4 L 1 8 Z" fill="#212c33" />
        <circle cx="-6" cy="3" r="1.5" fill="#0f1920" />
        <circle cx="-1" cy="6" r="1.5" fill="#0f1920" />
        <path
          d="M 8 2 l 2 -1 M 8 4 l 2 -1"
          stroke="#f6e5bc"
          strokeWidth="1.4"
        />
      </g>
    </g>
  );
}
export function City({
  state,
  onBuilding,
  civic,
  onPerson,
  onService,
}: {
  state: GameState;
  civic: Civilization | null;
  onPerson: (id: string) => void;
  onService: (id: string) => void;
  onBuilding: (id: string) => void;
}) {
  const [hover, setHover] = useState<string | null>(null),
    [light, setNight] = useState<boolean | null>(null);
  const night =
    light ?? (civic ? civic.clock.hour < 6 || civic.clock.hour >= 20 : true);
  const route = (id: string) =>
    ["home"].includes(id)
      ? "housing"
      : ["farm", "factory", "studio"].includes(id)
        ? "companies"
        : id === "market"
          ? "policies"
          : id === "park"
            ? "families"
            : "education";
  const facilities =
    civic?.facilities.filter(
      (f) => !["market", "park", "home"].includes(f.id),
    ) ?? [];
  const level = levelOf(state);
  const roadPositions = [-7.1, -2.5, 2.5, 7.1];
  const decorators: Array<{
    u: number;
    v: number;
    kind: "tree" | "lamp" | "building";
    h?: number;
  }> = [];
  for (let i = 0; i < 38 + level * 8; i++) {
    const u = ((i * 37) % 144) / 10 - 7.2,
      v = ((i * 67 + 15) % 144) / 10 - 7.2;
    if (
      facilities.some(
        (f) =>
          Math.abs(f.location[0] - u) < 1.2 &&
          Math.abs(f.location[1] - v) < 1.2,
      ) ||
      BUILDINGS.some(
        (b) => Math.abs(b.u - u) < 1.7 && Math.abs(b.v - v) < 1.7,
      ) ||
      roadPositions.some(
        (r) => Math.abs(u - r) < 0.65 || Math.abs(v - r) < 0.65,
      )
    )
      continue;
    decorators.push({
      u,
      v,
      kind: i % 3 === 0 ? "tree" : "building",
      h: 18 + (i % 5) * 8 + level * 5,
    });
  }
  for (const i of [-6.2, -4.4, -0.9, 0.9, 4.4, 6.2]) {
    decorators.push(
      { u: i, v: 2.95, kind: "lamp" },
      { u: 2.95, v: i, kind: "lamp" },
      { u: i, v: -2.97, kind: "tree" },
      { u: -2.97, v: i, kind: "tree" },
    );
  }
  const objects = [
    ...decorators.map((d, i) => ({ ...d, id: `decor-${i}` })),
    ...facilities
      .filter((f) => f.built)
      .map((f) => ({
        id: f.id,
        u: f.location[0],
        v: f.location[1],
        h: f.id === "university" ? 62 : 30,
        kind: "social" as const,
      })),
    ...BUILDINGS.map((b) => ({ ...b, kind: "landmark" as const })),
  ].sort((a, b) => a.u + a.v - (b.u + b.v));
  return (
    <div
      className={`city-scene realistic-city ${night ? "night-scene" : "day-scene"} city-level-${level}`}
    >
      <div className="city-light-controls">
        <button
          className={night ? "active" : ""}
          aria-label="إضاءة ليلية"
          aria-pressed={night}
          onClick={() => setNight(true)}
        >
          <Moon size={13} />
          <span>ليل</span>
        </button>
        <button
          className={!night ? "active" : ""}
          aria-label="إضاءة نهارية"
          aria-pressed={!night}
          onClick={() => setNight(false)}
        >
          <Sun size={13} />
          <span>نهار</span>
        </button>
        <button
          aria-label="إضاءة حسب وقت المجتمع"
          onClick={() => setNight(null)}
          className={light === null ? "active" : ""}
        >
          تلقائي
        </button>
      </div>
      <svg
        className="city-svg"
        viewBox="0 0 1040 660"
        role="img"
        aria-label="مدينة واقعية تفاعلية بمبانٍ وشوارع وحدائق؛ اختر مبنى لفتح قسمه"
      >
        <defs>
          <filter id="city-glow">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="soft-shadow">
            <feGaussianBlur stdDeviation="2" />
          </filter>
          <linearGradient id="sky" x2="0" y2="1">
            <stop stopColor={night ? "#0c1824" : "#344557"} />
            <stop offset=".6" stopColor={night ? "#192c37" : "#7b8583"} />
            <stop offset="1" stopColor={night ? "#0e1a22" : "#334a4a"} />
          </linearGradient>
          <radialGradient id="horizon">
            <stop
              stopColor={night ? "#a7a878" : "#e6c997"}
              stopOpacity={night ? ".10" : ".4"}
            />
            <stop offset="1" stopColor="#999" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="glass-front" x2=".7" y2="1">
            <stop stopColor={night ? "#456579" : "#7ea1b1"} />
            <stop offset=".45" stopColor={night ? "#1f3b4e" : "#3c6075"} />
            <stop offset="1" stopColor="#172c3a" />
          </linearGradient>
          <linearGradient id="glass-side" x2="1" y2="1">
            <stop stopColor="#1c3546" />
            <stop offset="1" stopColor="#102431" />
          </linearGradient>
          <linearGradient id="glass-roof">
            <stop stopColor="#7193a0" />
            <stop offset="1" stopColor="#3f5f6b" />
          </linearGradient>
          <linearGradient id="stone-front" x2="1" y2="1">
            <stop stopColor={night ? "#d0baa0" : "#eadbc5"} />
            <stop offset="1" stopColor={night ? "#9c8b76" : "#b5a089"} />
          </linearGradient>
          <linearGradient id="stone-side">
            <stop stopColor="#837863" />
            <stop offset="1" stopColor="#676354" />
          </linearGradient>
          <linearGradient id="stone-roof">
            <stop stopColor="#d7cab1" />
            <stop offset="1" stopColor="#afa58e" />
          </linearGradient>
          <linearGradient id="concrete-front" x2="1" y2="1">
            <stop stopColor={night ? "#73888f" : "#a3b1b4"} />
            <stop offset="1" stopColor="#4c626d" />
          </linearGradient>
          <linearGradient id="concrete-side">
            <stop stopColor="#405462" />
            <stop offset="1" stopColor="#2b404b" />
          </linearGradient>
          <linearGradient id="concrete-roof">
            <stop stopColor="#99aaa9" />
            <stop offset="1" stopColor="#5e7376" />
          </linearGradient>
          <linearGradient id="brick-front" x2="0" y2="1">
            <stop stopColor={night ? "#a88b76" : "#c19c81"} />
            <stop offset="1" stopColor="#785f54" />
          </linearGradient>
          <linearGradient id="brick-side">
            <stop stopColor="#6d6257" />
            <stop offset="1" stopColor="#524b47" />
          </linearGradient>
          <linearGradient id="brick-roof">
            <stop stopColor="#a89783" />
            <stop offset="1" stopColor="#6d716b" />
          </linearGradient>
          <linearGradient id="window-light">
            <stop stopColor={night ? "#f0d49c" : "#99bac8"} />
            <stop offset=".5" stopColor={night ? "#ffe9b9" : "#83a7bb"} />
            <stop offset="1" stopColor={night ? "#b79562" : "#668b9f"} />
          </linearGradient>
          <linearGradient id="dome">
            <stop stopColor="#e6cd91" />
            <stop offset=".5" stopColor="#a89368" />
            <stop offset="1" stopColor="#6b674f" />
          </linearGradient>
          <radialGradient id="foliage" cx=".3" cy=".25">
            <stop stopColor={night ? "#64876a" : "#83a878"} />
            <stop offset="1" stopColor="#1f4736" />
          </radialGradient>
          <radialGradient id="lamp-pool">
            <stop stopColor="#fbd7a1" stopOpacity={night ? ".3" : ".05"} />
            <stop offset="1" stopColor="#ead7a3" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="river" x2="0" y2="1">
            <stop stopColor="#476d7c" />
            <stop offset="1" stopColor="#193b4c" />
          </linearGradient>
        </defs>
        <rect width="1040" height="660" fill="url(#sky)" />
        <ellipse cx="540" cy="165" rx="520" ry="210" fill="url(#horizon)" />
        <path
          d="M 0 176 Q 90 119 167 151 Q 270 103 341 144 Q 470 72 591 134 Q 721 89 838 150 Q 945 95 1040 145 V 400 H 0 Z"
          fill={night ? "#162935" : "#52676d"}
          opacity=".75"
        />
        <path
          d="M 0 214 Q 200 145 344 184 Q 510 125 691 178 Q 870 131 1040 190 V 420 H 0 Z"
          fill={night ? "#1b3039" : "#607878"}
          opacity=".55"
        />
        <g opacity={night ? ".22" : ".30"}>
          {Array.from({ length: 35 }, (_, i) => {
            const x = 36 + i * 28,
              h = 12 + ((i * 13) % 43);
            return (
              <g key={i}>
                <rect
                  x={x}
                  y={216 - h}
                  width={15 + (i % 3) * 5}
                  height={h}
                  fill="#142733"
                />
                {night && (
                  <path
                    d={`M ${x + 5} ${219 - h} v ${h - 6} M ${x + 12} ${219 - h} v ${h - 6}`}
                    stroke="#e1bf8b"
                    strokeWidth="1"
                    strokeDasharray="2 5"
                  />
                )}
              </g>
            );
          })}
        </g>
        {night && (
          <g opacity=".6">
            <circle cx="126" cy="99" r="11" fill="#c5d0c8" />
            <circle cx="130" cy="95" r="10" fill="#172834" />
            {Array.from({ length: 35 }, (_, i) => (
              <circle
                key={i}
                cx={(i * 131) % 1040}
                cy={40 + ((i * 31) % 122)}
                r={i % 4 === 0 ? 1 : 0.6}
                fill="#c9d9dc"
                opacity=".6"
              />
            ))}
          </g>
        )}
        <polygon
          points={points([
            p(-8.6, -8.6),
            p(8.6, -8.6),
            p(8.6, 8.6),
            p(-8.6, 8.6),
          ])}
          fill={night ? "#32494a" : "#5d7467"}
          stroke="#718f88"
          strokeOpacity=".45"
        />
        <polygon
          points={points([
            p(-8.6, 8.6),
            p(8.6, 8.6),
            p(8.6, 8.6, -11),
            p(-8.6, 8.6, -11),
          ])}
          fill="#192e33"
        />
        <polygon
          points={points([
            p(8.6, -8.6),
            p(8.6, 8.6),
            p(8.6, 8.6, -11),
            p(8.6, -8.6, -11),
          ])}
          fill="#223a40"
        />
        <Quad u={7.94} v={0} w={0.55} d={16.5} fill="url(#river)" />
        <Quad u={-1} v={7.98} w={13.3} d={0.48} fill="url(#river)" />
        {[-5, 0, 5].map((u) => (
          <g key={u}>
            <Quad
              u={u}
              v={7.98}
              w={0.7}
              d={0.75}
              fill="#90958b"
              stroke="#c7c7b0"
            />
            <Quad
              u={7.94}
              v={u}
              d={0.7}
              w={0.75}
              fill="#90958b"
              stroke="#c7c7b0"
            />
          </g>
        ))}
        {roadPositions.map((r) => (
          <g key={r}>
            <Quad
              u={r}
              v={0}
              w={1.14}
              d={15.6}
              fill={night ? "#718482" : "#9ba89d"}
            />
            <Quad
              u={0}
              v={r}
              w={15.6}
              d={1.14}
              fill={night ? "#718482" : "#9ba89d"}
            />
            <Quad u={r} v={0} w={0.78} d={15.6} fill="#29363e" />
            <Quad u={0} v={r} w={15.6} d={0.78} fill="#29363e" />
          </g>
        ))}
        {roadPositions.map((r) => (
          <g key={r}>
            <path
              d={`M ${p(r, -7.8).join(" ")} L ${p(r, 7.8).join(" ")}`}
              fill="none"
              stroke="#cbbf94"
              strokeWidth=".7"
              strokeDasharray="6 9"
              opacity=".75"
            />
            <path
              d={`M ${p(-7.8, r).join(" ")} L ${p(7.8, r).join(" ")}`}
              fill="none"
              stroke="#cbbf94"
              strokeWidth=".7"
              strokeDasharray="6 9"
              opacity=".75"
            />
          </g>
        ))}
        {[-2.5, 2.5].flatMap((u) =>
          [-2.5, 2.5].map((v) => (
            <g key={`${u}-${v}`}>
              {[-0.85, 0.85].flatMap((off) =>
                Array.from({ length: 5 }, (_, i) => (
                  <Quad
                    key={`${off}-${i}`}
                    u={u - 0.25 + i * 0.12}
                    v={v + off}
                    w={0.06}
                    d={0.65}
                    fill="#d9d4bd"
                    opacity={0.75}
                  />
                )),
              )}
            </g>
          )),
        )}
        <Quad
          u={0}
          v={0}
          w={4.1}
          d={3.9}
          fill={night ? "#8c8c7a" : "#b7b2a0"}
          stroke="#c6bda2"
        />
        <Quad u={0} v={1.45} w={3.9} d={0.53} fill="#778a6e" />
        <Quad u={-0.1} v={1.65} w={2.45} d={0.18} fill="#c1bba4" />
        {[...BUILDINGS].map((b) => (
          <g key={b.id}>
            <Quad
              u={b.u}
              v={b.v}
              w={b.id === "palace" ? 2.6 : 2.9}
              d={2.55}
              fill={night ? "#697574" : "#8f998b"}
              stroke="#b7b89e"
            />
            {b.id !== "palace" && (
              <Quad
                u={b.u + 0.82}
                v={b.v - 0.87}
                w={0.45}
                d={0.45}
                fill="#335d42"
              />
            )}
            <polygon
              points={points([
                p(b.u - 0.8, b.v - 0.8),
                p(b.u + 0.8, b.v - 0.8),
                p(b.u + 2.3, b.v + 0.9),
                p(b.u + 0.7, b.v + 1.4),
              ])}
              fill="#03151b"
              opacity={night ? ".20" : ".32"}
              filter="url(#soft-shadow)"
            />
          </g>
        ))}
        <g pointerEvents="none">
          {[0, 1, 2, 3, 4].map((i) => (
            <Car
              key={i}
              axis={i % 2 ? "u" : "v"}
              road={(i % 2 ? -2.5 : 2.5) + (i % 3 === 0 ? -0.2 : 0.2)}
              duration={21 + i * 3}
              delay={i * 7}
              color={["#d6d2bb", "#426e83", "#bc8b70", "#738d8c", "#a4a8a2"][i]}
            />
          ))}
          {[0, 1, 2].map((i) => (
            <Car
              key={`outer-${i}`}
              axis="u"
              road={7.1 + 0.2}
              duration={27 + i * 2}
              delay={i * 9}
              color={["#cfbaa1", "#416678", "#8a7570"][i]}
            />
          ))}
        </g>
        {objects.map((o) => {
          if (o.kind === "tree")
            return <Tree key={o.id} u={o.u} v={o.v} scale={0.8} />;
          if (o.kind === "lamp") return <Lamp key={o.id} u={o.u} v={o.v} />;
          if (o.kind === "building")
            return (
              <g key={o.id} pointerEvents="none">
                <Structure
                  u={o.u}
                  v={o.v}
                  w={0.8}
                  d={0.62}
                  h={o.h}
                  material={o.h! > 40 ? "glass" : "brick"}
                  columns={3}
                />
                <RoofDetails u={o.u} v={o.v} h={o.h!} />
              </g>
            );
          if (o.kind === "social") {
            const f = facilities.find((f) => f.id === o.id)!;
            return (
              <g
                key={o.id}
                className="social-landmark"
                onClick={() => onService(route(f.id))}
              >
                <title>{f.name}</title>
                <Structure
                  u={o.u}
                  v={o.v}
                  w={0.85}
                  d={0.8}
                  h={o.h}
                  material={
                    f.id === "studio" || f.id === "university"
                      ? "glass"
                      : "brick"
                  }
                  columns={3}
                />
                <RoofDetails u={o.u} v={o.v} h={o.h!} />
              </g>
            );
          }
          const b = BUILDINGS.find((b) => b.id === o.id)!;
          const height = b.h + level * 9;
          return (
            <g
              key={o.id}
              onClick={() => onBuilding(b.id)}
              onMouseEnter={() => setHover(b.id)}
              onMouseLeave={() => setHover(null)}
              className={`landmark-model ${hover === b.id ? "selected" : ""}`}
            >
              <title>{b.name}</title>
              <Landmark id={b.id} u={b.u} v={b.v} h={height} />
              {[-1, 1].map((i) => (
                <Lamp key={i} u={b.u + i * 1.25} v={b.v + 1.28} />
              ))}
            </g>
          );
        })}
        <g pointerEvents="none">
          <Quad u={0.08} v={1.68} w={0.56} d={0.44} fill="#b3b5a3" />
          {(() => {
            const [x, y] = p(0.08, 1.68);
            return (
              <>
                <ellipse
                  cx={x}
                  cy={y}
                  rx="12"
                  ry="6"
                  fill="#6f9da7"
                  stroke="#d5d2b8"
                />
                <path
                  d={`M ${x} ${y} q -5 -16 -8 -2 M ${x} ${y} q 5 -18 9 -3`}
                  fill="none"
                  stroke="#bfe0db"
                  strokeWidth="1"
                />
                <circle cx={x} cy={y - 10} r="2" fill="#d7eee1" />
              </>
            );
          })()}
          {[-1.4, 1.4].map((i) => (
            <Tree key={i} u={i} v={1.6} scale={0.8} />
          ))}
          {Array.from({ length: 12 }, (_, i) => {
            const [x, y] = p(
              -1.4 + (i % 4) * 0.65,
              1.45 + Math.floor(i / 4) * 0.2,
            );
            return (
              <g key={i}>
                <circle cx={x} cy={y - 4} r="1.2" fill="#e2c5a0" />
                <path
                  d={`M ${x} ${y - 2} v 3`}
                  stroke={i % 2 ? "#3b5060" : "#b7986f"}
                  strokeWidth="1.7"
                />
              </g>
            );
          })}
        </g>
        {civic && (
          <g>
            {civic.homes.slice(0, 24).map((h, i) => {
              const u = -6.1 + (i % 4) * 0.62,
                v = 4.2 + Math.floor(i / 4) * 0.55;
              return (
                <g
                  key={h.id}
                  className="social-landmark"
                  onClick={() => onService("housing")}
                >
                  <title>
                    {h.name} • {h.residents.length} سكان
                  </title>
                  <Structure
                    u={u}
                    v={v}
                    w={0.46}
                    d={0.42}
                    h={18 + (h.family ? 7 : 0)}
                    material="brick"
                    columns={2}
                  />
                </g>
              );
            })}
          </g>
        )}
        {facilities.map((f) => {
          const [x, y] = p(...f.location);
          return (
            <g
              key={`label-${f.id}`}
              className="social-landmark"
              role="button"
              tabIndex={0}
              aria-label={`فتح ${f.name}`}
              onClick={() => onService(route(f.id))}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onService(route(f.id));
                }
              }}
            >
              <rect
                x={x - 48}
                y={y + 9}
                width="96"
                height="21"
                rx="5"
                fill="#0b1b22"
                stroke={f.built ? "#79b9ac88" : "#85744d"}
                strokeDasharray={f.built ? undefined : "3 2"}
              />
              <text
                x={x}
                y={y + 23}
                textAnchor="middle"
                fill={f.built ? "#b0d4cb" : "#bbaa85"}
                fontSize="9"
                fontFamily="Tahoma, Arial"
              >
                {f.name}
                {!f.built ? " +" : ""}
              </text>
            </g>
          );
        })}
        {civic?.people
          .filter((q) => q.alive)
          .map((q, i) => {
            const f = civic.facilities.find((f) => f.id === q.place);
            let [u, v] = f?.location ?? [-5.5, 5.4];
            if (q.place === "home") {
              const index = civic.homes.findIndex((h) => h.id === q.home);
              u = -6.1 + (index % 4) * 0.62;
              v = 4.2 + Math.floor(index / 4) * 0.55;
            } else {
              u += 0.65 + (i % 4) * 0.2;
              v += 0.75 + Math.floor(i / 4) * 0.13;
            }
            const [x, y] = p(u, v);
            const minor = age(civic, q) < 18;
            return (
              <g
                key={q.id}
                role="button"
                tabIndex={0}
                aria-label={`الشخصية ${q.name}`}
                className="resident-marker"
                style={{ transform: `translate(${x}px,${y}px)` }}
                onClick={() => onPerson(q.id)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    onPerson(q.id);
                  }
                }}
              >
                <title>
                  {q.name} • {q.activity}
                </title>
                <circle r="13" cy="-7" fill="transparent" />
                <ellipse rx="4" ry="2" fill="#0008" />
                <path
                  d={
                    minor
                      ? "M-2 -5 L-2 0 M2 -5 L2 0"
                      : "M-2 -7 L-2 0 M2 -7 L2 0"
                  }
                  stroke="#243945"
                  strokeWidth="2"
                />
                <path
                  d="M-3 -11 H3 V-4 H-3Z"
                  fill={q.gender === "f" ? "#c9a4cd" : "#80c8bf"}
                />
                <circle r="3" cy="-14" fill="#dfbc97" />
                <circle
                  r="1.2"
                  cx="5"
                  cy="-14"
                  fill={q.retired ? "#d5bd76" : "#93debb"}
                />
                <g className="resident-name" pointerEvents="none">
                  <rect
                    x="-55"
                    y="-39"
                    width="110"
                    height="18"
                    rx="4"
                    fill="#091720"
                    stroke="#78baa766"
                  />
                  <text
                    y="-27"
                    textAnchor="middle"
                    fontSize="9"
                    fill="#e1d4ad"
                    fontFamily="Tahoma, Arial"
                  >
                    {q.name}
                  </text>
                </g>
              </g>
            );
          })}
        {BUILDINGS.map((b) => {
          const [x, y] = p(b.u, b.v),
            active = hover === b.id;
          return (
            <g
              key={b.id}
              className={`building building-label real-building-label ${active ? "active" : ""}`}
              role="button"
              aria-label={b.name}
              tabIndex={0}
              onMouseEnter={() => setHover(b.id)}
              onMouseLeave={() => setHover(null)}
              onFocus={() => setHover(b.id)}
              onBlur={() => setHover(null)}
              onClick={() => onBuilding(b.id)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onBuilding(b.id);
                }
              }}
            >
              <path
                d={`M ${x} ${y + 16} V ${y + 28}`}
                stroke={b.color}
                strokeOpacity=".65"
              />
              <rect
                x={x - 66}
                y={y + 28}
                width="132"
                height="28"
                rx="6"
                fill="#09131bed"
                stroke={active ? "#f7db9e" : "#8295a478"}
                strokeWidth={active ? 1.4 : 0.7}
              />
              <circle cx={x + 55} cy={y + 42} r="2" fill={b.color} />
              <text
                x={x - 2}
                y={y + 47}
                textAnchor="middle"
                fontSize="12"
                fontFamily="Tahoma, Arial"
                fill={active ? "#fff1d6" : "#d7e0e4"}
              >
                {b.name}
              </text>
            </g>
          );
        })}
        <g opacity=".6">
          <path
            d="M 93 491 l -14 7 l 14 7 l 14 -7 Z"
            stroke="#d5ccaa"
            fill="none"
          />
          <text x="93" y="484" textAnchor="middle" fill="#d5ccaa" fontSize="10">
            N
          </text>
          <text
            x="904"
            y="575"
            textAnchor="middle"
            fill="#aac0c0"
            fontSize="8"
            letterSpacing="2"
          >
            EMPIRE CENTRAL DISTRICT
          </text>
        </g>
      </svg>
      <div className="community-legend">
        <span>
          {civic?.people.filter((p) => p.alive).length ?? 0} سكان يتحركون حسب
          احتياجاتهم ووقت اللعبة
        </span>
        <button onClick={() => onService("housing")}>حي السكان</button>
        <button onClick={() => onService("education")}>التعليم والخدمات</button>
        <button onClick={() => onService("population")}>
          اضغط شخصية لفتح حياتها
        </button>
      </div>
      <div className="city-tip">
        <span className="live-dot" />
        <span className="desktop-tip">
          مدينة حيّة • اضغط على مبنى لاستكشافه
        </span>
        <span className="mobile-tip">اسحب الخريطة أو اختر مبنى بالأسفل</span>
      </div>
    </div>
  );
}
