import { createRoot } from "react-dom/client";
import App from "./App";
import { CivilizationProvider } from "./civilization/context";
createRoot(document.getElementById("root")!).render(
  <CivilizationProvider>
    <App />
  </CivilizationProvider>,
);
