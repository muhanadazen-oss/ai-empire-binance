import { defineConfig } from 'drizzle-kit';
export default defineConfig({ dialect: 'sqlite', schema: './server/vault-schema.ts', out: './drizzle' });
